#!/usr/bin/env python3
"""
CERT Scenario-Based Loader
Uses the actual malicious activity files (r6_2-1.csv through r6_2-5.csv)
These files contain ONLY malicious user activity including WikiLeaks/Dropbox!
"""

import os
import pandas as pd
import numpy as np
from datetime import datetime


def load_cert_with_scenarios(cert_path, max_events=2_000_000, max_users=200):
    """
    Load CERT dataset including the actual scenario files.
    
    The scenario files (r6_2-1.csv through r6_2-5.csv) contain ONLY 
    malicious activity, including WikiLeaks uploads and Dropbox leaks.
    
    Args:
        cert_path: Path to CERT directory (should contain r6.2 folder)
        max_events: Maximum events to load
        max_users: Maximum users to include
        
    Returns:
        df: DataFrame with all events
        gt_df: Ground truth DataFrame
    """
    
    print("="*70)
    print("CERT SCENARIO-BASED LOADER")
    print("="*70)
    print(f"  Loading from: {cert_path}")
    print(f"  Including malicious scenario files!")
    
    all_events = []
    
    # ========================================================================
    # 1. Load MAIN dataset files (normal + some malicious)
    # ========================================================================
    
    # LOGON
    logon_file = os.path.join(cert_path, 'logon.csv')
    if os.path.exists(logon_file):
        print(f"\n  📂 Loading logon.csv...")
        logon_df = pd.read_csv(logon_file, on_bad_lines='skip', nrows=500000)
        print(f"     Rows: {len(logon_df):,}")
        
        for _, row in logon_df.iterrows():
            try:
                activity = str(row.iloc[5]).strip().strip('"')
                all_events.append({
                    'user_id': str(row.iloc[3]).strip().strip('"'),
                    'timestamp': str(row.iloc[2]).strip().strip('"'),
                    'event_type': f"logon_{activity}",
                    'device': str(row.iloc[4]).strip().strip('"'),
                    'ip_address': '',
                    'path': '',
                    'source': 'logon'
                })
            except:
                continue
    
    # DEVICE
    device_file = os.path.join(cert_path, 'device.csv')
    if os.path.exists(device_file):
        print(f"\n  📂 Loading device.csv...")
        device_df = pd.read_csv(device_file, on_bad_lines='skip', nrows=300000)
        print(f"     Rows: {len(device_df):,}")
        
        for _, row in device_df.iterrows():
            try:
                activity = str(row.iloc[6]).strip().strip('"') if len(row) > 6 else 'Unknown'
                all_events.append({
                    'user_id': str(row.iloc[3]).strip().strip('"'),
                    'timestamp': str(row.iloc[2]).strip().strip('"'),
                    'event_type': f"device_{activity}",
                    'device': str(row.iloc[4]).strip().strip('"'),
                    'ip_address': '',
                    'path': str(row.iloc[5]).strip().strip('"') if len(row) > 5 else '',
                    'source': 'device'
                })
            except:
                continue
    
    # FILE
    file_file = os.path.join(cert_path, 'file.csv')
    if os.path.exists(file_file):
        print(f"\n  📂 Loading file.csv...")
        file_df = pd.read_csv(file_file, on_bad_lines='skip', nrows=200000)
        print(f"     Rows: {len(file_df):,}")
        
        for _, row in file_df.iterrows():
            try:
                filename = str(row.iloc[5]).strip().strip('"') if len(row) > 5 else ''
                ext = filename.split('.')[-1].lower() if '.' in filename else 'unknown'
                all_events.append({
                    'user_id': str(row.iloc[3]).strip().strip('"'),
                    'timestamp': str(row.iloc[2]).strip().strip('"'),
                    'event_type': f"file_{ext}",
                    'device': str(row.iloc[4]).strip().strip('"'),
                    'ip_address': '',
                    'path': filename,
                    'source': 'file'
                })
            except:
                continue
    
    # HTTP (limited)
    http_file = os.path.join(cert_path, 'http.csv')
    if os.path.exists(http_file):
        print(f"\n  📂 Loading http.csv (limited to 500k)...")
        http_df = pd.read_csv(http_file, on_bad_lines='skip', nrows=500000)
        print(f"     Rows: {len(http_df):,}")
        
        for _, row in http_df.iterrows():
            try:
                timestamp_str = str(row.iloc[1]).strip()
                url = str(row.iloc[5]).strip().lower() if len(row) > 5 else ''
                activity = str(row.iloc[6]).strip().lower() if len(row) > 6 else ''
                
                url = url.strip('"').strip("'")
                activity = activity.strip('"').strip("'")
                
                event_type = 'http_browse'
                if 'upload' in activity or 'www upload' in activity.lower():
                    event_type = 'http_upload'
                elif 'download' in activity:
                    event_type = 'http_download'
                
                all_events.append({
                    'user_id': str(row.iloc[2]).strip().strip('"') if len(row) > 2 else '',
                    'timestamp': timestamp_str,
                    'event_type': event_type,
                    'device': str(row.iloc[3]).strip().strip('"') if len(row) > 3 else '',
                    'ip_address': '',
                    'path': url[:200],
                    'source': 'http'
                })
            except:
                continue
    
    # ========================================================================
    # 2. Load SCENARIO files (CRITICAL - contains WikiLeaks/Dropbox!)
    # ========================================================================
    print(f"\n  🔴 Loading malicious scenario files...")
    
    scenario_files = {
        'r6.2-1.csv': 'ACM2278',  # WikiLeaks
        'r6.2-2.csv': 'CMP2946',  # IP Theft
        'r6.2-3.csv': 'Scenario3',  # Mass resignation
        'r6.2-4.csv': 'CDE1846',  # Data exfiltration
        'r6.2-5.csv': 'MBG3183',  # Dropbox leak
    }
    
    malicious_users = []
    wikileaks_count = 0
    dropbox_count = 0
    
    for scenario_file, scenario_name in scenario_files.items():
        scenario_path = os.path.join(cert_path, scenario_file)
        
        if not os.path.exists(scenario_path):
            print(f"     ⚠️  {scenario_file} not found")
            continue
        
        print(f"\n     📋 Loading {scenario_file} ({scenario_name})...")
        
        try:
            # Read scenario file
            with open(scenario_path, 'r', encoding='utf-8', errors='ignore') as f:
                lines = f.readlines()
            
            print(f"        Rows: {len(lines):,}")
            
            for line in lines:
                try:
                    parts = line.strip().split(',')
                    if len(parts) < 4:
                        continue
                    
                    event_src = parts[0].strip()
                    timestamp = parts[2].strip('"')
                    user = parts[3].strip('"')
                    device = parts[4].strip('"') if len(parts) > 4 else ''
                    
                    # Track malicious users
                    if user not in malicious_users:
                        malicious_users.append(user)
                    
                    # Parse event type based on source
                    if event_src == 'logon':
                        activity = parts[5].strip('"') if len(parts) > 5 else 'Logon'
                        event_type = f"logon_{activity}"
                        path = ''
                        
                    elif event_src == 'device':
                        activity = parts[6].strip('"') if len(parts) > 6 else 'Unknown'
                        event_type = f"device_{activity}"
                        path = parts[5].strip('"') if len(parts) > 5 else ''
                        
                    elif event_src == 'file':
                        filename = parts[5].strip('"') if len(parts) > 5 else ''
                        ext = filename.split('.')[-1].lower() if '.' in filename else 'unknown'
                        event_type = f"file_{ext}"
                        path = filename
                        
                    elif event_src == 'http':
                        url = parts[5].strip('"').lower() if len(parts) > 5 else ''
                        activity = parts[6].strip('"').lower() if len(parts) > 6 else ''
                        
                        # DETECT SMOKING GUNS!
                        if 'wikileaks' in url:
                            event_type = 'http_WIKILEAKS_upload'
                            wikileaks_count += 1
                        elif 'dropbox' in url:
                            event_type = 'http_DROPBOX_upload'
                            dropbox_count += 1
                        elif 'upload' in activity or 'www upload' in activity:
                            event_type = 'http_upload'
                        elif 'download' in activity:
                            event_type = 'http_download'
                        else:
                            event_type = 'http_browse'
                        
                        path = url[:200]
                    else:
                        continue
                    
                    all_events.append({
                        'user_id': user,
                        'timestamp': timestamp,
                        'event_type': event_type,
                        'device': device,
                        'ip_address': '',
                        'path': path,
                        'source': f'scenario_{scenario_file}'
                    })
                    
                except Exception as e:
                    continue
            
            print(f"        ✅ Loaded")
            
        except Exception as e:
            print(f"        ❌ Error: {e}")
    
    print(f"\n  🎯 Scenario Summary:")
    print(f"     Malicious users found: {len(malicious_users)}")
    print(f"     WikiLeaks uploads: {wikileaks_count} {'✅' if wikileaks_count > 0 else '❌'}")
    print(f"     Dropbox uploads: {dropbox_count} {'✅' if dropbox_count > 0 else '❌'}")
    
    # ========================================================================
    # 3. Create DataFrame - PRIORITIZE MALICIOUS USERS
    # ========================================================================
    print(f"\n  🔧 Creating unified DataFrame...")
    df = pd.DataFrame(all_events)
    
    print(f"     Total events: {len(df):,}")
    print(f"     Sources: {df['source'].value_counts().to_dict()}")
    
    # Convert timestamps
    df['timestamp'] = pd.to_datetime(df['timestamp'], errors='coerce', utc=True)
    df = df.dropna(subset=['timestamp'])
    
    # Filter to valid date range
    valid_start = pd.Timestamp('2009-01-01', tz='UTC')
    valid_end = pd.Timestamp('2012-12-31', tz='UTC')
    df = df[(df['timestamp'] >= valid_start) & (df['timestamp'] <= valid_end)]
    
    # Clean user IDs
    df = df[df['user_id'].notna() & (df['user_id'] != '') & 
            (df['user_id'] != 'nan') & (df['user_id'] != 'None')]
    
    print(f"     Events after timestamp filtering: {len(df):,}")
    
    # CRITICAL: Split into malicious and normal BEFORE limiting
    df_malicious = df[df['user_id'].isin(malicious_users)]
    df_normal = df[~df['user_id'].isin(malicious_users)]
    
    print(f"\n  🎯 Splitting dataset:")
    print(f"     Malicious user events: {len(df_malicious):,}")
    print(f"     Normal user events: {len(df_normal):,}")
    
    # Take ALL malicious events + top normal users to fill quota
    if len(df_normal) > 0:
        # Get top normal users by activity
        normal_user_counts = df_normal['user_id'].value_counts()
        remaining_quota = max_events - len(df_malicious)
        
        if remaining_quota > 0:
            # Take top normal users
            top_normal_users = normal_user_counts.head(max_users - len(malicious_users)).index.tolist()
            df_normal_filtered = df_normal[df_normal['user_id'].isin(top_normal_users)]
            
            # Limit normal events to remaining quota
            if len(df_normal_filtered) > remaining_quota:
                df_normal_filtered = df_normal_filtered.head(remaining_quota)
            
            print(f"     Normal users selected: {len(top_normal_users)}")
            print(f"     Normal events kept: {len(df_normal_filtered):,}")
        else:
            df_normal_filtered = pd.DataFrame()
    else:
        df_normal_filtered = pd.DataFrame()
    
    # Combine: ALL malicious + sampled normal
    df = pd.concat([df_malicious, df_normal_filtered], ignore_index=True)
    df = df.sort_values(['user_id', 'timestamp']).reset_index(drop=True)
    
    print(f"\n  ✅ Final dataset:")
    print(f"     Total events: {len(df):,}")
    print(f"     Total users: {df['user_id'].nunique()}")
    print(f"     Malicious users with events: {df[df['user_id'].isin(malicious_users)]['user_id'].nunique()}")
    
    # Generate IPs
    device_to_ip = {}
    for device in df['device'].unique():
        if device and device != '' and device != 'nan':
            parts = str(device).split('-')
            if len(parts) == 2 and parts[0] == 'PC':
                try:
                    num = int(parts[1])
                    device_to_ip[device] = f"10.{(num >> 8) & 255}.{num & 255}.{np.random.randint(1, 255)}"
                except:
                    device_to_ip[device] = f"10.{np.random.randint(1, 255)}.{np.random.randint(1, 255)}.{np.random.randint(1, 255)}"
    
    df['ip_address'] = df['device'].map(device_to_ip).fillna('')
    
    # ========================================================================
    # 4. Create Ground Truth
    # ========================================================================
    print(f"\n  📋 Creating ground truth...")
    gt_df = pd.DataFrame({
        'user': malicious_users,
        'scenario': list(range(1, len(malicious_users) + 1))
    })
    
    print(f"     Malicious users: {len(gt_df)}")
    
    # ========================================================================
    # 5. Summary
    # ========================================================================
    print(f"\n" + "="*70)
    print("DATASET SUMMARY")
    print("="*70)
    print(f"  Total events: {len(df):,}")
    print(f"  Users: {df['user_id'].nunique()}")
    print(f"  Event types: {df['event_type'].nunique()}")
    print(f"  Date range: {df['timestamp'].min()} to {df['timestamp'].max()}")
    
    print(f"\n  Top 15 Event Types:")
    for event, count in df['event_type'].value_counts().head(15).items():
        pct = count / len(df) * 100
        marker = "🔴" if "WIKILEAKS" in event or "DROPBOX" in event else ""
        print(f"    {marker} {event:30s} {count:8,} ({pct:5.2f}%)")
    
    print(f"\n  🚨 Smoking Gun Detection:")
    wikileaks = len(df[df['event_type'] == 'http_WIKILEAKS_upload'])
    dropbox = len(df[df['event_type'] == 'http_DROPBOX_upload'])
    print(f"    WikiLeaks uploads: {wikileaks:,} {'✅' if wikileaks > 0 else '❌'}")
    print(f"    Dropbox uploads: {dropbox:,} {'✅' if dropbox > 0 else '❌'}")
    
    return df, gt_df


if __name__ == "__main__":
    cert_path = r"F:\Projects\Security\cert\r6.2"
    df, gt = load_cert_with_scenarios(cert_path)
    
    print(f"\n✅ Dataset ready!")
    print(f"   Events: {len(df):,}")
    print(f"   Malicious users: {len(gt)}")

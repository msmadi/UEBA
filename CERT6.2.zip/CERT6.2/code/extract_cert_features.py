#!/usr/bin/env python3
"""
CERT Feature Extraction Script
Extracts features once and saves to disk for reuse

This script:
1. Loads CERT dataset
2. Constructs windows
3. Extracts all features (Hadith + Temporal)
4. Saves to pickle files for fast reloading

USAGE:
======
python extract_cert_features.py

Output:
- cert_features/windows.pkl
- cert_features/features_hadith.npy
- cert_features/features_temporal.npy
- cert_features/features_combined.npy
- cert_features/labels.npy
- cert_features/metadata.json
"""

import os
import sys
import numpy as np
import pandas as pd
import pickle
import json
from datetime import datetime

# Add path for imports
sys.path.insert(0, r'F:\Projects\Security')

# Import feature extraction functions
try:
    from compare_features_temporal_FULL import (
        construct_windows,
        build_user_history,
        build_transition_matrices,
        build_hadith_features,
        build_temporal_sequence_features,
    )
    print("✅ Imported feature functions from compare_features_temporal_FULL.py")
except ImportError as e:
    print(f"❌ ERROR: Cannot import feature functions")
    print(f"   Error: {e}")
    print("\n   Please ensure compare_features_temporal_FULL.py has these functions:")
    print("   - construct_windows")
    print("   - build_user_history")
    print("   - build_transition_matrices")
    print("   - build_hadith_features")
    print("   - build_temporal_sequence_features")
    sys.exit(1)

# Import data loading - use scenario-based loader
try:
    from load_cert_scenarios import load_cert_with_scenarios
    print("✅ Imported scenario-based loader")
    
    # Also need these helper functions
    import pandas as pd
    
    def ensure_df_timestamp_utc(df):
        """Ensure timestamps are UTC-aware."""
        if "timestamp" not in df.columns:
            return df
        df = df.copy()
        df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce", utc=True)
        df = df.dropna(subset=["timestamp"])
        df = df.sort_values(["user_id", "timestamp"]).reset_index(drop=True)
        return df
    
    def label_windows(windows, hijack_df):
        """Label windows as hijacked (1) or normal (0)."""
        if hijack_df is None or hijack_df.empty:
            return np.zeros(len(windows), dtype=int)
        
        h = hijack_df.copy()
        h["start"] = pd.to_datetime(h["start"], errors="coerce", utc=True)
        h["end"] = pd.to_datetime(h["end"], errors="coerce", utc=True)
        h = h.dropna(subset=["user_id", "start", "end"])
        
        labels = []
        for w in windows:
            uid = w["user_id"]
            ws = pd.to_datetime(w["start_time"], utc=True)
            we = pd.to_datetime(w["end_time"], utc=True)
            
            intervals = h[h["user_id"] == uid]
            is_hijacked = 0
            
            for _, row in intervals.iterrows():
                if not (we < row["start"] or ws > row["end"]):
                    is_hijacked = 1
                    break
            
            labels.append(is_hijacked)
        
        return np.array(labels, dtype=int)
    
    print("✅ Helper functions loaded")
    
except ImportError as e:
    print(f"❌ ERROR: Cannot import scenario-based loader")
    print(f"   Error: {e}")
    print("\n   Please ensure load_cert_scenarios.py is in:")
    print("   F:\\Projects\\Security\\")
    sys.exit(1)


def extract_and_save_features(cert_path, output_dir, max_events=1_500_000, max_users=200):
    """
    Extract features from CERT dataset and save to disk.
    
    Args:
        cert_path: Path to CERT directory
        output_dir: Directory to save features
        max_events: Maximum events to load
        max_users: Maximum users
    
    Returns:
        dict: Metadata about extracted features
    """
    
    print("="*70)
    print("CERT FEATURE EXTRACTION")
    print("="*70)
    print(f"\nConfiguration:")
    print(f"  CERT Path: {cert_path}")
    print(f"  Output Directory: {output_dir}")
    print(f"  Max Events: {max_events:,}")
    print(f"  Max Users: {max_users}")
    
    os.makedirs(output_dir, exist_ok=True)
    
    # -------------------------------------------------------------------------
    # STEP 1: Load Dataset
    # -------------------------------------------------------------------------
    print("\n" + "="*70)
    print("STEP 1: LOADING DATASET")
    print("="*70)
    
    df, gt_df = load_cert_with_scenarios(cert_path, max_events, max_users)
    
    if df is None or df.empty:
        print("❌ ERROR: Failed to load dataset")
        return None
    
    df = ensure_df_timestamp_utc(df)
    
    # -------------------------------------------------------------------------
    # STEP 2: Ground Truth
    # -------------------------------------------------------------------------
    print("\n" + "="*70)
    print("STEP 2: PROCESSING GROUND TRUTH")
    print("="*70)
    
    hijack_df = None
    
    if gt_df is not None and not gt_df.empty:
        print(f"\n✅ Found ground truth: {len(gt_df)} rows")
        
        # Find user column
        user_col = None
        for col in ['user', 'user_id', 'userid']:
            if col in gt_df.columns:
                user_col = col
                break
        
        if user_col:
            malicious_users = gt_df[user_col].unique()
            print(f"   Malicious users: {list(malicious_users)}")
            
            # Create intervals
            intervals = []
            for user_id in malicious_users:
                user_events = df[df['user_id'] == str(user_id)]
                if len(user_events) > 0:
                    intervals.append({
                        'user_id': str(user_id),
                        'start': user_events['timestamp'].min(),
                        'end': user_events['timestamp'].max()
                    })
            
            if intervals:
                hijack_df = pd.DataFrame(intervals)
                hijack_df['start'] = pd.to_datetime(hijack_df['start'], utc=True)
                hijack_df['end'] = pd.to_datetime(hijack_df['end'], utc=True)
                print(f"   ✅ Created {len(hijack_df)} intervals")
    
    if hijack_df is None or hijack_df.empty:
        print("\n❌ ERROR: No ground truth available")
        return None
    
    # -------------------------------------------------------------------------
    # STEP 3: Construct Windows
    # -------------------------------------------------------------------------
    print("\n" + "="*70)
    print("STEP 3: CONSTRUCTING WINDOWS")
    print("="*70)
    
    print("\n  Creating windows (size=50, step=25)...")
    windows = construct_windows(df, window_size=50, step_size=25)
    print(f"  ✅ Created {len(windows):,} windows")
    
    # Label windows
    print("\n  Labeling windows...")
    y = label_windows(windows, hijack_df)
    pos = int(y.sum())
    neg = len(y) - pos
    
    print(f"  ✅ Labels created:")
    print(f"     Positive: {pos:,} ({pos/len(y)*100:.2f}%)")
    print(f"     Negative: {neg:,} ({neg/len(y)*100:.2f}%)")
    
    if pos < 2:
        print("\n❌ ERROR: Not enough positive samples")
        return None
    
    # -------------------------------------------------------------------------
    # STEP 4: Extract Features
    # -------------------------------------------------------------------------
    print("\n" + "="*70)
    print("STEP 4: EXTRACTING FEATURES")
    print("="*70)
    
    print("\n  Building user history...")
    user_history = build_user_history(df)
    
    all_event_types = df["event_type"].unique()
    print(f"  Event types: {len(all_event_types)}")
    
    print("  Building transition matrices...")
    user_transitions = build_transition_matrices(df, all_event_types)
    
    # Hadith features (26)
    print("\n  Extracting Hadith features (26)...")
    print(f"  Processing {len(windows):,} windows...")
    
    X_hadith = []
    for i, w in enumerate(windows):
        if i % 2000 == 0 and i > 0:
            print(f"    Progress: {i:,}/{len(windows):,} ({i/len(windows)*100:.1f}%)")
        X_hadith.append(build_hadith_features(w, df, user_history, all_event_types))
    
    X_hadith = np.nan_to_num(np.array(X_hadith), nan=0, posinf=0, neginf=0)
    print(f"  ✅ Hadith features: {X_hadith.shape}")
    
    # Temporal features (16)
    print("\n  Extracting Temporal features (16)...")
    
    X_temporal = []
    for i, w in enumerate(windows):
        if i % 2000 == 0 and i > 0:
            print(f"    Progress: {i:,}/{len(windows):,} ({i/len(windows)*100:.1f}%)")
        X_temporal.append(
            build_temporal_sequence_features(w, df, user_history, all_event_types, user_transitions)
        )
    
    X_temporal = np.nan_to_num(np.array(X_temporal), nan=0, posinf=0, neginf=0)
    print(f"  ✅ Temporal features: {X_temporal.shape}")
    
    # Combined (42)
    X_combined = np.nan_to_num(np.hstack([X_hadith, X_temporal]), nan=0, posinf=0, neginf=0)
    print(f"  ✅ Combined features: {X_combined.shape}")
    
    # -------------------------------------------------------------------------
    # STEP 5: Save to Disk
    # -------------------------------------------------------------------------
    print("\n" + "="*70)
    print("STEP 5: SAVING FEATURES TO DISK")
    print("="*70)
    
    # Save windows
    windows_file = os.path.join(output_dir, 'windows.pkl')
    with open(windows_file, 'wb') as f:
        pickle.dump(windows, f)
    print(f"\n  ✅ Saved windows: {windows_file}")
    
    # Save features
    hadith_file = os.path.join(output_dir, 'features_hadith.npy')
    np.save(hadith_file, X_hadith)
    print(f"  ✅ Saved Hadith features: {hadith_file}")
    
    temporal_file = os.path.join(output_dir, 'features_temporal.npy')
    np.save(temporal_file, X_temporal)
    print(f"  ✅ Saved Temporal features: {temporal_file}")
    
    combined_file = os.path.join(output_dir, 'features_combined.npy')
    np.save(combined_file, X_combined)
    print(f"  ✅ Saved Combined features: {combined_file}")
    
    # Save labels
    labels_file = os.path.join(output_dir, 'labels.npy')
    np.save(labels_file, y)
    print(f"  ✅ Saved labels: {labels_file}")
    
    # Save metadata
    metadata = {
        'extraction_date': datetime.now().isoformat(),
        'cert_path': cert_path,
        'max_events': max_events,
        'max_users': max_users,
        'total_events': len(df),
        'total_users': int(df['user_id'].nunique()),
        'total_windows': len(windows),
        'positive_windows': int(pos),
        'negative_windows': int(neg),
        'positive_rate': float(pos / len(y)),
        'hadith_features': 26,
        'temporal_features': 16,
        'combined_features': 42,
        'event_types': int(len(all_event_types)),
        'date_range': {
            'min': str(df['timestamp'].min()),
            'max': str(df['timestamp'].max())
        },
        'malicious_users': hijack_df['user_id'].tolist(),
        'feature_names': {
            'hadith': [
                "adalah_active_days", "adalah_total_events", "adalah_account_age",
                "adalah_consistency", "adalah_avg_events",
                "dabt_login_success", "dabt_delta_fail", "dabt_burstiness",
                "dabt_outside_hours", "dabt_timing_entropy", "dabt_vocab_div",
                "dabt_sensitive_ratio",
                "isnad_ip_consistency", "isnad_ip_match", "isnad_subnet_match",
                "isnad_geo_impossible", "isnad_session_discont", "isnad_new_ip_rate",
                "rep_duration", "rep_trust", "rep_penalty", "rep_trend",
                "anom_kl_div", "anom_hour", "anom_path", "anom_l2_dist"
            ],
            'temporal': [
                "temp_kl_transition", "temp_rare_transitions", "temp_seq_entropy",
                "temp_ngram_anomaly", "temp_run_anomaly",
                "temp_behavior_drift", "temp_autocorr", "temp_timing_shift",
                "temp_dow_divergence", "temp_rate_drift",
                "temp_subnet_drift", "temp_ip_switch_rate", "temp_device_trans_anom",
                "temp_failure_trend", "temp_cumul_suspicious", "temp_risk_accel"
            ]
        }
    }
    
    metadata_file = os.path.join(output_dir, 'metadata.json')
    with open(metadata_file, 'w') as f:
        json.dump(metadata, f, indent=2)
    print(f"  ✅ Saved metadata: {metadata_file}")
    
    # -------------------------------------------------------------------------
    # SUMMARY
    # -------------------------------------------------------------------------
    print("\n" + "="*70)
    print("✅ FEATURE EXTRACTION COMPLETE!")
    print("="*70)
    
    print(f"\nSaved files in: {output_dir}")
    print(f"  - windows.pkl ({len(windows):,} windows)")
    print(f"  - features_hadith.npy (shape: {X_hadith.shape})")
    print(f"  - features_temporal.npy (shape: {X_temporal.shape})")
    print(f"  - features_combined.npy (shape: {X_combined.shape})")
    print(f"  - labels.npy (shape: {y.shape})")
    print(f"  - metadata.json")
    
    file_sizes = {
        'windows': os.path.getsize(windows_file) / (1024**2),
        'hadith': os.path.getsize(hadith_file) / (1024**2),
        'temporal': os.path.getsize(temporal_file) / (1024**2),
        'combined': os.path.getsize(combined_file) / (1024**2),
        'labels': os.path.getsize(labels_file) / (1024**2),
    }
    
    total_size = sum(file_sizes.values())
    print(f"\nTotal size: {total_size:.2f} MB")
    
    print("\n📊 Feature Statistics:")
    print(f"  Windows: {len(windows):,}")
    print(f"  Positive: {pos:,} ({pos/len(y)*100:.2f}%)")
    print(f"  Hadith features: {X_hadith.shape[1]}")
    print(f"  Temporal features: {X_temporal.shape[1]}")
    print(f"  Combined features: {X_combined.shape[1]}")
    
    print("\n✅ Features are ready for training!")
    print("   Use load_cert_features.py to load them quickly.")
    
    return metadata


def main():
    """Main execution."""
    
    CERT_PATH = r"F:\Projects\Security\cert\r6.2"
    OUTPUT_DIR = r"F:\Projects\Security\cert_features"
    
    # Extract and save
    metadata = extract_and_save_features(
        cert_path=CERT_PATH,
        output_dir=OUTPUT_DIR,
        max_events=1_500_000,
        max_users=200
    )
    
    if metadata:
        print("\n" + "="*70)
        print("NEXT STEPS")
        print("="*70)
        print("\n1. Features are extracted and saved!")
        print(f"2. Use load_cert_features.py to load them instantly")
        print(f"3. Train models without re-extracting features")
        print(f"\nExample:")
        print(f"  from load_cert_features import load_features")
        print(f"  X_hadith, X_temporal, X_combined, y = load_features('{OUTPUT_DIR}')")


if __name__ == "__main__":
    main()

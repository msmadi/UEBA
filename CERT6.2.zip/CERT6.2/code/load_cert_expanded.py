#!/usr/bin/env python3
"""
CERT Expanded Dataset Loader for Publication

Loads a larger, more comprehensive dataset:
- 1-2M events (vs current 66K)
- More diverse event types
- Better temporal coverage
- All 29 malicious users preserved
"""

import os
import pandas as pd
import numpy as np
from datetime import datetime


def load_cert_expanded(cert_path, target_events=1_500_000, max_users=500):
    """
    Load expanded CERT dataset for stronger publication results.
    
    Changes from basic loader:
    - 1.5M events (vs 66K) - 20x larger
    - 500 users (vs 200) - more diversity
    - More logon/device/file events
    - Preserves all malicious user events
    
    Args:
        cert_path: Path to CERT directory
        target_events: Target number of events (default 1.5M)
        max_users: Maximum users (default 500)
        
    Returns:
        df: DataFrame with events
        gt_df: Ground truth
    """
    
    print("="*70)
    print("CERT EXPANDED LOADER - PUBLICATION VERSION")
    print("="*70)
    print(f"  Target: {target_events:,} events from {max_users} users")
    print(f"  Goal: Stronger statistical power for publication")
    
    all_events = []
    
    # ========================================================================
    # 1. MAIN FILES - Load MORE data for diversity
    # ========================================================================
    
    # LOGON - Increase to 1M rows (was 500K)
    logon_file = os.path.join(cert_path, 'logon.csv')
    if os.path.exists(logon_file):
        print(f"\n  📂 Loading logon.csv (1M rows)...")
        logon_df = pd.read_csv(logon_file, on_bad_lines='skip', nrows=1_000_000)
        print(f"     Rows: {len(logon_df):,}")
        
        for _, row in logon_df.iterrows():
            try:
                activity = str(row.iloc[5]).strip().strip('"')
                all_events.append({
                    'user_id': str(row.iloc[3]).strip().strip('"'),
                    'timestamp': str(row.iloc[2]).strip().strip('"'),
                    'event_type': f"logon_{activity}",
                    'device': str(row.iloc[4]).strip().strip('"'),
                    'ip_address': '',
                    'path': '',
                    'source': 'logon'
                })
            except:
                continue
    
    # DEVICE - Increase to 500K (was 300K)
    device_file = os.path.join(cert_path, 'device.csv')
    if os.path.exists(device_file):
        print(f"\n  📂 Loading device.csv (500K rows)...")
        device_df = pd.read_csv(device_file, on_bad_lines='skip', nrows=500_000)
        print(f"     Rows: {len(device_df):,}")
        
        for _, row in device_df.iterrows():
            try:
                activity = str(row.iloc[6]).strip().strip('"') if len(row) > 6 else 'Unknown'
                all_events.append({
                    'user_id': str(row.iloc[3]).strip().strip('"'),
                    'timestamp': str(row.iloc[2]).strip().strip('"'),
                    'event_type': f"device_{activity}",
                    'device': str(row.iloc[4]).strip().strip('"'),
                    'ip_address': '',
                    'path': str(row.iloc[5]).strip().strip('"') if len(row) > 5 else '',
                    'source': 'device'
                })
            except:
                continue
    
    # FILE - Increase to 400K (was 200K)
    file_file = os.path.join(cert_path, 'file.csv')
    if os.path.exists(file_file):
        print(f"\n  📂 Loading file.csv (400K rows)...")
        file_df = pd.read_csv(file_file, on_bad_lines='skip', nrows=400_000)
        print(f"     Rows: {len(file_df):,}")
        
        for _, row in file_df.iterrows():
            try:
                filename = str(row.iloc[5]).strip().strip('"') if len(row) > 5 else ''
                ext = filename.split('.')[-1].lower() if '.' in filename else 'unknown'
                all_events.append({
                    'user_id': str(row.iloc[3]).strip().strip('"'),
                    'timestamp': str(row.iloc[2]).strip().strip('"'),
                    'event_type': f"file_{ext}",
                    'device': str(row.iloc[4]).strip().strip('"'),
                    'ip_address': '',
                    'path': filename,
                    'source': 'file'
                })
            except:
                continue
    
    # EMAIL - Add email data (NEW!)
    email_file = os.path.join(cert_path, 'email.csv')
    if os.path.exists(email_file):
        print(f"\n  📧 Loading email.csv (200K rows)...")
        email_df = pd.read_csv(email_file, on_bad_lines='skip', nrows=200_000)
        print(f"     Rows: {len(email_df):,}")
        
        for _, row in email_df.iterrows():
            try:
                attachments = str(row.iloc[10]).strip() if len(row) > 10 else ''
                event_type = 'email_send_attachment' if attachments and attachments != '' else 'email_send'
                
                all_events.append({
                    'user_id': str(row.iloc[2]).strip().strip('"'),
                    'timestamp': str(row.iloc[1]).strip().strip('"'),
                    'event_type': event_type,
                    'device': str(row.iloc[3]).strip().strip('"'),
                    'ip_address': '',
                    'path': str(row.iloc[4]).strip()[:100] if len(row) > 4 else '',
                    'source': 'email'
                })
            except:
                continue
    
    # HTTP - Keep at 500K but sample more diversely
    http_file = os.path.join(cert_path, 'http.csv')
    if os.path.exists(http_file):
        print(f"\n  🌐 Loading http.csv (500K rows, stratified)...")
        # Read in chunks and sample downloads/uploads more
        http_df = pd.read_csv(http_file, on_bad_lines='skip', nrows=500_000)
        print(f"     Rows: {len(http_df):,}")
        
        for _, row in http_df.iterrows():
            try:
                timestamp_str = str(row.iloc[1]).strip()
                url = str(row.iloc[5]).strip().lower() if len(row) > 5 else ''
                activity = str(row.iloc[6]).strip().lower() if len(row) > 6 else ''
                
                url = url.strip('"').strip("'")
                activity = activity.strip('"').strip("'")
                
                event_type = 'http_browse'
                if 'upload' in activity or 'www upload' in activity.lower():
                    event_type = 'http_upload'
                elif 'download' in activity:
                    event_type = 'http_download'
                
                all_events.append({
                    'user_id': str(row.iloc[2]).strip().strip('"') if len(row) > 2 else '',
                    'timestamp': timestamp_str,
                    'event_type': event_type,
                    'device': str(row.iloc[3]).strip().strip('"') if len(row) > 3 else '',
                    'ip_address': '',
                    'path': url[:200],
                    'source': 'http'
                })
            except:
                continue
    
    # ========================================================================
    # 2. SCENARIO FILES - KEEP ALL (unchanged)
    # ========================================================================
    print(f"\n  🔴 Loading malicious scenario files...")
    
    scenario_files = {
        'r6.2-1.csv': 'ACM2278',
        'r6.2-2.csv': 'CMP2946',
        'r6.2-3.csv': 'Scenario3',
        'r6.2-4.csv': 'CDE1846',
        'r6.2-5.csv': 'MBG3183',
    }
    
    malicious_users = []
    wikileaks_count = 0
    dropbox_count = 0
    
    for scenario_file, scenario_name in scenario_files.items():
        scenario_path = os.path.join(cert_path, scenario_file)
        
        if not os.path.exists(scenario_path):
            continue
        
        print(f"\n     📋 Loading {scenario_file} ({scenario_name})...")
        
        try:
            with open(scenario_path, 'r', encoding='utf-8', errors='ignore') as f:
                lines = f.readlines()
            
            print(f"        Rows: {len(lines):,}")
            
            for line in lines:
                try:
                    parts = line.strip().split(',')
                    if len(parts) < 4:
                        continue
                    
                    event_src = parts[0].strip()
                    timestamp = parts[2].strip('"')
                    user = parts[3].strip('"')
                    device = parts[4].strip('"') if len(parts) > 4 else ''
                    
                    if user not in malicious_users:
                        malicious_users.append(user)
                    
                    if event_src == 'logon':
                        activity = parts[5].strip('"') if len(parts) > 5 else 'Logon'
                        event_type = f"logon_{activity}"
                        path = ''
                    elif event_src == 'device':
                        activity = parts[6].strip('"') if len(parts) > 6 else 'Unknown'
                        event_type = f"device_{activity}"
                        path = parts[5].strip('"') if len(parts) > 5 else ''
                    elif event_src == 'file':
                        filename = parts[5].strip('"') if len(parts) > 5 else ''
                        ext = filename.split('.')[-1].lower() if '.' in filename else 'unknown'
                        event_type = f"file_{ext}"
                        path = filename
                    elif event_src == 'http':
                        url = parts[5].strip('"').lower() if len(parts) > 5 else ''
                        activity = parts[6].strip('"').lower() if len(parts) > 6 else ''
                        
                        if 'wikileaks' in url:
                            event_type = 'http_WIKILEAKS_upload'
                            wikileaks_count += 1
                        elif 'dropbox' in url:
                            event_type = 'http_DROPBOX_upload'
                            dropbox_count += 1
                        elif 'upload' in activity or 'www upload' in activity:
                            event_type = 'http_upload'
                        elif 'download' in activity:
                            event_type = 'http_download'
                        else:
                            event_type = 'http_browse'
                        
                        path = url[:200]
                    else:
                        continue
                    
                    all_events.append({
                        'user_id': user,
                        'timestamp': timestamp,
                        'event_type': event_type,
                        'device': device,
                        'ip_address': '',
                        'path': path,
                        'source': f'scenario_{scenario_file}'
                    })
                    
                except:
                    continue
            
            print(f"        ✅ Loaded")
            
        except Exception as e:
            print(f"        ❌ Error: {e}")
    
    print(f"\n  🎯 Scenario Summary:")
    print(f"     Malicious users found: {len(malicious_users)}")
    print(f"     WikiLeaks uploads: {wikileaks_count} {'✅' if wikileaks_count > 0 else '❌'}")
    print(f"     Dropbox uploads: {dropbox_count} {'✅' if dropbox_count > 0 else '❌'}")
    
    # ========================================================================
    # 3. Create DataFrame - PRIORITIZE MALICIOUS
    # ========================================================================
    print(f"\n  🔧 Creating unified DataFrame...")
    df = pd.DataFrame(all_events)
    
    print(f"     Total events: {len(df):,}")
    
    # Convert timestamps
    df['timestamp'] = pd.to_datetime(df['timestamp'], errors='coerce', utc=True)
    df = df.dropna(subset=['timestamp'])
    
    # Filter to valid date range
    valid_start = pd.Timestamp('2009-01-01', tz='UTC')
    valid_end = pd.Timestamp('2012-12-31', tz='UTC')
    df = df[(df['timestamp'] >= valid_start) & (df['timestamp'] <= valid_end)]
    
    # Clean user IDs
    df = df[df['user_id'].notna() & (df['user_id'] != '') & 
            (df['user_id'] != 'nan') & (df['user_id'] != 'None')]
    
    print(f"     Events after filtering: {len(df):,}")
    
    # Split malicious/normal
    df_malicious = df[df['user_id'].isin(malicious_users)]
    df_normal = df[~df['user_id'].isin(malicious_users)]
    
    print(f"\n  🎯 Splitting dataset:")
    print(f"     Malicious user events: {len(df_malicious):,}")
    print(f"     Normal user events: {len(df_normal):,}")
    
    # Take ALL malicious + fill with normal
    remaining_quota = target_events - len(df_malicious)
    
    if remaining_quota > 0 and len(df_normal) > 0:
        normal_user_counts = df_normal['user_id'].value_counts()
        top_normal_users = normal_user_counts.head(max_users - len(malicious_users)).index.tolist()
        df_normal_filtered = df_normal[df_normal['user_id'].isin(top_normal_users)]
        
        if len(df_normal_filtered) > remaining_quota:
            df_normal_filtered = df_normal_filtered.sample(n=remaining_quota, random_state=42)
        
        print(f"     Normal users selected: {len(top_normal_users)}")
        print(f"     Normal events kept: {len(df_normal_filtered):,}")
    else:
        df_normal_filtered = pd.DataFrame()
    
    # Combine
    df = pd.concat([df_malicious, df_normal_filtered], ignore_index=True)
    df = df.sort_values(['user_id', 'timestamp']).reset_index(drop=True)
    
    print(f"\n  ✅ Final dataset:")
    print(f"     Total events: {len(df):,}")
    print(f"     Total users: {df['user_id'].nunique()}")
    print(f"     Malicious users: {df[df['user_id'].isin(malicious_users)]['user_id'].nunique()}")
    
    # Generate IPs
    device_to_ip = {}
    for device in df['device'].unique():
        if device and device != '' and device != 'nan':
            parts = str(device).split('-')
            if len(parts) == 2 and parts[0] == 'PC':
                try:
                    num = int(parts[1])
                    device_to_ip[device] = f"10.{(num >> 8) & 255}.{num & 255}.{np.random.randint(1, 255)}"
                except:
                    device_to_ip[device] = f"10.{np.random.randint(1, 255)}.{np.random.randint(1, 255)}.{np.random.randint(1, 255)}"
    
    df['ip_address'] = df['device'].map(device_to_ip).fillna('')
    
    # Ground truth
    print(f"\n  📋 Creating ground truth...")
    gt_df = pd.DataFrame({
        'user': malicious_users,
        'scenario': list(range(1, len(malicious_users) + 1))
    })
    
    # Summary
    print(f"\n" + "="*70)
    print("DATASET SUMMARY")
    print("="*70)
    print(f"  Total events: {len(df):,}")
    print(f"  Users: {df['user_id'].nunique()}")
    print(f"  Event types: {df['event_type'].nunique()}")
    print(f"  Date range: {df['timestamp'].min()} to {df['timestamp'].max()}")
    print(f"  Sources: {df['source'].nunique()}")
    
    print(f"\n  Top 20 Event Types:")
    for event, count in df['event_type'].value_counts().head(20).items():
        pct = count / len(df) * 100
        marker = "🔴" if "WIKILEAKS" in event or "DROPBOX" in event else ""
        print(f"    {marker} {event:35s} {count:8,} ({pct:5.2f}%)")
    
    print(f"\n  🚨 Smoking Gun Detection:")
    wikileaks = len(df[df['event_type'] == 'http_WIKILEAKS_upload'])
    dropbox = len(df[df['event_type'] == 'http_DROPBOX_upload'])
    print(f"    WikiLeaks uploads: {wikileaks:,} {'✅' if wikileaks > 0 else '❌'}")
    print(f"    Dropbox uploads: {dropbox:,} {'✅' if dropbox > 0 else '❌'}")
    
    return df, gt_df


if __name__ == "__main__":
    cert_path = r"F:\Projects\Security\cert\r6.2"
    df, gt = load_cert_expanded(cert_path, target_events=1_500_000, max_users=500)
    
    print(f"\n✅ Expanded dataset ready!")
    print(f"   Events: {len(df):,}")
    print(f"   Users: {df['user_id'].nunique()}")
    print(f"   Malicious: {len(gt)}")

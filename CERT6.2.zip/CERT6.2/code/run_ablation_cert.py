#!/usr/bin/env python3
"""
Standalone Ablation Analysis for CERT r6.2
Run this after training to get detailed ablation study

USAGE:
======
python run_ablation_cert.py
"""

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import roc_auc_score, average_precision_score, f1_score

RANDOM_STATE = 42


def run_ablation_analysis(X_combined, X_hadith, X_temporal, y, 
                          combined_roc, orig_roc, temporal_roc):
    """
    Run detailed ablation study on extracted features.
    
    Args:
        X_combined: Combined features (N, 42)
        X_hadith: Original Hadith features (N, 26)
        X_temporal: Temporal features (N, 16)
        y: Labels (N,)
        combined_roc: ROC-AUC of combined model
        orig_roc: ROC-AUC of original model
        temporal_roc: ROC-AUC of temporal model
    
    Returns:
        DataFrame with ablation results
    """
    
    print("\n" + "="*80)
    print("DETAILED ABLATION STUDY - CERT r6.2")
    print("="*80)
    
    # Split data
    (X_c_train, X_c_test, y_train, y_test) = train_test_split(
        X_combined, y, test_size=0.3, stratify=y, random_state=RANDOM_STATE
    )
    
    print(f"\nTrain: {len(y_train):,} (Pos: {int(y_train.sum()):,})")
    print(f"Test:  {len(y_test):,} (Pos: {int(y_test.sum()):,})")
    
    # Feature indices for each axis
    axis_indices = {
        'Adalah': list(range(0, 5)),      # 5 features
        'Dabt': list(range(5, 12)),        # 7 features
        'Isnad': list(range(12, 18)),      # 6 features
        'Reputation': list(range(18, 22)), # 4 features
        'Anomaly': list(range(22, 26)),    # 4 features
        'Temporal_Dabt': list(range(26, 31)),      # 5 features
        'Temporal_Adalah': list(range(31, 36)),    # 5 features
        'Temporal_Isnad': list(range(36, 39)),     # 3 features
        'Temporal_Rep': list(range(39, 42)),       # 3 features
    }
    
    ablation_results = []
    
    # ========================================================================
    # 1. REMOVING INDIVIDUAL AXES
    # ========================================================================
    print("\n" + "="*80)
    print("1. REMOVING INDIVIDUAL AXES")
    print("="*80)
    print(f"\n{'Axis Removed':25s} {'Features':>10s} {'ROC-AUC':>10s} {'PR-AUC':>10s} {'F1':>10s} {'Δ ROC':>10s}")
    print("-" * 85)
    
    for axis_name, indices in axis_indices.items():
        # Create mask for all features EXCEPT this axis
        mask = np.ones(42, dtype=bool)
        mask[indices] = False
        
        X_ablated = X_combined[:, mask]
        X_abl_train = X_ablated[:(len(y_train))]
        X_abl_test = X_ablated[(len(y_train)):]
        
        # Get same train/test split
        (X_abl_tr, X_abl_te, y_tr, y_te) = train_test_split(
            X_ablated, y, test_size=0.3, stratify=y, random_state=RANDOM_STATE
        )
        
        # Scale
        scaler = StandardScaler()
        X_abl_tr = scaler.fit_transform(X_abl_tr)
        X_abl_te = scaler.transform(X_abl_te)
        
        # Train
        rf = RandomForestClassifier(n_estimators=100, class_weight='balanced',
                                    random_state=RANDOM_STATE, n_jobs=-1)
        rf.fit(X_abl_tr, y_tr)
        scores = rf.predict_proba(X_abl_te)[:, 1]
        
        # Evaluate
        roc_abl = roc_auc_score(y_te, scores)
        pr_abl = average_precision_score(y_te, scores)
        
        best_f1 = 0
        for thr in np.linspace(0, 1, 51):
            f1 = f1_score(y_te, (scores >= thr).astype(int), zero_division=0)
            best_f1 = max(best_f1, f1)
        
        delta = roc_abl - combined_roc
        n_features = 42 - len(indices)
        
        ablation_results.append({
            'Type': 'Remove',
            'Axis': axis_name,
            'Features': n_features,
            'ROC-AUC': roc_abl,
            'PR-AUC': pr_abl,
            'F1': best_f1,
            'Delta_ROC': delta
        })
        
        print(f"{axis_name:25s} {n_features:10d} {roc_abl:10.4f} {pr_abl:10.4f} {best_f1:10.4f} {delta:10.4f}")
    
    # ========================================================================
    # 2. SINGLE AXIS ONLY
    # ========================================================================
    print("\n" + "="*80)
    print("2. SINGLE-AXIS ONLY MODELS")
    print("="*80)
    print(f"\n{'Axis Used':25s} {'Features':>10s} {'ROC-AUC':>10s} {'PR-AUC':>10s} {'F1':>10s} {'Δ ROC':>10s}")
    print("-" * 85)
    
    for axis_name, indices in axis_indices.items():
        # Use ONLY this axis
        X_single = X_combined[:, indices]
        
        # Get same train/test split
        (X_sgl_tr, X_sgl_te, y_tr, y_te) = train_test_split(
            X_single, y, test_size=0.3, stratify=y, random_state=RANDOM_STATE
        )
        
        # Scale
        scaler = StandardScaler()
        X_sgl_tr = scaler.fit_transform(X_sgl_tr)
        X_sgl_te = scaler.transform(X_sgl_te)
        
        # Train
        rf = RandomForestClassifier(n_estimators=100, class_weight='balanced',
                                    random_state=RANDOM_STATE, n_jobs=-1)
        rf.fit(X_sgl_tr, y_tr)
        scores = rf.predict_proba(X_sgl_te)[:, 1]
        
        # Evaluate
        roc_sgl = roc_auc_score(y_te, scores)
        pr_sgl = average_precision_score(y_te, scores)
        
        best_f1 = 0
        for thr in np.linspace(0, 1, 51):
            f1 = f1_score(y_te, (scores >= thr).astype(int), zero_division=0)
            best_f1 = max(best_f1, f1)
        
        delta = roc_sgl - combined_roc
        
        ablation_results.append({
            'Type': 'Only',
            'Axis': axis_name,
            'Features': len(indices),
            'ROC-AUC': roc_sgl,
            'PR-AUC': pr_sgl,
            'F1': best_f1,
            'Delta_ROC': delta
        })
        
        print(f"{axis_name:25s} {len(indices):10d} {roc_sgl:10.4f} {pr_sgl:10.4f} {best_f1:10.4f} {delta:10.4f}")
    
    # ========================================================================
    # 3. SUMMARY
    # ========================================================================
    print("\n" + "="*80)
    print("ABLATION INSIGHTS")
    print("="*80)
    
    ablation_df = pd.DataFrame(ablation_results)
    
    # Most critical axis
    remove_results = ablation_df[ablation_df['Type'] == 'Remove'].sort_values('Delta_ROC')
    most_impactful = remove_results.iloc[0]
    
    print(f"\n🎯 Most Critical Axis (largest drop when removed):")
    print(f"   {most_impactful['Axis']}: ROC-AUC drops by {abs(most_impactful['Delta_ROC']):.4f}")
    print(f"   (Performance: {most_impactful['ROC-AUC']:.4f} with {most_impactful['Features']} features)")
    
    # Best single axis
    only_results = ablation_df[ablation_df['Type'] == 'Only'].sort_values('ROC-AUC', ascending=False)
    best_single = only_results.iloc[0]
    
    print(f"\n🏆 Best Single Axis:")
    print(f"   {best_single['Axis']}: ROC-AUC = {best_single['ROC-AUC']:.4f}")
    print(f"   ({best_single['Features']} features)")
    
    # Average by type
    orig_axes = ablation_df[(ablation_df['Type'] == 'Only') & 
                            (~ablation_df['Axis'].str.startswith('Temporal'))]
    temp_axes = ablation_df[(ablation_df['Type'] == 'Only') & 
                            (ablation_df['Axis'].str.startswith('Temporal'))]
    
    if len(orig_axes) > 0 and len(temp_axes) > 0:
        orig_avg = orig_axes['ROC-AUC'].mean()
        temp_avg = temp_axes['ROC-AUC'].mean()
        
        print(f"\n📊 Average Performance by Type:")
        print(f"   Original axes (5): {orig_avg:.4f}")
        print(f"   Temporal axes (4): {temp_avg:.4f}")
        print(f"   Difference: {temp_avg - orig_avg:+.4f}")
    
    # Save results
    import os
    output_dir = r"F:\Projects\Security\results_cert_complete"
    os.makedirs(output_dir, exist_ok=True)
    
    ablation_df.to_csv(os.path.join(output_dir, 'cert_ablation_detailed.csv'), index=False)
    print(f"\n✅ Saved: {output_dir}/cert_ablation_detailed.csv")
    
    return ablation_df


if __name__ == "__main__":
    print("="*80)
    print("STANDALONE ABLATION ANALYSIS")
    print("="*80)
    print("\nThis script requires pre-extracted features.")
    print("Load your features first, then call run_ablation_analysis()")
    print("\nExample:")
    print("  from load_cert_features import load_features")
    print("  X_hadith, X_temporal, X_combined, y, meta = load_features()")
    print("  from run_ablation_cert import run_ablation_analysis")
    print("  ablation_df = run_ablation_analysis(X_combined, X_hadith, X_temporal, y, 0.844, 0.776, 0.809)")

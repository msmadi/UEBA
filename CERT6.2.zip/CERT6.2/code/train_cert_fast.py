#!/usr/bin/env python3
"""
CERT Fast Training Script
Uses pre-extracted features for instant training

USAGE:
======
python train_cert_fast.py

This script loads pre-extracted features and trains models in seconds!
"""

import os
import sys
import numpy as np
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_auc_score, average_precision_score, classification_report
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier

import matplotlib.pyplot as plt
import seaborn as sns

# Load features
sys.path.insert(0, r'F:\Projects\Security')

try:
    from load_cert_features import load_features, get_feature_names
    print("✅ Feature loader imported")
except ImportError as e:
    print(f"❌ ERROR: Cannot import load_cert_features")
    print(f"   Error: {e}")
    print("   Make sure load_cert_features.py is in F:\\Projects\\Security")
    sys.exit(1)

RANDOM_STATE = 42
np.random.seed(RANDOM_STATE)


def train_and_evaluate():
    """Train models on pre-extracted features."""
    
    print("="*70)
    print("CERT FAST TRAINING - Using Pre-Extracted Features")
    print("="*70)
    
    # -------------------------------------------------------------------------
    # STEP 1: Load Features (INSTANT!)
    # -------------------------------------------------------------------------
    print("\n" + "="*70)
    print("STEP 1: LOADING FEATURES")
    print("="*70)
    
    X_hadith, X_temporal, X_combined, y, metadata = load_features()
    
    if X_hadith is None:
        print("\n❌ ERROR: Features not found!")
        print("   Please run extract_cert_features.py first.")
        return
    
    feature_names_dict = get_feature_names(metadata)
    feature_names = feature_names_dict['combined']
    
    # -------------------------------------------------------------------------
    # STEP 2: Train-Test Split
    # -------------------------------------------------------------------------
    print("\n" + "="*70)
    print("STEP 2: TRAIN-TEST SPLIT")
    print("="*70)
    
    (X_h_train, X_h_test, X_t_train, X_t_test, X_c_train, X_c_test,
     y_train, y_test) = train_test_split(
        X_hadith, X_temporal, X_combined, y,
        test_size=0.3,
        stratify=y,
        random_state=RANDOM_STATE
    )
    
    print(f"\n✅ Split complete:")
    print(f"   Train: {len(y_train):,} (Pos: {int(y_train.sum()):,}, {y_train.mean()*100:.2f}%)")
    print(f"   Test:  {len(y_test):,} (Pos: {int(y_test.sum()):,}, {y_test.mean()*100:.2f}%)")
    
    # -------------------------------------------------------------------------
    # STEP 3: Scale Features
    # -------------------------------------------------------------------------
    print("\n" + "="*70)
    print("STEP 3: SCALING FEATURES")
    print("="*70)
    
    scaler_h = StandardScaler()
    X_h_train_s = scaler_h.fit_transform(X_h_train)
    X_h_test_s = scaler_h.transform(X_h_test)
    
    scaler_t = StandardScaler()
    X_t_train_s = scaler_t.fit_transform(X_t_train)
    X_t_test_s = scaler_t.transform(X_t_test)
    
    scaler_c = StandardScaler()
    X_c_train_s = scaler_c.fit_transform(X_c_train)
    X_c_test_s = scaler_c.transform(X_c_test)
    
    print("\n✅ Features scaled (mean=0, std=1)")
    
    # -------------------------------------------------------------------------
    # STEP 4: Train Models
    # -------------------------------------------------------------------------
    print("\n" + "="*70)
    print("STEP 4: TRAINING MODELS")
    print("="*70)
    
    results = []
    
    # 1) Combined + RF
    print("\n  1/6: Combined + RandomForest...")
    rf_combined = RandomForestClassifier(
        n_estimators=100,
        class_weight="balanced",
        random_state=RANDOM_STATE,
        n_jobs=-1
    )
    rf_combined.fit(X_c_train_s, y_train)
    scores_c = rf_combined.predict_proba(X_c_test_s)[:, 1]
    roc_c = roc_auc_score(y_test, scores_c)
    pr_c = average_precision_score(y_test, scores_c)
    print(f"      ROC-AUC={roc_c:.4f}, PR-AUC={pr_c:.4f}")
    results.append(("Combined + RF", roc_c, pr_c))
    
    # 2) Combined + GB
    print("\n  2/6: Combined + GradientBoosting...")
    gb_combined = GradientBoostingClassifier(
        n_estimators=100,
        max_depth=5,
        random_state=RANDOM_STATE
    )
    gb_combined.fit(X_c_train_s, y_train)
    scores_c_gb = gb_combined.predict_proba(X_c_test_s)[:, 1]
    roc_c_gb = roc_auc_score(y_test, scores_c_gb)
    pr_c_gb = average_precision_score(y_test, scores_c_gb)
    print(f"      ROC-AUC={roc_c_gb:.4f}, PR-AUC={pr_c_gb:.4f}")
    results.append(("Combined + GB", roc_c_gb, pr_c_gb))
    
    # 3) Original + RF
    print("\n  3/6: Original Hadith + RF...")
    rf_hadith = RandomForestClassifier(
        n_estimators=100,
        class_weight="balanced",
        random_state=RANDOM_STATE,
        n_jobs=-1
    )
    rf_hadith.fit(X_h_train_s, y_train)
    scores_h = rf_hadith.predict_proba(X_h_test_s)[:, 1]
    roc_h = roc_auc_score(y_test, scores_h)
    pr_h = average_precision_score(y_test, scores_h)
    print(f"      ROC-AUC={roc_h:.4f}, PR-AUC={pr_h:.4f}")
    results.append(("Original + RF", roc_h, pr_h))
    
    # 4) Original + GB
    print("\n  4/6: Original Hadith + GB...")
    gb_hadith = GradientBoostingClassifier(
        n_estimators=100,
        max_depth=5,
        random_state=RANDOM_STATE
    )
    gb_hadith.fit(X_h_train_s, y_train)
    scores_h_gb = gb_hadith.predict_proba(X_h_test_s)[:, 1]
    roc_h_gb = roc_auc_score(y_test, scores_h_gb)
    pr_h_gb = average_precision_score(y_test, scores_h_gb)
    print(f"      ROC-AUC={roc_h_gb:.4f}, PR-AUC={pr_h_gb:.4f}")
    results.append(("Original + GB", roc_h_gb, pr_h_gb))
    
    # 5) Temporal + RF
    print("\n  5/6: Temporal Only + RF...")
    rf_temporal = RandomForestClassifier(
        n_estimators=100,
        class_weight="balanced",
        random_state=RANDOM_STATE,
        n_jobs=-1
    )
    rf_temporal.fit(X_t_train_s, y_train)
    scores_t = rf_temporal.predict_proba(X_t_test_s)[:, 1]
    roc_t = roc_auc_score(y_test, scores_t)
    pr_t = average_precision_score(y_test, scores_t)
    print(f"      ROC-AUC={roc_t:.4f}, PR-AUC={pr_t:.4f}")
    results.append(("Temporal + RF", roc_t, pr_t))
    
    # 6) Temporal + GB
    print("\n  6/6: Temporal Only + GB...")
    gb_temporal = GradientBoostingClassifier(
        n_estimators=100,
        max_depth=5,
        random_state=RANDOM_STATE
    )
    gb_temporal.fit(X_t_train_s, y_train)
    scores_t_gb = gb_temporal.predict_proba(X_t_test_s)[:, 1]
    roc_t_gb = roc_auc_score(y_test, scores_t_gb)
    pr_t_gb = average_precision_score(y_test, scores_t_gb)
    print(f"      ROC-AUC={roc_t_gb:.4f}, PR-AUC={pr_t_gb:.4f}")
    results.append(("Temporal + GB", roc_t_gb, pr_t_gb))
    
    print("\n✅ All models trained!")
    
    # -------------------------------------------------------------------------
    # STEP 5: Results
    # -------------------------------------------------------------------------
    print("\n" + "="*70)
    print("RESULTS")
    print("="*70)
    
    results_df = pd.DataFrame(results, columns=["Approach", "ROC-AUC", "PR-AUC"])
    results_df = results_df.sort_values("ROC-AUC", ascending=False)
    
    print("\n" + results_df.to_string(index=False))
    
    # Ablation
    improvement = (roc_c - roc_h) / (roc_h + 1e-12) * 100.0
    
    print("\n" + "="*70)
    print("ABLATION ANALYSIS")
    print("="*70)
    print(f"\nROC-AUC Comparison:")
    print(f"  Combined (Orig+Temp):  {roc_c:.4f}")
    print(f"  Original Hadith Only:  {roc_h:.4f}  (Δ = {roc_c - roc_h:+.4f})")
    print(f"  Temporal Only:         {roc_t:.4f}  (Δ = {roc_c - roc_t:+.4f})")
    
    if improvement >= 0:
        print(f"\n✅ Temporal features improve ROC-AUC by {improvement:.2f}%")
    else:
        print(f"\n⚠️  Temporal features reduced ROC-AUC by {abs(improvement):.2f}%")
    
    # -------------------------------------------------------------------------
    # STEP 6: Feature Importance
    # -------------------------------------------------------------------------
    print("\n" + "="*70)
    print("FEATURE IMPORTANCE")
    print("="*70)
    
    importances = rf_combined.feature_importances_
    sorted_idx = np.argsort(importances)[::-1]
    
    print("\nTop 15 Features:")
    for i in range(min(15, len(feature_names))):
        idx = sorted_idx[i]
        marker = "🔄" if "temp_" in feature_names[idx] else "📊"
        print(f"  {i+1:2d}. {marker} {feature_names[idx]:30s} {importances[idx]:.4f}")
    
    orig_imp = float(importances[:26].sum())
    temp_imp = float(importances[26:42].sum())
    total_imp = float(importances.sum())
    
    print(f"\nImportance by Type:")
    print(f"  Original Hadith: {orig_imp:.4f} ({orig_imp/total_imp*100:.1f}%)")
    print(f"  Temporal:        {temp_imp:.4f} ({temp_imp/total_imp*100:.1f}%)")
    
    # -------------------------------------------------------------------------
    # STEP 7: Save Results
    # -------------------------------------------------------------------------
    OUTPUT_DIR = r"F:\Projects\Security\results_cert_fast"
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    
    print("\n" + "="*70)
    print("SAVING RESULTS")
    print("="*70)
    
    results_df.to_csv(os.path.join(OUTPUT_DIR, "cert_results.csv"), index=False)
    
    importance_df = pd.DataFrame({
        "Feature": feature_names,
        "Importance": importances,
        "Type": ["Original"] * 26 + ["Temporal"] * 16
    }).sort_values("Importance", ascending=False)
    
    importance_df.to_csv(os.path.join(OUTPUT_DIR, "cert_feature_importance.csv"), index=False)
    
    # Summary
    with open(os.path.join(OUTPUT_DIR, "cert_summary.txt"), "w", encoding="utf-8") as f:
        f.write("CERT INSIDER THREAT ANALYSIS - SUMMARY\n")
        f.write("=" * 70 + "\n\n")
        f.write(f"Extraction Date: {metadata['extraction_date']}\n")
        f.write(f"Events: {metadata['total_events']:,}\n")
        f.write(f"Users: {metadata['total_users']}\n")
        f.write(f"Windows: {metadata['total_windows']:,}\n")
        f.write(f"Positive: {metadata['positive_windows']:,} ({metadata['positive_rate']*100:.2f}%)\n\n")
        f.write("RESULTS\n")
        f.write("-" * 70 + "\n")
        f.write(results_df.to_string(index=False))
        f.write("\n\nABLATION\n")
        f.write("-" * 70 + "\n")
        f.write(f"Combined ROC-AUC: {roc_c:.4f}\n")
        f.write(f"Original ROC-AUC: {roc_h:.4f}\n")
        f.write(f"Temporal ROC-AUC: {roc_t:.4f}\n")
        f.write(f"Improvement: {improvement:+.2f}%\n")
    
    print(f"\n✅ Saved: {os.path.join(OUTPUT_DIR, 'cert_results.csv')}")
    print(f"✅ Saved: {os.path.join(OUTPUT_DIR, 'cert_feature_importance.csv')}")
    print(f"✅ Saved: {os.path.join(OUTPUT_DIR, 'cert_summary.txt')}")
    
    # -------------------------------------------------------------------------
    # STEP 8: Visualizations
    # -------------------------------------------------------------------------
    print("\n" + "="*70)
    print("CREATING VISUALIZATIONS")
    print("="*70)
    
    # Plot 1: Performance
    fig, ax = plt.subplots(figsize=(10, 6))
    plot_df = results_df.sort_values("ROC-AUC", ascending=True)
    colors = ['#2E86AB' if 'Combined' in a else '#A23B72' if 'Original' in a 
              else '#F18F01' for a in plot_df['Approach']]
    ax.barh(plot_df["Approach"], plot_df["ROC-AUC"], color=colors, edgecolor='black')
    ax.set_xlabel("ROC-AUC", fontsize=12, fontweight='bold')
    ax.set_title("CERT Dataset - Model Performance", fontsize=14, fontweight='bold')
    ax.set_xlim([0, 1])
    ax.grid(True, alpha=0.3, axis="x")
    plt.tight_layout()
    plt.savefig(os.path.join(OUTPUT_DIR, "cert_performance.png"), dpi=150)
    plt.close()
    
    # Plot 2: Top features
    fig, ax = plt.subplots(figsize=(12, 8))
    top10 = importance_df.head(10).sort_values("Importance", ascending=True)
    colors_feat = ['#F18F01' if t == 'Temporal' else '#2E86AB' for t in top10['Type']]
    ax.barh(top10["Feature"], top10["Importance"], color=colors_feat, edgecolor='black')
    ax.set_xlabel("Importance", fontsize=12, fontweight='bold')
    ax.set_title("CERT Dataset - Top 10 Features", fontsize=14, fontweight='bold')
    ax.grid(True, alpha=0.3, axis="x")
    plt.tight_layout()
    plt.savefig(os.path.join(OUTPUT_DIR, "cert_top_features.png"), dpi=150)
    plt.close()
    
    print(f"\n✅ Saved: {os.path.join(OUTPUT_DIR, 'cert_performance.png')}")
    print(f"✅ Saved: {os.path.join(OUTPUT_DIR, 'cert_top_features.png')}")
    
    # -------------------------------------------------------------------------
    # DONE
    # -------------------------------------------------------------------------
    print("\n" + "="*70)
    print("✅ ANALYSIS COMPLETE!")
    print("="*70)
    print(f"\nAll results saved to: {OUTPUT_DIR}")
    print(f"\nKey Findings:")
    print(f"  - Combined ROC-AUC: {roc_c:.4f}")
    print(f"  - Temporal contribution: {improvement:+.2f}%")
    print(f"  - Top feature: {importance_df.iloc[0]['Feature']}")
    print(f"  - Malicious users detected: {len(metadata['malicious_users'])}")


if __name__ == "__main__":
    train_and_evaluate()

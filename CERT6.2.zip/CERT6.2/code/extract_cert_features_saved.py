#!/usr/bin/env python3
"""
CERT r6.2 Feature Extraction with Saving
Extract features once, reuse many times

This script:
1. Loads CERT data (scalable from 100K to 10M+ events)
2. Extracts all features (Hadith 26 + Temporal 16 = 42)
3. Saves to disk for instant reloading
4. Can be run at different scales (500, 1000, 4000 users)

Usage:
    # Extract features for 500 users (30 min)
    python extract_cert_features_saved.py --users 500 --events 1500000
    
    # Extract features for 4000 users (3 hours)
    python extract_cert_features_saved.py --users 4000 --events 10000000 --full
"""

import os
import sys
import json
import argparse
from datetime import datetime
import pickle

import numpy as np
import pandas as pd

sys.path.insert(0, r'F:\Projects\Security')

from compare_features_temporal_FULL import (
    construct_windows,
    build_user_history,
    build_transition_matrices,
    build_hadith_features,
    build_temporal_sequence_features,
    build_raw_count_features,
    build_minimal_features,
)

from load_cert_scalable import load_cert_scalable

RANDOM_STATE = 42
np.random.seed(RANDOM_STATE)


def extract_and_save_cert_features(
    cert_path=r"F:\Projects\Security\cert\r6.2",
    output_dir=r"F:\Projects\Security\cert_features_saved",
    max_events=1_500_000,
    max_users=500,
    load_full=False,
    config_name="cert_500users"
):
    """
    Extract CERT features and save for reuse.
    
    Args:
        cert_path: Path to CERT r6.2 directory
        output_dir: Where to save extracted features
        max_events: Target number of events
        max_users: Maximum users
        load_full: Load full dataset (no limits)
        config_name: Name for this configuration (e.g., "cert_500users", "cert_4000users")
    
    Returns:
        dict: Metadata about extraction
    """
    
    print("="*80)
    print("CERT r6.2 FEATURE EXTRACTION WITH SAVING")
    print("="*80)
    print(f"\nConfiguration: {config_name}")
    print(f"  CERT Path: {cert_path}")
    print(f"  Output Directory: {output_dir}")
    print(f"  Max Events: {max_events:,}")
    print(f"  Max Users: {max_users:,}")
    print(f"  Load Full: {load_full}")
    
    # Create output directory
    os.makedirs(output_dir, exist_ok=True)
    
    # Create config-specific subdirectory
    config_dir = os.path.join(output_dir, config_name)
    os.makedirs(config_dir, exist_ok=True)
    
    # ========================================================================
    # STEP 1: Load Data
    # ========================================================================
    print("\n" + "="*80)
    print("STEP 1: LOADING DATA")
    print("="*80)
    
    df, gt_df = load_cert_scalable(
        cert_path=cert_path,
        target_events=max_events,
        max_users=max_users,
        load_full=load_full
    )
    
    if df is None or len(df) == 0:
        print("\n❌ ERROR: Failed to load data")
        return None
    
    print(f"\n📊 Loaded:")
    print(f"  Events: {len(df):,}")
    print(f"  Users: {df['user_id'].nunique()}")
    print(f"  Malicious users: {len(gt_df) if gt_df is not None else 0}")
    print(f"  Event types: {df['event_type'].nunique()}")
    print(f"  Date range: {df['timestamp'].min()} to {df['timestamp'].max()}")
    
    # ========================================================================
    # STEP 2: Construct Windows
    # ========================================================================
    print("\n" + "="*80)
    print("STEP 2: CONSTRUCTING WINDOWS")
    print("="*80)
    
    print("\n  Creating windows (size=50, step=25)...")
    windows = construct_windows(df, window_size=50, step_size=25)
    print(f"  ✅ Created {len(windows):,} windows")
    
    # Label windows
    print("\n  Labeling windows...")
    malicious_users = set(gt_df['user'].astype(str).unique()) if gt_df is not None else set()
    
    # Label ALL windows from malicious users
    y = np.array([1 if w['user_id'] in malicious_users else 0 for w in windows])
    
    pos = int(y.sum())
    neg = len(y) - pos
    
    print(f"  ✅ Labels created:")
    print(f"     Positive: {pos:,} ({pos/len(y)*100:.2f}%)")
    print(f"     Negative: {neg:,} ({neg/len(y)*100:.2f}%)")
    
    if pos < 2:
        print("\n❌ ERROR: Not enough positive samples")
        return None
    
    # ========================================================================
    # STEP 3: Extract Features
    # ========================================================================
    print("\n" + "="*80)
    print("STEP 3: EXTRACTING FEATURES")
    print("="*80)
    
    # Build user history and transitions
    print("\n  Building user history...")
    user_history = build_user_history(df)
    
    all_event_types = df['event_type'].unique()
    print(f"  Event types: {len(all_event_types)}")
    
    print("  Building transition matrices...")
    user_transitions = build_transition_matrices(df, all_event_types)
    
    # Extract Hadith features (26)
    print("\n  Extracting Hadith features (26)...")
    X_hadith = []
    for i, w in enumerate(windows):
        if i % 1000 == 0:
            print(f"    Progress: {i:,}/{len(windows):,} ({i/len(windows)*100:.1f}%)")
        X_hadith.append(build_hadith_features(w, df, user_history, all_event_types))
    X_hadith = np.array(X_hadith)
    print(f"  ✅ Hadith features: {X_hadith.shape}")
    
    # Extract Temporal features (16)
    print("\n  Extracting Temporal features (16)...")
    X_temporal = []
    for i, w in enumerate(windows):
        if i % 1000 == 0:
            print(f"    Progress: {i:,}/{len(windows):,} ({i/len(windows)*100:.1f}%)")
        X_temporal.append(build_temporal_sequence_features(
            w, df, user_history, all_event_types, user_transitions
        ))
    X_temporal = np.array(X_temporal)
    print(f"  ✅ Temporal features: {X_temporal.shape}")
    
    # Combined (42)
    X_combined = np.hstack([X_hadith, X_temporal])
    print(f"  ✅ Combined features: {X_combined.shape}")
    
    # Other feature sets
    print("\n  Extracting other feature sets...")
    X_raw = np.array([build_raw_count_features(w, df, all_event_types) for w in windows])
    X_minimal = np.array([build_minimal_features(w, df) for w in windows])
    print(f"  ✅ Raw features: {X_raw.shape}")
    print(f"  ✅ Minimal features: {X_minimal.shape}")
    
    # Handle NaN/Inf
    print("\n  Cleaning features...")
    X_hadith = np.nan_to_num(X_hadith, nan=0, posinf=0, neginf=0)
    X_temporal = np.nan_to_num(X_temporal, nan=0, posinf=0, neginf=0)
    X_combined = np.nan_to_num(X_combined, nan=0, posinf=0, neginf=0)
    X_raw = np.nan_to_num(X_raw, nan=0, posinf=0, neginf=0)
    X_minimal = np.nan_to_num(X_minimal, nan=0, posinf=0, neginf=0)
    print("  ✅ Features cleaned")
    
    # ========================================================================
    # STEP 4: Save Features
    # ========================================================================
    print("\n" + "="*80)
    print("STEP 4: SAVING FEATURES TO DISK")
    print("="*80)
    
    # Save windows
    windows_file = os.path.join(config_dir, 'windows.pkl')
    with open(windows_file, 'wb') as f:
        pickle.dump(windows, f)
    print(f"\n  ✅ Saved windows: {windows_file}")
    print(f"     Size: {os.path.getsize(windows_file) / (1024**2):.2f} MB")
    
    # Save features
    hadith_file = os.path.join(config_dir, 'features_hadith.npy')
    np.save(hadith_file, X_hadith)
    print(f"\n  ✅ Saved Hadith features: {hadith_file}")
    print(f"     Shape: {X_hadith.shape}, Size: {os.path.getsize(hadith_file) / (1024**2):.2f} MB")
    
    temporal_file = os.path.join(config_dir, 'features_temporal.npy')
    np.save(temporal_file, X_temporal)
    print(f"\n  ✅ Saved Temporal features: {temporal_file}")
    print(f"     Shape: {X_temporal.shape}, Size: {os.path.getsize(temporal_file) / (1024**2):.2f} MB")
    
    combined_file = os.path.join(config_dir, 'features_combined.npy')
    np.save(combined_file, X_combined)
    print(f"\n  ✅ Saved Combined features: {combined_file}")
    print(f"     Shape: {X_combined.shape}, Size: {os.path.getsize(combined_file) / (1024**2):.2f} MB")
    
    raw_file = os.path.join(config_dir, 'features_raw.npy')
    np.save(raw_file, X_raw)
    print(f"\n  ✅ Saved Raw features: {raw_file}")
    print(f"     Shape: {X_raw.shape}, Size: {os.path.getsize(raw_file) / (1024**2):.2f} MB")
    
    minimal_file = os.path.join(config_dir, 'features_minimal.npy')
    np.save(minimal_file, X_minimal)
    print(f"\n  ✅ Saved Minimal features: {minimal_file}")
    print(f"     Shape: {X_minimal.shape}, Size: {os.path.getsize(minimal_file) / (1024**2):.2f} MB")
    
    # Save labels
    labels_file = os.path.join(config_dir, 'labels.npy')
    np.save(labels_file, y)
    print(f"\n  ✅ Saved labels: {labels_file}")
    print(f"     Shape: {y.shape}, Size: {os.path.getsize(labels_file) / (1024**2):.2f} MB")
    
    # Save metadata
    metadata = {
        'config_name': config_name,
        'extraction_date': datetime.now().isoformat(),
        'cert_path': cert_path,
        'max_events': max_events,
        'max_users': max_users,
        'load_full': load_full,
        'total_events': len(df),
        'total_users': int(df['user_id'].nunique()),
        'malicious_users': len(gt_df) if gt_df is not None else 0,
        'event_types': int(df['event_type'].nunique()),
        'windows': len(windows),
        'positive_windows': int(pos),
        'negative_windows': int(neg),
        'positive_rate': float(pos / len(y)),
        'feature_shapes': {
            'hadith': list(X_hadith.shape),
            'temporal': list(X_temporal.shape),
            'combined': list(X_combined.shape),
            'raw': list(X_raw.shape),
            'minimal': list(X_minimal.shape),
        },
        'feature_names': {
            'hadith': [
                "adalah_active_days", "adalah_total_events", "adalah_account_age",
                "adalah_consistency", "adalah_avg_events",
                "dabt_login_success", "dabt_delta_fail", "dabt_burstiness",
                "dabt_outside_hours", "dabt_timing_entropy", "dabt_vocab_div",
                "dabt_sensitive_ratio",
                "isnad_ip_consistency", "isnad_ip_match", "isnad_subnet_match",
                "isnad_geo_impossible", "isnad_session_discont", "isnad_new_ip_rate",
                "rep_duration", "rep_trust", "rep_penalty", "rep_trend",
                "anom_kl_div", "anom_hour", "anom_path", "anom_l2_dist",
            ],
            'temporal': [
                "temp_kl_transition", "temp_rare_transitions", "temp_seq_entropy",
                "temp_ngram_anomaly", "temp_run_anomaly",
                "temp_behavior_drift", "temp_autocorr", "temp_timing_shift",
                "temp_dow_divergence", "temp_rate_drift",
                "temp_subnet_drift", "temp_ip_switch_rate", "temp_device_trans_anom",
                "temp_failure_trend", "temp_cumul_suspicious", "temp_risk_accel",
            ]
        }
    }
    
    metadata_file = os.path.join(config_dir, 'metadata.json')
    with open(metadata_file, 'w') as f:
        json.dump(metadata, f, indent=2)
    print(f"\n  ✅ Saved metadata: {metadata_file}")
    
    # ========================================================================
    # STEP 5: Summary
    # ========================================================================
    print("\n" + "="*80)
    print("✅ FEATURE EXTRACTION COMPLETE!")
    print("="*80)
    
    total_size = sum([
        os.path.getsize(hadith_file),
        os.path.getsize(temporal_file),
        os.path.getsize(combined_file),
        os.path.getsize(labels_file),
        os.path.getsize(windows_file),
    ]) / (1024**2)
    
    print(f"\nSaved files in: {config_dir}")
    print(f"  - windows.pkl (window definitions)")
    print(f"  - features_hadith.npy ({X_hadith.shape})")
    print(f"  - features_temporal.npy ({X_temporal.shape})")
    print(f"  - features_combined.npy ({X_combined.shape})")
    print(f"  - features_raw.npy ({X_raw.shape})")
    print(f"  - features_minimal.npy ({X_minimal.shape})")
    print(f"  - labels.npy ({y.shape})")
    print(f"  - metadata.json")
    
    print(f"\nTotal size: {total_size:.2f} MB")
    
    print(f"\n📊 Feature Statistics:")
    print(f"  Windows: {len(windows):,}")
    print(f"  Positive: {pos:,} ({pos/len(y)*100:.2f}%)")
    print(f"  Hadith features: 26")
    print(f"  Temporal features: 16")
    print(f"  Combined features: 42")
    
    print("\n✅ Features are ready for training!")
    print(f"   Use load_cert_features_saved.py to load them instantly.")
    
    print("\n" + "="*80)
    print("NEXT STEPS")
    print("="*80)
    print("\n1. Features are extracted and saved!")
    print(f"2. Load with: load_features('{config_name}')")
    print("3. Train models without re-extracting features")
    print("\nExample:")
    print(f"  from load_cert_features_saved import load_features")
    print(f"  X_h, X_t, X_c, y, meta = load_features('{config_name}')")
    print(f"  # Train instantly!")
    
    return metadata


def main():
    """Main function with command line args."""
    parser = argparse.ArgumentParser(description='Extract and save CERT features')
    parser.add_argument('--users', type=int, default=500, help='Max users (500, 1000, 4000)')
    parser.add_argument('--events', type=int, default=1_500_000, help='Target events')
    parser.add_argument('--full', action='store_true', help='Load full dataset')
    parser.add_argument('--name', type=str, default=None, help='Config name')
    
    args = parser.parse_args()
    
    # Auto-generate config name if not provided
    if args.name is None:
        args.name = f"cert_{args.users}users"
    
    print(f"\nExtracting features for: {args.name}")
    print(f"  Users: {args.users}")
    print(f"  Events: {args.events:,}")
    print(f"  Full: {args.full}")
    
    metadata = extract_and_save_cert_features(
        max_events=args.events,
        max_users=args.users,
        load_full=args.full,
        config_name=args.name
    )
    
    if metadata:
        print(f"\n✅ Success! Features saved for: {args.name}")
    else:
        print(f"\n❌ Failed to extract features")


if __name__ == "__main__":
    # If run from Jupyter without args, use defaults
    try:
        import sys
        if 'ipykernel' in sys.modules:
            # Running in Jupyter
            print("Running in Jupyter - using default configuration")
            metadata = extract_and_save_cert_features(
                max_events=1_500_000,
                max_users=500,
                config_name="cert_500users"
            )
        else:
            # Command line
            main()
    except:
        main()

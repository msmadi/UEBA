#!/usr/bin/env python3
"""
CERT r6.2 Training Script - Complete Analysis
Matches CLUE-LDS analysis structure for direct comparison

USAGE:
======
from train_cert_complete import run_cert_analysis

results = run_cert_analysis(
    cert_path='F:\\Projects\\Security\\cert\\r6.2',
    max_events=1_500_000,
    save_plots=True
)
"""

import os
import sys
import numpy as np
import pandas as pd
from datetime import datetime

from sklearn.model_selection import train_test_split, StratifiedKFold
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (
    roc_auc_score, average_precision_score, f1_score, 
    precision_score, recall_score, accuracy_score,
    roc_curve, precision_recall_curve
)
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier, IsolationForest
from sklearn.linear_model import LogisticRegression

import matplotlib.pyplot as plt
import seaborn as sns

# Try to import torch for LSTM
try:
    import torch
    import torch.nn as nn
    import torch.optim as optim
    from torch.utils.data import TensorDataset, DataLoader
    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False
    print("WARNING: PyTorch not available. LSTM will be skipped.")

# Add paths for imports
sys.path.insert(0, r'F:\Projects\Security')

# Import from existing modules
from compare_features_temporal_FULL import (
    construct_windows,
    build_user_history,
    build_transition_matrices,
    build_hadith_features,
    build_temporal_sequence_features,
    build_raw_count_features,
    build_minimal_features,
)

from load_cert_expanded import load_cert_expanded

RANDOM_STATE = 42
np.random.seed(RANDOM_STATE)


# ============================================================
# EVALUATION FUNCTIONS (matching CLUE)
# ============================================================

def evaluate(y_true: np.ndarray, scores: np.ndarray, name: str) -> dict:
    """Compute comprehensive metrics."""
    if scores.max() - scores.min() > 1e-9:
        scores_norm = (scores - scores.min()) / (scores.max() - scores.min())
    else:
        scores_norm = np.zeros_like(scores) + 0.5
    
    try:
        roc = roc_auc_score(y_true, scores_norm)
    except ValueError:
        roc = 0.5
    
    try:
        pr = average_precision_score(y_true, scores_norm)
    except ValueError:
        pr = y_true.mean()
    
    best_f1, best_thr = 0, 0.5
    for thr in np.linspace(0, 1, 101):
        y_pred = (scores_norm >= thr).astype(int)
        f1 = f1_score(y_true, y_pred, zero_division=0)
        if f1 > best_f1:
            best_f1, best_thr = f1, thr
    
    y_pred = (scores_norm >= best_thr).astype(int)
    
    return {
        'Approach': name,
        'ROC-AUC': roc,
        'PR-AUC': pr,
        'F1': best_f1,
        'Precision': precision_score(y_true, y_pred, zero_division=0),
        'Recall': recall_score(y_true, y_pred, zero_division=0),
        'Accuracy': accuracy_score(y_true, y_pred),
        'Threshold': best_thr,
    }


def cross_validate(X, y, model_class, model_params, n_folds=5):
    """Stratified K-fold cross-validation."""
    skf = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=RANDOM_STATE)
    
    metrics = {'roc_auc': [], 'pr_auc': [], 'f1': []}
    
    for train_idx, val_idx in skf.split(X, y):
        X_train, X_val = X[train_idx], X[val_idx]
        y_train, y_val = y[train_idx], y[val_idx]
        
        scaler = StandardScaler()
        X_train_s = scaler.fit_transform(X_train)
        X_val_s = scaler.transform(X_val)
        
        model = model_class(**model_params)
        model.fit(X_train_s, y_train)
        
        if hasattr(model, 'predict_proba'):
            scores = model.predict_proba(X_val_s)[:, 1]
        else:
            scores = model.decision_function(X_val_s)
            scores = (scores - scores.min()) / (scores.max() - scores.min() + 1e-9)
        
        try:
            metrics['roc_auc'].append(roc_auc_score(y_val, scores))
        except ValueError:
            metrics['roc_auc'].append(0.5)
        
        try:
            metrics['pr_auc'].append(average_precision_score(y_val, scores))
        except ValueError:
            metrics['pr_auc'].append(y_val.mean())
        
        best_f1 = 0
        for thr in np.linspace(0, 1, 51):
            f1 = f1_score(y_val, (scores >= thr).astype(int), zero_division=0)
            best_f1 = max(best_f1, f1)
        metrics['f1'].append(best_f1)
    
    return {k: (np.mean(v), np.std(v)) for k, v in metrics.items()}


# ============================================================
# LSTM CLASSIFIER (if available)
# ============================================================

if TORCH_AVAILABLE:
    class LSTMClassifier(nn.Module):
        """LSTM for sequence classification."""
        def __init__(self, input_dim, hidden_dim=64, num_layers=2, dropout=0.3):
            super(LSTMClassifier, self).__init__()
            
            self.hidden_dim = hidden_dim
            self.num_layers = num_layers
            
            self.lstm = nn.LSTM(input_dim, hidden_dim, num_layers, 
                               batch_first=True, dropout=dropout if num_layers > 1 else 0)
            self.dropout = nn.Dropout(dropout)
            self.fc = nn.Linear(hidden_dim, 1)
            self.sigmoid = nn.Sigmoid()
        
        def forward(self, x):
            lstm_out, (h_n, c_n) = self.lstm(x)
            out = h_n[-1]
            out = self.dropout(out)
            out = self.fc(out)
            return self.sigmoid(out).squeeze()
    
    
    def train_lstm(X_train, y_train, X_val, y_val, input_dim, epochs=50, 
                   batch_size=32, lr=0.001):
        """Train LSTM classifier."""
        
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        
        X_train_t = torch.FloatTensor(X_train).unsqueeze(1).to(device)
        y_train_t = torch.FloatTensor(y_train).to(device)
        X_val_t = torch.FloatTensor(X_val).unsqueeze(1).to(device)
        y_val_t = torch.FloatTensor(y_val).to(device)
        
        train_dataset = TensorDataset(X_train_t, y_train_t)
        train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
        
        model = LSTMClassifier(input_dim).to(device)
        
        pos_weight = torch.tensor([len(y_train) / (y_train.sum() + 1e-9)]).to(device)
        criterion = nn.BCEWithLogitsLoss(pos_weight=pos_weight)
        optimizer = optim.Adam(model.parameters(), lr=lr)
        
        best_val_loss = float('inf')
        patience = 10
        patience_counter = 0
        
        for epoch in range(epochs):
            model.train()
            train_loss = 0
            
            for batch_X, batch_y in train_loader:
                optimizer.zero_grad()
                outputs = model(batch_X)
                
                outputs_logits = torch.log(outputs / (1 - outputs + 1e-9))
                loss = criterion(outputs_logits, batch_y)
                
                loss.backward()
                optimizer.step()
                
                train_loss += loss.item()
            
            model.eval()
            with torch.no_grad():
                val_outputs = model(X_val_t)
                val_outputs_logits = torch.log(val_outputs / (1 - val_outputs + 1e-9))
                val_loss = criterion(val_outputs_logits, y_val_t).item()
            
            if epoch % 10 == 0:
                print(f"  Epoch {epoch}/{epochs}, Train Loss: {train_loss/len(train_loader):.4f}, Val Loss: {val_loss:.4f}")
            
            if val_loss < best_val_loss:
                best_val_loss = val_loss
                patience_counter = 0
                best_model_state = model.state_dict()
            else:
                patience_counter += 1
                if patience_counter >= patience:
                    print(f"  Early stopping at epoch {epoch}")
                    break
        
        model.load_state_dict(best_model_state)
        
        return model
    
    
    def predict_lstm(model, X_test):
        """Get predictions from LSTM."""
        device = next(model.parameters()).device
        model.eval()
        
        X_test_t = torch.FloatTensor(X_test).unsqueeze(1).to(device)
        
        with torch.no_grad():
            outputs = model(X_test_t)
        
        return outputs.cpu().numpy()


# ============================================================
# GROUND TRUTH LABELING
# ============================================================

def label_windows(windows, gt_df):
    """Label windows based on ground truth."""
    if gt_df is None or gt_df.empty:
        return np.zeros(len(windows), dtype=int)
    
    # Find user column
    user_col = None
    for col in ['user', 'user_id', 'userid']:
        if col in gt_df.columns:
            user_col = col
            break
    
    if user_col is None:
        print("WARNING: No user column found in ground truth")
        return np.zeros(len(windows), dtype=int)
    
    malicious_users = set(gt_df[user_col].astype(str).unique())
    
    # Create intervals for each malicious user
    # For CERT, we label entire user timeline as malicious
    labels = []
    for w in windows:
        uid = str(w['user_id'])
        if uid in malicious_users:
            labels.append(1)
        else:
            labels.append(0)
    
    return np.array(labels, dtype=int)


# ============================================================
# VISUALIZATION
# ============================================================

def save_result_plots(results_df, importances, feature_names, output_dir,
                      y_test, scores_combined, scores_hadith, 
                      scores_temporal, scores_raw):
    """Save comprehensive visualizations."""
    os.makedirs(output_dir, exist_ok=True)
    
    # 1. ROC curves
    fig, ax = plt.subplots(figsize=(10, 8))
    
    fpr_c, tpr_c, _ = roc_curve(y_test, scores_combined)
    fpr_h, tpr_h, _ = roc_curve(y_test, scores_hadith)
    fpr_t, tpr_t, _ = roc_curve(y_test, scores_temporal)
    fpr_r, tpr_r, _ = roc_curve(y_test, scores_raw)
    
    ax.plot(fpr_c, tpr_c, label=f'Combined (AUC={roc_auc_score(y_test, scores_combined):.3f})', 
            linewidth=2.5, color='#2E86AB')
    ax.plot(fpr_h, tpr_h, label=f'Original (AUC={roc_auc_score(y_test, scores_hadith):.3f})', 
            linewidth=2, color='#A23B72')
    ax.plot(fpr_t, tpr_t, label=f'Temporal (AUC={roc_auc_score(y_test, scores_temporal):.3f})', 
            linewidth=2, color='#F18F01')
    ax.plot(fpr_r, tpr_r, label=f'Raw (AUC={roc_auc_score(y_test, scores_raw):.3f})', 
            linewidth=1.5, color='#98C1D9', linestyle='--')
    ax.plot([0, 1], [0, 1], '--', color='gray', linewidth=1)
    
    ax.set_xlabel('False Positive Rate', fontsize=12)
    ax.set_ylabel('True Positive Rate', fontsize=12)
    ax.set_title('CERT r6.2 - ROC Curves: Impact of Temporal Features', 
                fontsize=14, fontweight='bold')
    ax.legend(loc='lower right', fontsize=11)
    ax.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'cert_roc_curves.png'), dpi=150)
    print(f"  Saved: {output_dir}/cert_roc_curves.png")
    plt.close()
    
    # 2. Feature importance
    fig, ax = plt.subplots(figsize=(12, 8))
    
    sorted_idx = np.argsort(importances)[::-1][:20]
    top_features = [feature_names[i] for i in sorted_idx]
    top_importances = importances[sorted_idx]
    
    colors = ['#F18F01' if 'temp_' in f else '#2E86AB' for f in top_features]
    
    display_names = [f.replace('temp_', 'T:').replace('adalah_', 'AD:').replace('dabt_', 'DB:')
                    .replace('isnad_', 'IS:').replace('rep_', 'RP:').replace('anom_', 'AN:')
                    for f in top_features]
    
    y_pos = np.arange(len(display_names))
    bars = ax.barh(y_pos, top_importances, color=colors, edgecolor='black')
    
    ax.set_yticks(y_pos)
    ax.set_yticklabels(display_names, fontsize=10)
    ax.invert_yaxis()
    ax.set_xlabel('Feature Importance', fontsize=12, fontweight='bold')
    ax.set_title('CERT r6.2 - Top 20 Features', fontsize=14, fontweight='bold')
    ax.grid(True, alpha=0.3, axis='x')
    
    for i, (bar, val) in enumerate(zip(bars, top_importances)):
        ax.text(bar.get_width() + 0.002, bar.get_y() + bar.get_height()/2,
               f'{val:.4f}', va='center', fontsize=9)
    
    from matplotlib.patches import Patch
    legend_elements = [
        Patch(facecolor='#2E86AB', label='Original Hadith'),
        Patch(facecolor='#F18F01', label='Temporal Sequence')
    ]
    ax.legend(handles=legend_elements, loc='lower right', fontsize=11)
    
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'cert_top_features.png'), dpi=150)
    print(f"  Saved: {output_dir}/cert_top_features.png")
    plt.close()


# ============================================================
# MAIN ANALYSIS FUNCTION
# ============================================================

def run_cert_analysis(cert_path=r"F:\Projects\Security\cert\r6.2",
                      max_events=1_500_000,
                      max_users=500,
                      window_size=50,
                      step_size=25,
                      output_dir=r"F:\Projects\Security\results_cert_complete",
                      save_plots=True):
    """
    Complete CERT analysis matching CLUE structure.
    
    Args:
        cert_path: Path to CERT r6.2 directory
        max_events: Maximum events to load
        max_users: Maximum users
        window_size: Window size for feature extraction
        step_size: Step size for sliding windows
        output_dir: Output directory for results
        save_plots: Whether to save plots
    
    Returns:
        dict: Complete results including dataframes and metrics
    """
    
    print("="*70)
    print("CERT r6.2 COMPLETE ANALYSIS")
    print("Matching CLUE-LDS Analysis Structure")
    print("="*70)
    
    print(f"\nConfiguration:")
    print(f"  CERT Path: {cert_path}")
    print(f"  Max events: {max_events:,}")
    print(f"  Max users: {max_users}")
    print(f"  Window size: {window_size}")
    print(f"  Step size: {step_size}")
    
    # ========================================================================
    # STEP 1: Load Data
    # ========================================================================
    print("\n" + "="*70)
    print("STEP 1: LOADING DATA")
    print("="*70)
    
    df, gt_df = load_cert_expanded(cert_path, max_events, max_users)
    
    if df is None or df.empty:
        print("ERROR: Failed to load dataset")
        return None
    
    # Ensure timestamps are UTC
    df['timestamp'] = pd.to_datetime(df['timestamp'], utc=True)
    df = df.sort_values(['user_id', 'timestamp']).reset_index(drop=True)
    
    print(f"\n📊 Dataset loaded:")
    print(f"  Events: {len(df):,}")
    print(f"  Users: {df['user_id'].nunique()}")
    print(f"  Malicious users: {len(gt_df) if gt_df is not None else 0}")
    print(f"  Event types: {df['event_type'].nunique()}")
    
    # ========================================================================
    # STEP 2: Construct Windows
    # ========================================================================
    print("\n" + "="*70)
    print("STEP 2: CONSTRUCTING WINDOWS")
    print("="*70)
    
    print(f"\nBuilding windows (size={window_size}, step={step_size})...")
    windows = construct_windows(df, window_size, step_size)
    print(f"  Created {len(windows):,} windows")
    
    # Label windows
    y = label_windows(windows, gt_df)
    pos = int(y.sum())
    neg = len(y) - pos
    
    print(f"\n  Labels:")
    print(f"    Positive: {pos:,} ({pos/len(y)*100:.2f}%)")
    print(f"    Negative: {neg:,} ({neg/len(y)*100:.2f}%)")
    
    if pos < 2:
        print("ERROR: Not enough positive samples for training")
        return None
    
    # ========================================================================
    # STEP 3: Extract Features
    # ========================================================================
    print("\n" + "="*70)
    print("STEP 3: EXTRACTING FEATURES")
    print("="*70)
    
    # Build history and transitions
    print("\n  Building user history...")
    user_history = build_user_history(df)
    
    all_event_types = df['event_type'].unique()
    print(f"  Event types: {len(all_event_types)}")
    
    print("  Building transition matrices...")
    user_transitions = build_transition_matrices(df, all_event_types)
    
    # Extract Original Hadith features (26)
    print("\n  Extracting Original Hadith features (26)...")
    X_hadith = []
    for i, w in enumerate(windows):
        if i % 500 == 0 and i > 0:
            print(f"    Progress: {i:,}/{len(windows):,}")
        X_hadith.append(build_hadith_features(w, df, user_history, all_event_types))
    X_hadith = np.array(X_hadith)
    
    # Extract Temporal features (16)
    print("\n  Extracting Temporal Sequence features (16)...")
    X_temporal = []
    for i, w in enumerate(windows):
        if i % 500 == 0 and i > 0:
            print(f"    Progress: {i:,}/{len(windows):,}")
        X_temporal.append(build_temporal_sequence_features(
            w, df, user_history, all_event_types, user_transitions
        ))
    X_temporal = np.array(X_temporal)
    
    # Combined (42)
    X_combined = np.hstack([X_hadith, X_temporal])
    
    # Other feature sets
    print("\n  Extracting other feature sets...")
    X_raw = np.array([build_raw_count_features(w, df, all_event_types) for w in windows])
    X_minimal = np.array([build_minimal_features(w, df) for w in windows])
    
    print(f"\n  Feature dimensions:")
    print(f"    Original:  {X_hadith.shape}")
    print(f"    Temporal:  {X_temporal.shape}")
    print(f"    Combined:  {X_combined.shape}")
    print(f"    Raw:       {X_raw.shape}")
    print(f"    Minimal:   {X_minimal.shape}")
    
    # Handle NaN/Inf
    X_hadith = np.nan_to_num(X_hadith, nan=0, posinf=0, neginf=0)
    X_temporal = np.nan_to_num(X_temporal, nan=0, posinf=0, neginf=0)
    X_combined = np.nan_to_num(X_combined, nan=0, posinf=0, neginf=0)
    X_raw = np.nan_to_num(X_raw, nan=0, posinf=0, neginf=0)
    X_minimal = np.nan_to_num(X_minimal, nan=0, posinf=0, neginf=0)
    
    # ========================================================================
    # STEP 4: Train-Test Split
    # ========================================================================
    print("\n" + "="*70)
    print("STEP 4: TRAIN-TEST SPLIT")
    print("="*70)
    
    (X_h_train, X_h_test, X_t_train, X_t_test, X_c_train, X_c_test,
     X_r_train, X_r_test, X_m_train, X_m_test, y_train, y_test) = train_test_split(
        X_hadith, X_temporal, X_combined, X_raw, X_minimal, y,
        test_size=0.3, stratify=y, random_state=RANDOM_STATE
    )
    
    print(f"\n  Train: {len(y_train):,} (Pos: {int(y_train.sum()):,})")
    print(f"  Test:  {len(y_test):,} (Pos: {int(y_test.sum()):,})")
    
    # ========================================================================
    # STEP 5: Scale Features
    # ========================================================================
    print("\n" + "="*70)
    print("STEP 5: SCALING FEATURES")
    print("="*70)
    
    scaler_h = StandardScaler()
    X_h_tr = scaler_h.fit_transform(X_h_train)
    X_h_te = scaler_h.transform(X_h_test)
    
    scaler_t = StandardScaler()
    X_t_tr = scaler_t.fit_transform(X_t_train)
    X_t_te = scaler_t.transform(X_t_test)
    
    scaler_c = StandardScaler()
    X_c_tr = scaler_c.fit_transform(X_c_train)
    X_c_te = scaler_c.transform(X_c_test)
    
    scaler_r = StandardScaler()
    X_r_tr = scaler_r.fit_transform(X_r_train)
    X_r_te = scaler_r.transform(X_r_test)
    
    scaler_m = StandardScaler()
    X_m_tr = scaler_m.fit_transform(X_m_train)
    X_m_te = scaler_m.transform(X_m_test)
    
    print("  ✅ Features scaled (mean=0, std=1)")
    
    # ========================================================================
    # STEP 6: Train Models
    # ========================================================================
    print("\n" + "="*70)
    print("STEP 6: TRAINING MODELS")
    print("="*70)
    
    results = []
    
    # 1. Combined + RF
    print("\n  1. Combined + RF")
    rf_combined = RandomForestClassifier(n_estimators=100, class_weight='balanced',
                                         random_state=RANDOM_STATE, n_jobs=-1)
    rf_combined.fit(X_c_tr, y_train)
    scores_combined_rf = rf_combined.predict_proba(X_c_te)[:, 1]
    results.append(evaluate(y_test, scores_combined_rf, "Combined + RF"))
    
    # 2. Combined + GB
    print("  2. Combined + GB")
    gb_combined = GradientBoostingClassifier(n_estimators=100, max_depth=5,
                                             random_state=RANDOM_STATE)
    gb_combined.fit(X_c_tr, y_train)
    scores_combined_gb = gb_combined.predict_proba(X_c_te)[:, 1]
    results.append(evaluate(y_test, scores_combined_gb, "Combined + GB"))
    
    # 3. Original + RF
    print("  3. Original Hadith + RF")
    rf_hadith = RandomForestClassifier(n_estimators=100, class_weight='balanced',
                                        random_state=RANDOM_STATE, n_jobs=-1)
    rf_hadith.fit(X_h_tr, y_train)
    scores_hadith_rf = rf_hadith.predict_proba(X_h_te)[:, 1]
    results.append(evaluate(y_test, scores_hadith_rf, "Original Hadith + RF"))
    
    # 4. Original + GB
    print("  4. Original Hadith + GB")
    gb_hadith = GradientBoostingClassifier(n_estimators=100, max_depth=5,
                                            random_state=RANDOM_STATE)
    gb_hadith.fit(X_h_tr, y_train)
    scores_hadith_gb = gb_hadith.predict_proba(X_h_te)[:, 1]
    results.append(evaluate(y_test, scores_hadith_gb, "Original Hadith + GB"))
    
    # 5. Temporal + RF
    print("  5. Temporal Only + RF")
    rf_temporal = RandomForestClassifier(n_estimators=100, class_weight='balanced',
                                          random_state=RANDOM_STATE, n_jobs=-1)
    rf_temporal.fit(X_t_tr, y_train)
    scores_temporal_rf = rf_temporal.predict_proba(X_t_te)[:, 1]
    results.append(evaluate(y_test, scores_temporal_rf, "Temporal Only + RF"))
    
    # 6. Temporal + GB
    print("  6. Temporal Only + GB")
    gb_temporal = GradientBoostingClassifier(n_estimators=100, max_depth=5,
                                              random_state=RANDOM_STATE)
    gb_temporal.fit(X_t_tr, y_train)
    scores_temporal_gb = gb_temporal.predict_proba(X_t_te)[:, 1]
    results.append(evaluate(y_test, scores_temporal_gb, "Temporal Only + GB"))
    
    # 7. LSTM (if available)
    if TORCH_AVAILABLE:
        print("  7. Combined + LSTM")
        try:
            lstm_model = train_lstm(X_c_tr, y_train, X_c_te, y_test,
                                   input_dim=X_combined.shape[1], epochs=50)
            scores_lstm = predict_lstm(lstm_model, X_c_te)
            results.append(evaluate(y_test, scores_lstm, "Combined + LSTM"))
        except Exception as e:
            print(f"  LSTM training failed: {e}")
    
    # 8. Raw + RF
    print("  8. Raw Counts + RF")
    rf_raw = RandomForestClassifier(n_estimators=100, class_weight='balanced',
                                     random_state=RANDOM_STATE, n_jobs=-1)
    rf_raw.fit(X_r_tr, y_train)
    scores_raw_rf = rf_raw.predict_proba(X_r_te)[:, 1]
    results.append(evaluate(y_test, scores_raw_rf, "Raw Counts + RF"))
    
    # 9. Minimal + RF
    print("  9. Minimal + RF")
    rf_min = RandomForestClassifier(n_estimators=100, class_weight='balanced',
                                     random_state=RANDOM_STATE, n_jobs=-1)
    rf_min.fit(X_m_tr, y_train)
    scores_min_rf = rf_min.predict_proba(X_m_te)[:, 1]
    results.append(evaluate(y_test, scores_min_rf, "Minimal + RF"))
    
    # 10. Random Baseline
    print("  10. Random Baseline")
    scores_random = np.random.random(len(y_test))
    results.append(evaluate(y_test, scores_random, "Random"))
    
    # ========================================================================
    # STEP 7: Results Summary
    # ========================================================================
    print("\n" + "="*80)
    print("RESULTS")
    print("="*80)
    
    results_df = pd.DataFrame(results)
    results_df = results_df.sort_values('ROC-AUC', ascending=False)
    
    print("\n" + results_df.to_string(index=False))
    
    # ========================================================================
    # STEP 8: Ablation Analysis
    # ========================================================================
    print("\n" + "="*80)
    print("ABLATION ANALYSIS")
    print("="*80)
    
    # Basic comparison
    combined_roc = results_df[results_df['Approach'] == 'Combined + RF']['ROC-AUC'].values[0]
    orig_roc = results_df[results_df['Approach'] == 'Original Hadith + RF']['ROC-AUC'].values[0]
    temporal_roc = results_df[results_df['Approach'] == 'Temporal Only + RF']['ROC-AUC'].values[0]
    raw_roc = results_df[results_df['Approach'] == 'Raw Counts + RF']['ROC-AUC'].values[0]
    
    combined_pr = results_df[results_df['Approach'] == 'Combined + RF']['PR-AUC'].values[0]
    orig_pr = results_df[results_df['Approach'] == 'Original Hadith + RF']['PR-AUC'].values[0]
    temporal_pr = results_df[results_df['Approach'] == 'Temporal Only + RF']['PR-AUC'].values[0]
    
    combined_f1 = results_df[results_df['Approach'] == 'Combined + RF']['F1'].values[0]
    orig_f1 = results_df[results_df['Approach'] == 'Original Hadith + RF']['F1'].values[0]
    temporal_f1 = results_df[results_df['Approach'] == 'Temporal Only + RF']['F1'].values[0]
    
    print(f"\n📊 Overall Performance Comparison:")
    print(f"{'':30s} {'ROC-AUC':>10s} {'PR-AUC':>10s} {'F1':>10s}")
    print(f"{'-'*60}")
    print(f"{'Full Combined (42 features)':30s} {combined_roc:10.4f} {combined_pr:10.4f} {combined_f1:10.4f}")
    print(f"{'Original Hadith (26)':30s} {orig_roc:10.4f} {orig_pr:10.4f} {orig_f1:10.4f}")
    print(f"{'Temporal Only (16)':30s} {temporal_roc:10.4f} {temporal_pr:10.4f} {temporal_f1:10.4f}")
    print(f"{'Raw Counts':30s} {raw_roc:10.4f}")
    
    print(f"\n🎯 Improvement from Temporal Features:")
    roc_improvement = (combined_roc - orig_roc) / orig_roc * 100
    pr_improvement = (combined_pr - orig_pr) / orig_pr * 100
    f1_improvement = (combined_f1 - orig_f1) / orig_f1 * 100
    
    print(f"  ROC-AUC: {orig_roc:.4f} → {combined_roc:.4f} ({roc_improvement:+.2f}%)")
    print(f"  PR-AUC:  {orig_pr:.4f} → {combined_pr:.4f} ({pr_improvement:+.2f}%)")
    print(f"  F1:      {orig_f1:.4f} → {combined_f1:.4f} ({f1_improvement:+.2f}%)")
    
    if combined_roc > orig_roc:
        print(f"\n✅ Temporal features improve ROC-AUC by {roc_improvement:.1f}%")
    elif abs(combined_roc - orig_roc) < 0.001:
        print(f"\n≈ Performance equivalent (difference < 0.1%)")
    else:
        print(f"\n✗ Combined performance lower than baseline")
    
    # ========================================================================
    # DETAILED ABLATION: Remove Individual Axes
    # ========================================================================
    print("\n" + "="*80)
    print("DETAILED ABLATION STUDY")
    print("="*80)
    
    print("\n🔬 Testing impact of removing each feature axis...")
    
    # Feature indices for each axis
    axis_indices = {
        'Adalah': list(range(0, 5)),      # adalah_* (5 features)
        'Dabt': list(range(5, 12)),        # dabt_* (7 features)
        'Isnad': list(range(12, 18)),      # isnad_* (6 features)
        'Reputation': list(range(18, 22)), # rep_* (4 features)
        'Anomaly': list(range(22, 26)),    # anom_* (4 features)
        'Temporal_Dabt': list(range(26, 31)),      # temp dabt (5 features)
        'Temporal_Adalah': list(range(31, 36)),    # temp adalah (5 features)
        'Temporal_Isnad': list(range(36, 39)),     # temp isnad (3 features)
        'Temporal_Rep': list(range(39, 42)),       # temp rep (3 features)
    }
    
    ablation_results = []
    
    # 1. REMOVING INDIVIDUAL AXES (from full 42)
    print("\n📉 1. Removing Individual Axes from Full Set (42 → 42-N):")
    print(f"{'Axis Removed':25s} {'Features':>10s} {'ROC-AUC':>10s} {'PR-AUC':>10s} {'F1':>10s}")
    print("-" * 65)
    
    for axis_name, indices in axis_indices.items():
        # Create mask for all features EXCEPT this axis
        mask = np.ones(42, dtype=bool)
        mask[indices] = False
        
        X_ablated = X_combined[:, mask]
        
        # Properly split ablated features
        (X_abl_train, X_abl_test, _, _) = train_test_split(
            X_ablated, y, test_size=0.3, stratify=y, random_state=RANDOM_STATE
        )
        
        scaler_abl = StandardScaler()
        X_abl_tr = scaler_abl.fit_transform(X_abl_train)
        X_abl_te = scaler_abl.transform(X_abl_test)
        
        rf_abl = RandomForestClassifier(n_estimators=100, class_weight='balanced',
                                        random_state=RANDOM_STATE, n_jobs=-1)
        rf_abl.fit(X_abl_tr, y_train)
        scores_abl = rf_abl.predict_proba(X_abl_te)[:, 1]
        
        roc_abl = roc_auc_score(y_test, scores_abl)
        pr_abl = average_precision_score(y_test, scores_abl)
        
        # Find best F1
        best_f1 = 0
        for thr in np.linspace(0, 1, 51):
            f1 = f1_score(y_test, (scores_abl >= thr).astype(int), zero_division=0)
            best_f1 = max(best_f1, f1)
        
        n_features = 42 - len(indices)
        ablation_results.append({
            'Type': 'Remove',
            'Axis': axis_name,
            'Features': n_features,
            'ROC-AUC': roc_abl,
            'PR-AUC': pr_abl,
            'F1': best_f1,
            'Delta_ROC': roc_abl - combined_roc
        })
        
        print(f"Without {axis_name:20s} {n_features:10d} {roc_abl:10.4f} {pr_abl:10.4f} {best_f1:10.4f}")
    
    # 2. SINGLE AXIS ONLY MODELS
    print(f"\n📊 2. Single-Axis Only Models (Using Only One Axis):")
    print(f"{'Axis Used':25s} {'Features':>10s} {'ROC-AUC':>10s} {'PR-AUC':>10s} {'F1':>10s}")
    print("-" * 65)
    
    for axis_name, indices in axis_indices.items():
        # Use ONLY this axis
        X_single = X_combined[:, indices]
        
        # Properly split single-axis features
        (X_sgl_train, X_sgl_test, _, _) = train_test_split(
            X_single, y, test_size=0.3, stratify=y, random_state=RANDOM_STATE
        )
        
        scaler_sgl = StandardScaler()
        X_sgl_tr = scaler_sgl.fit_transform(X_sgl_train)
        X_sgl_te = scaler_sgl.transform(X_sgl_test)
        
        rf_sgl = RandomForestClassifier(n_estimators=100, class_weight='balanced',
                                        random_state=RANDOM_STATE, n_jobs=-1)
        rf_sgl.fit(X_sgl_tr, y_train)
        scores_sgl = rf_sgl.predict_proba(X_sgl_te)[:, 1]
        
        roc_sgl = roc_auc_score(y_test, scores_sgl)
        pr_sgl = average_precision_score(y_test, scores_sgl)
        
        # Find best F1
        best_f1 = 0
        for thr in np.linspace(0, 1, 51):
            f1 = f1_score(y_test, (scores_sgl >= thr).astype(int), zero_division=0)
            best_f1 = max(best_f1, f1)
        
        ablation_results.append({
            'Type': 'Only',
            'Axis': axis_name,
            'Features': len(indices),
            'ROC-AUC': roc_sgl,
            'PR-AUC': pr_sgl,
            'F1': best_f1,
            'Delta_ROC': roc_sgl - combined_roc
        })
        
        print(f"{axis_name:25s} {len(indices):10d} {roc_sgl:10.4f} {pr_sgl:10.4f} {best_f1:10.4f}")
    
    # 3. GROUPED COMPARISONS
    print(f"\n📈 3. Original vs Temporal Feature Groups:")
    print(f"{'Group':25s} {'Features':>10s} {'ROC-AUC':>10s} {'PR-AUC':>10s} {'F1':>10s}")
    print("-" * 65)
    
    # Original features only (indices 0-25)
    print(f"{'Original Hadith (26)':25s} {26:10d} {orig_roc:10.4f} {orig_pr:10.4f} {orig_f1:10.4f}")
    
    # Temporal features only (indices 26-41)
    print(f"{'Temporal Only (16)':25s} {16:10d} {temporal_roc:10.4f} {temporal_pr:10.4f} {temporal_f1:10.4f}")
    
    # Combined
    print(f"{'Combined (42)':25s} {42:10d} {combined_roc:10.4f} {combined_pr:10.4f} {combined_f1:10.4f}")
    
    # Save ablation results
    ablation_df = pd.DataFrame(ablation_results)
    
    print("\n" + "="*80)
    print("ABLATION INSIGHTS")
    print("="*80)
    
    # Find most impactful axis (largest drop when removed)
    remove_results = ablation_df[ablation_df['Type'] == 'Remove'].sort_values('Delta_ROC')
    most_impactful = remove_results.iloc[0]
    
    print(f"\n🎯 Most Critical Axis (largest drop when removed):")
    print(f"  {most_impactful['Axis']}: ROC-AUC drops by {abs(most_impactful['Delta_ROC']):.4f}")
    print(f"  ({most_impactful['Features']} features remaining)")
    
    # Find best single axis
    only_results = ablation_df[ablation_df['Type'] == 'Only'].sort_values('ROC-AUC', ascending=False)
    best_single = only_results.iloc[0]
    
    print(f"\n🏆 Best Single Axis:")
    print(f"  {best_single['Axis']}: ROC-AUC = {best_single['ROC-AUC']:.4f}")
    print(f"  ({best_single['Features']} features)")
    
    # Temporal vs Original comparison
    orig_avg = ablation_df[(ablation_df['Type'] == 'Only') & 
                           (ablation_df['Axis'].str.startswith('Temporal') == False)]['ROC-AUC'].mean()
    temp_avg = ablation_df[(ablation_df['Type'] == 'Only') & 
                           (ablation_df['Axis'].str.startswith('Temporal'))]['ROC-AUC'].mean()
    
    print(f"\n📊 Average Performance by Type:")
    print(f"  Original axes (5): {orig_avg:.4f}")
    print(f"  Temporal axes (4): {temp_avg:.4f}")
    print(f"  Difference: {temp_avg - orig_avg:+.4f}")
    
    # ========================================================================
    # STEP 9: Feature Importance
    # ========================================================================
    print("\n" + "="*80)
    print("FEATURE IMPORTANCE")
    print("="*80)
    
    feature_names = [
        "adalah_active_days", "adalah_total_events", "adalah_account_age",
        "adalah_consistency", "adalah_avg_events",
        "dabt_login_success", "dabt_delta_fail", "dabt_burstiness",
        "dabt_outside_hours", "dabt_timing_entropy", "dabt_vocab_div",
        "dabt_sensitive_ratio",
        "isnad_ip_consistency", "isnad_ip_match", "isnad_subnet_match",
        "isnad_geo_impossible", "isnad_session_discont", "isnad_new_ip_rate",
        "rep_duration", "rep_trust", "rep_penalty", "rep_trend",
        "anom_kl_div", "anom_hour", "anom_path", "anom_l2_dist",
        "temp_kl_transition", "temp_rare_transitions", "temp_seq_entropy",
        "temp_ngram_anomaly", "temp_run_anomaly",
        "temp_behavior_drift", "temp_autocorr", "temp_timing_shift",
        "temp_dow_divergence", "temp_rate_drift",
        "temp_subnet_drift", "temp_ip_switch_rate", "temp_device_trans_anom",
        "temp_failure_trend", "temp_cumul_suspicious", "temp_risk_accel",
    ]
    
    importances = rf_combined.feature_importances_
    sorted_idx = np.argsort(importances)[::-1]
    
    print("\nTop 15 Features:")
    for i in range(min(15, len(feature_names))):
        idx = sorted_idx[i]
        marker = "🔄" if "temp_" in feature_names[idx] else "📊"
        print(f"  {i+1:2d}. {marker} {feature_names[idx]:30s} {importances[idx]:.4f}")
    
    orig_total = importances[:26].sum()
    temp_total = importances[26:42].sum()
    
    print(f"\nTotal Importance:")
    print(f"  Original: {orig_total:.4f} ({orig_total/importances.sum()*100:.1f}%)")
    print(f"  Temporal: {temp_total:.4f} ({temp_total/importances.sum()*100:.1f}%)")
    
    # ========================================================================
    # STEP 10: Cross-Validation
    # ========================================================================
    print("\n" + "="*80)
    print("CROSS-VALIDATION")
    print("="*80)
    
    print("\nCombined + RF:")
    cv_combined = cross_validate(X_combined, y, RandomForestClassifier,
                                 {'n_estimators': 100, 'class_weight': 'balanced',
                                  'random_state': RANDOM_STATE, 'n_jobs': -1})
    for m, (mean, std) in cv_combined.items():
        print(f"  {m}: {mean:.4f} ± {std:.4f}")
    
    print("\nOriginal + RF:")
    cv_hadith = cross_validate(X_hadith, y, RandomForestClassifier,
                               {'n_estimators': 100, 'class_weight': 'balanced',
                                'random_state': RANDOM_STATE, 'n_jobs': -1})
    for m, (mean, std) in cv_hadith.items():
        print(f"  {m}: {mean:.4f} ± {std:.4f}")
    
    print("\nTemporal + RF:")
    cv_temporal = cross_validate(X_temporal, y, RandomForestClassifier,
                                {'n_estimators': 100, 'class_weight': 'balanced',
                                 'random_state': RANDOM_STATE, 'n_jobs': -1})
    for m, (mean, std) in cv_temporal.items():
        print(f"  {m}: {mean:.4f} ± {std:.4f}")
    
    # ========================================================================
    # STEP 11: Save Results
    # ========================================================================
    print("\n" + "="*80)
    print("SAVING RESULTS")
    print("="*80)
    
    os.makedirs(output_dir, exist_ok=True)
    
    # Save main results CSV
    results_df.to_csv(os.path.join(output_dir, 'cert_results.csv'), index=False)
    print(f"\n  ✅ Saved: {output_dir}/cert_results.csv")
    
    # Save ablation results
    ablation_df.to_csv(os.path.join(output_dir, 'cert_ablation.csv'), index=False)
    print(f"  ✅ Saved: {output_dir}/cert_ablation.csv")
    
    # Save feature importance
    importance_df = pd.DataFrame({
        'Feature': feature_names,
        'Importance': importances,
        'Type': ['Original']*26 + ['Temporal']*16,
        'Axis': (
            ['Adalah']*5 + ['Dabt']*7 + ['Isnad']*6 + ['Reputation']*4 + ['Anomaly']*4 +
            ['Temporal_Dabt']*5 + ['Temporal_Adalah']*5 + ['Temporal_Isnad']*3 + ['Temporal_Rep']*3
        )
    }).sort_values('Importance', ascending=False)
    
    importance_df.to_csv(os.path.join(output_dir, 'cert_feature_importance.csv'), index=False)
    print(f"  ✅ Saved: {output_dir}/cert_feature_importance.csv")
    
    # Save comprehensive summary
    with open(os.path.join(output_dir, 'cert_summary.txt'), 'w', encoding='utf-8') as f:
        f.write("CERT r6.2 INSIDER THREAT ANALYSIS - COMPREHENSIVE SUMMARY\n")
        f.write("=" * 70 + "\n\n")
        f.write(f"Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
        
        f.write("DATASET STATISTICS\n")
        f.write("-" * 70 + "\n")
        f.write(f"Events: {len(df):,}\n")
        f.write(f"Users: {df['user_id'].nunique()}\n")
        f.write(f"Malicious users: {len(gt_df) if gt_df is not None else 0}\n")
        f.write(f"Windows: {len(windows):,}\n")
        f.write(f"Positive: {pos:,} ({pos/len(y)*100:.2f}%)\n")
        f.write(f"Event types: {df['event_type'].nunique()}\n\n")
        
        f.write("MAIN RESULTS\n")
        f.write("-" * 70 + "\n")
        f.write(results_df.to_string(index=False))
        
        f.write("\n\nOVERALL ABLATION\n")
        f.write("-" * 70 + "\n")
        f.write(f"Combined ROC-AUC: {combined_roc:.4f}\n")
        f.write(f"Original ROC-AUC: {orig_roc:.4f}\n")
        f.write(f"Temporal ROC-AUC: {temporal_roc:.4f}\n")
        f.write(f"Improvement: {roc_improvement:+.2f}%\n\n")
        
        f.write("DETAILED ABLATION\n")
        f.write("-" * 70 + "\n")
        f.write(ablation_df.to_string(index=False))
        
        f.write("\n\nFEATURE IMPORTANCE (Top 20)\n")
        f.write("-" * 70 + "\n")
        f.write(importance_df.head(20).to_string(index=False))
        
        f.write(f"\n\nTEMPORAL CONTRIBUTION\n")
        f.write("-" * 70 + "\n")
        f.write(f"Original features: {orig_total:.4f} ({orig_total/importances.sum()*100:.1f}%)\n")
        f.write(f"Temporal features: {temp_total:.4f} ({temp_total/importances.sum()*100:.1f}%)\n")
    
    print(f"  ✅ Saved: {output_dir}/cert_summary.txt")
    
    # Save plots
    if save_plots:
        print("\n  Creating visualizations...")
        save_result_plots(results_df, importances, feature_names, output_dir,
                         y_test, scores_combined_rf, scores_hadith_rf,
                         scores_temporal_rf, scores_raw_rf)
    
    # ========================================================================
    # DONE
    # ========================================================================
    print("\n" + "="*80)
    print("✅ ANALYSIS COMPLETE")
    print("="*80)
    
    print(f"\nResults saved to: {output_dir}")
    print(f"\nKey Findings:")
    print(f"  - Combined ROC-AUC: {combined_roc:.4f}")
    print(f"  - Original ROC-AUC: {orig_roc:.4f}")
    print(f"  - Improvement: {(combined_roc - orig_roc) / orig_roc * 100:+.2f}%")
    print(f"  - Temporal contribution: {temp_total/importances.sum()*100:.1f}%")
    print(f"  - Top feature: {feature_names[sorted_idx[0]]}")
    
    return {
        'results_df': results_df,
        'ablation_df': ablation_df,
        'cv_combined': cv_combined,
        'cv_hadith': cv_hadith,
        'cv_temporal': cv_temporal,
        'feature_importances': dict(zip(feature_names, importances)),
        'temporal_contribution': temp_total / importances.sum(),
        'improvement_pct': roc_improvement,
        'most_critical_axis': most_impactful['Axis'],
        'best_single_axis': best_single['Axis'],
    }


# ============================================================
# MAIN
# ============================================================

if __name__ == "__main__":
    results = run_cert_analysis(
        cert_path=r"F:\Projects\Security\cert\r6.2",
        max_events=1_500_000,
        max_users=500,
        save_plots=True
    )
    
    if results:
        print("\n" + "="*80)
        print("RESULTS SUMMARY")
        print("="*80)
        print(results['results_df'])
        print(f"\nTemporal contribution: {results['temporal_contribution']*100:.1f}%")
        print(f"Improvement: {results['improvement_pct']:+.2f}%")

#!/usr/bin/env python3
"""
CERT COMPREHENSIVE ANALYSIS - With HTTP, Email, and All Data Sources
Uses ALL CERT data including http.csv (WikiLeaks/Dropbox detection!)

USAGE:
======
python run_CERT_comprehensive.py

Key Features:
- Loads ALL CERT files: logon, device, file, HTTP, email
- Detects WikiLeaks and Dropbox uploads (smoking guns!)
- Creates rich event types for better detection
- Ensures all malicious users are captured
"""

import os
import sys
import numpy as np
import pandas as pd
from datetime import timedelta

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_auc_score, average_precision_score
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier

import matplotlib.pyplot as plt
import seaborn as sns

# Add path for imports
sys.path.insert(0, r'F:\Projects\Security')

try:
    from compare_features_temporal_FULL import (
        construct_windows,
        build_user_history,
        build_transition_matrices,
        build_hadith_features,
        build_temporal_sequence_features,
    )
except ImportError as e:
    print(f"❌ ERROR: Cannot import required functions")
    print(f"   Error: {e}")
    print("   Make sure compare_features_MULTI_DATASET.py is in F:\\Projects\\Security")
    sys.exit(1)

RANDOM_STATE = 42
np.random.seed(RANDOM_STATE)


# =============================================================================
# COMPREHENSIVE CERT LOADER - WITH HTTP, EMAIL, ALL DATA
# =============================================================================

def load_cert_comprehensive(cert_path, max_events=1_500_000, max_users=200):
    """
    Load CERT dataset with ALL data sources including HTTP and email.
    This captures WikiLeaks uploads, Dropbox leaks, and all insider activity!
    """
    
    print("="*70)
    print("COMPREHENSIVE CERT LOADER")
    print("="*70)
    print(f"  Loading from: {cert_path}")
    print(f"  Target: {max_events:,} events from top {max_users} users")
    
    all_events = []
    
    # ========================================================================
    # 1. LOGON.CSV - Login/logout events
    # ========================================================================
    logon_file = os.path.join(cert_path, 'logon.csv')
    if os.path.exists(logon_file):
        print(f"\n  📂 Loading logon.csv...")
        try:
            logon_df = pd.read_csv(logon_file, on_bad_lines='skip')
            print(f"     Rows: {len(logon_df):,}")
            
            for _, row in logon_df.iterrows():
                try:
                    activity = str(row.iloc[5]).strip().strip('"')
                    all_events.append({
                        'user_id': str(row.iloc[3]).strip().strip('"'),
                        'timestamp': str(row.iloc[2]).strip().strip('"'),
                        'event_type': f"logon_{activity}",
                        'device': str(row.iloc[4]).strip().strip('"'),
                        'ip_address': '',
                        'path': '',
                        'source': 'logon'
                    })
                except:
                    continue
        except Exception as e:
            print(f"     ⚠️  Error loading logon.csv: {e}")
    
    # ========================================================================
    # 2. DEVICE.CSV - USB/removable media (exfiltration!)
    # ========================================================================
    device_file = os.path.join(cert_path, 'device.csv')
    if os.path.exists(device_file):
        print(f"\n  📂 Loading device.csv...")
        try:
            device_df = pd.read_csv(device_file, on_bad_lines='skip')
            print(f"     Rows: {len(device_df):,}")
            
            for _, row in device_df.iterrows():
                try:
                    activity = str(row.iloc[6]).strip().strip('"') if len(row) > 6 else 'Unknown'
                    path = str(row.iloc[5]).strip().strip('"') if len(row) > 5 else ''
                    all_events.append({
                        'user_id': str(row.iloc[3]).strip().strip('"'),
                        'timestamp': str(row.iloc[2]).strip().strip('"'),
                        'event_type': f"device_{activity}",
                        'device': str(row.iloc[4]).strip().strip('"'),
                        'ip_address': '',
                        'path': path,
                        'source': 'device'
                    })
                except:
                    continue
        except Exception as e:
            print(f"     ⚠️  Error loading device.csv: {e}")
    
    # ========================================================================
    # 3. FILE.CSV - File operations (limited for memory)
    # ========================================================================
    file_file = os.path.join(cert_path, 'file.csv')
    if os.path.exists(file_file):
        print(f"\n  📂 Loading file.csv (first 400k rows)...")
        try:
            file_df = pd.read_csv(file_file, nrows=400000, on_bad_lines='skip')
            print(f"     Rows: {len(file_df):,}")
            
            for _, row in file_df.iterrows():
                try:
                    filename = str(row.iloc[5]).strip().strip('"') if len(row) > 5 else ''
                    ext = filename.split('.')[-1].lower() if '.' in filename else 'unknown'
                    device = str(row.iloc[4]).strip().strip('"')
                    
                    all_events.append({
                        'user_id': str(row.iloc[3]).strip().strip('"'),
                        'timestamp': str(row.iloc[2]).strip().strip('"'),
                        'event_type': f"file_{ext}",
                        'device': device,
                        'ip_address': '',
                        'path': filename,
                        'source': 'file'
                    })
                except:
                    continue
        except Exception as e:
            print(f"     ⚠️  Error loading file.csv: {e}")
    
    # ========================================================================
    # 4. HTTP.CSV - Web activity (CRITICAL - WikiLeaks, Dropbox!)
    # ========================================================================
    http_file = os.path.join(cert_path, 'http.csv')
    if os.path.exists(http_file):
        print(f"\n  🌐 Loading http.csv... (CRITICAL FOR EXFILTRATION DETECTION!)")
        try:
            http_df = pd.read_csv(http_file, on_bad_lines='skip')
            print(f"     Rows: {len(http_df):,}")
            
            wikileaks_count = 0
            dropbox_count = 0
            upload_count = 0
            
            for _, row in http_df.iterrows():
                try:
                    # Parse timestamp properly - column index 1
                    timestamp_str = str(row.iloc[1]).strip()
                    
                    # URL is typically in column 5 or 6
                    url = ''
                    activity = ''
                    
                    if len(row) > 5:
                        url = str(row.iloc[5]).strip().lower()
                    if len(row) > 6:
                        activity = str(row.iloc[6]).strip().lower()
                    
                    # Remove quotes
                    url = url.strip('"').strip("'")
                    activity = activity.strip('"').strip("'")
                    
                    # Detect smoking guns! (check both URL and activity)
                    event_type = 'http_browse'
                    if 'wikileaks' in url or 'wikileaks' in activity:
                        event_type = 'http_WIKILEAKS_upload'  # SMOKING GUN!
                        wikileaks_count += 1
                    elif 'dropbox' in url or 'dropbox' in activity:
                        event_type = 'http_DROPBOX_upload'    # SMOKING GUN!
                        dropbox_count += 1
                    elif 'upload' in activity or 'www upload' in activity.lower():
                        event_type = 'http_upload'
                        upload_count += 1
                    elif 'download' in activity:
                        event_type = 'http_download'
                    
                    # Extract user and device
                    user = str(row.iloc[2]).strip().strip('"') if len(row) > 2 else ''
                    device = str(row.iloc[3]).strip().strip('"') if len(row) > 3 else ''
                    
                    # Skip if no user or timestamp
                    if not user or not timestamp_str:
                        continue
                    
                    all_events.append({
                        'user_id': user,
                        'timestamp': timestamp_str,
                        'event_type': event_type,
                        'device': device,
                        'ip_address': '',
                        'path': url[:200],  # Truncate long URLs
                        'source': 'http'
                    })
                except:
                    continue
            
            print(f"     🔴 WikiLeaks uploads: {wikileaks_count}")
            print(f"     🔴 Dropbox uploads: {dropbox_count}")
            print(f"     📤 Other uploads: {upload_count}")
            
            if wikileaks_count == 0 and dropbox_count == 0:
                print(f"     ⚠️  WARNING: No WikiLeaks/Dropbox detected!")
                print(f"        This may be expected - check scenario files for actual URLs")
            
        except Exception as e:
            print(f"     ⚠️  Error loading http.csv: {e}")
    else:
        print(f"\n  ❌ http.csv NOT FOUND!")
        print(f"     This file is CRITICAL for detecting WikiLeaks/Dropbox exfiltration!")
        print(f"     Without it, only 1-2 of 4 malicious users will be detectable.")
    
    # ========================================================================
    # 5. EMAIL.CSV - Email activity
    # ========================================================================
    email_file = os.path.join(cert_path, 'email.csv')
    if os.path.exists(email_file):
        print(f"\n  📧 Loading email.csv (first 100k rows)...")
        try:
            email_df = pd.read_csv(email_file, nrows=100000, on_bad_lines='skip')
            print(f"     Rows: {len(email_df):,}")
            
            for _, row in email_df.iterrows():
                try:
                    attachments = str(row.iloc[9]).strip().strip('"') if len(row) > 9 else ''
                    to_addr = str(row.iloc[4]).strip().strip('"') if len(row) > 4 else ''
                    
                    event_type = 'email_send'
                    if attachments and attachments != '' and attachments != 'nan':
                        event_type = 'email_send_attachment'
                    
                    user = str(row.iloc[2]).strip().strip('"')
                    timestamp = str(row.iloc[1]).strip().strip('"')
                    device = str(row.iloc[3]).strip().strip('"')
                    
                    all_events.append({
                        'user_id': user,
                        'timestamp': timestamp,
                        'event_type': event_type,
                        'device': device,
                        'ip_address': '',
                        'path': to_addr[:100],
                        'source': 'email'
                    })
                except:
                    continue
        except Exception as e:
            print(f"     ⚠️  Error loading email.csv: {e}")
    
    # ========================================================================
    # 6. CREATE UNIFIED DATAFRAME
    # ========================================================================
    print(f"\n  🔧 Creating unified DataFrame...")
    df = pd.DataFrame(all_events)
    
    if df.empty:
        print("❌ ERROR: No events loaded!")
        return None, None
    
    print(f"     Total events collected: {len(df):,}")
    
    # Show source breakdown
    source_counts = df['source'].value_counts().to_dict()
    print(f"     Sources: {source_counts}")
    
    # Convert timestamps
    df['timestamp'] = pd.to_datetime(df['timestamp'], errors='coerce', utc=True)
    initial_len = len(df)
    df = df.dropna(subset=['timestamp'])
    if len(df) < initial_len:
        print(f"     Dropped {initial_len - len(df):,} rows with invalid timestamps")
    
    # Filter to valid CERT date range (2010-2011)
    # CERT r6.2 covers Jan 2010 - Jun 2011
    valid_start = pd.Timestamp('2009-01-01', tz='UTC')
    valid_end = pd.Timestamp('2012-12-31', tz='UTC')
    
    before_filter = len(df)
    df = df[(df['timestamp'] >= valid_start) & (df['timestamp'] <= valid_end)]
    if len(df) < before_filter:
        dropped = before_filter - len(df)
        print(f"     Dropped {dropped:,} rows with dates outside 2010-2011 range")
        print(f"     Kept {len(df):,} events with valid timestamps")
    
    # Clean user_ids
    df = df[df['user_id'].notna() & (df['user_id'] != '') & 
            (df['user_id'] != 'nan') & (df['user_id'] != 'None')]
    
    # Limit to top users by activity
    user_counts = df['user_id'].value_counts()
    print(f"     Unique users before filtering: {len(user_counts)}")
    
    if len(user_counts) > max_users:
        top_users = user_counts.head(max_users).index.tolist()
        df = df[df['user_id'].isin(top_users)]
        print(f"     Limited to top {max_users} users")
    
    # Limit total events
    if len(df) > max_events:
        df = df.head(max_events)
        print(f"     Limited to {max_events:,} events")
    
    # Sort
    df = df.sort_values(['user_id', 'timestamp']).reset_index(drop=True)
    
    # Generate IPs from devices
    print(f"     Generating IP addresses from devices...")
    device_to_ip = {}
    for device in df['device'].unique():
        if device and device != '' and device != 'nan':
            parts = str(device).split('-')
            if len(parts) == 2 and parts[0] == 'PC':
                try:
                    num = int(parts[1])
                    device_to_ip[device] = f"10.{(num >> 8) & 255}.{num & 255}.{np.random.randint(1, 255)}"
                except:
                    device_to_ip[device] = f"10.{np.random.randint(1, 255)}.{np.random.randint(1, 255)}.{np.random.randint(1, 255)}"
    
    df['ip_address'] = df['device'].map(device_to_ip).fillna('')
    
    # ========================================================================
    # 7. LOAD GROUND TRUTH
    # ========================================================================
    gt_df = None
    answers_file = os.path.join(cert_path, 'answers.csv')
    
    if os.path.exists(answers_file):
        try:
            gt_df = pd.read_csv(answers_file)
            print(f"\n  ✅ Ground truth loaded: {len(gt_df)} malicious users")
        except Exception as e:
            print(f"\n  ⚠️  Error loading answers.csv: {e}")
    
    # ========================================================================
    # 8. SUMMARY
    # ========================================================================
    print(f"\n" + "="*70)
    print("DATASET SUMMARY")
    print("="*70)
    print(f"  Total events: {len(df):,}")
    print(f"  Users: {df['user_id'].nunique()}")
    print(f"  Event types: {df['event_type'].nunique()}")
    print(f"  Date range: {df['timestamp'].min()} to {df['timestamp'].max()}")
    
    # Calculate time span safely
    try:
        time_span = (df['timestamp'].max() - df['timestamp'].min()).days
        print(f"  Time span: {time_span} days")
    except:
        print(f"  Time span: (calculation skipped due to date range)")
    
    print(f"\n  Top 15 Event Types:")
    top_events = df['event_type'].value_counts().head(15)
    for event, count in top_events.items():
        pct = count / len(df) * 100
        marker = "🔴" if "WIKILEAKS" in event or "DROPBOX" in event else ""
        print(f"    {marker} {event:30s} {count:8,} ({pct:5.2f}%)")
    
    # Critical event check
    print(f"\n  🚨 Smoking Gun Detection:")
    wikileaks = len(df[df['event_type'] == 'http_WIKILEAKS_upload'])
    dropbox = len(df[df['event_type'] == 'http_DROPBOX_upload'])
    uploads = len(df[df['event_type'] == 'http_upload'])
    usb_connect = len(df[df['event_type'] == 'device_Connect'])
    
    print(f"    WikiLeaks uploads: {wikileaks:,} {'✅' if wikileaks > 0 else '❌'}")
    print(f"    Dropbox uploads: {dropbox:,} {'✅' if dropbox > 0 else '❌'}")
    print(f"    Other uploads: {uploads:,}")
    print(f"    USB connections: {usb_connect:,}")
    
    return df, gt_df


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def ensure_df_timestamp_utc(df: pd.DataFrame) -> pd.DataFrame:
    """Ensure timestamps are UTC-aware."""
    if "timestamp" not in df.columns:
        return df
    df = df.copy()
    df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce", utc=True)
    df = df.dropna(subset=["timestamp"])
    df = df.sort_values(["user_id", "timestamp"]).reset_index(drop=True)
    return df


def label_windows(windows: list, hijack_df: pd.DataFrame) -> np.ndarray:
    """Label windows as hijacked (1) or normal (0)."""
    if hijack_df is None or hijack_df.empty:
        return np.zeros(len(windows), dtype=int)
    
    h = hijack_df.copy()
    h["start"] = pd.to_datetime(h["start"], errors="coerce", utc=True)
    h["end"] = pd.to_datetime(h["end"], errors="coerce", utc=True)
    h = h.dropna(subset=["user_id", "start", "end"])
    
    labels = []
    for w in windows:
        uid = w["user_id"]
        ws = pd.to_datetime(w["start_time"], utc=True)
        we = pd.to_datetime(w["end_time"], utc=True)
        
        intervals = h[h["user_id"] == uid]
        is_hijacked = 0
        
        for _, row in intervals.iterrows():
            if not (we < row["start"] or ws > row["end"]):
                is_hijacked = 1
                break
        
        labels.append(is_hijacked)
    
    return np.array(labels, dtype=int)


# =============================================================================
# MAIN
# =============================================================================

def main():
    print("=" * 70)
    print("CERT COMPREHENSIVE ANALYSIS")
    print("Hadith + Temporal Features with ALL Data Sources")
    print("=" * 70)
    
    # -------------------------------------------------------------------------
    # STEP 1: Configure
    # -------------------------------------------------------------------------
    CERT_PATH = r"F:\Projects\Security\cert"
    OUTPUT_DIR = r"F:\Projects\Security\results_cert_comprehensive"
    
    print(f"\nConfiguration:")
    print(f"  CERT Directory: {CERT_PATH}")
    print(f"  Output Directory: {OUTPUT_DIR}")
    
    if not os.path.exists(CERT_PATH):
        print(f"\n❌ ERROR: CERT directory not found")
        sys.exit(1)
    
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    print("✅ Paths verified!")
    
    # -------------------------------------------------------------------------
    # STEP 2: Load with Comprehensive Loader
    # -------------------------------------------------------------------------
    print("\n" + "=" * 70)
    print("LOADING CERT WITH COMPREHENSIVE LOADER")
    print("=" * 70)
    
    df, gt_df = load_cert_comprehensive(
        CERT_PATH,
        max_events=1_500_000,  # More events to capture all users
        max_users=200
    )
    
    if df is None or df.empty:
        print("❌ ERROR: Failed to load dataset")
        sys.exit(1)
    
    df = ensure_df_timestamp_utc(df)
    
    # -------------------------------------------------------------------------
    # STEP 3: Ground Truth
    # -------------------------------------------------------------------------
    print("\n" + "=" * 70)
    print("GROUND TRUTH")
    print("=" * 70)
    
    hijack_df = None
    
    if gt_df is not None and not gt_df.empty:
        print(f"\n✅ Found ground truth: {len(gt_df)} rows")
        print(f"   Columns: {gt_df.columns.tolist()}")
        
        # Find user column
        user_col = None
        for col in ['user', 'user_id', 'userid']:
            if col in gt_df.columns:
                user_col = col
                break
        
        if user_col:
            malicious_users = gt_df[user_col].unique()
            print(f"   Malicious users: {list(malicious_users)}")
            
            # Create intervals from full user timeline
            intervals = []
            for user_id in malicious_users:
                user_events = df[df['user_id'] == str(user_id)]
                if len(user_events) > 0:
                    intervals.append({
                        'user_id': str(user_id),
                        'start': user_events['timestamp'].min(),
                        'end': user_events['timestamp'].max()
                    })
                    
                    # Show what this user did
                    print(f"\n   📊 {user_id} Activity:")
                    print(f"      Events: {len(user_events):,}")
                    print(f"      Top 5 event types:")
                    for evt, cnt in user_events['event_type'].value_counts().head(5).items():
                        marker = "🔴" if "WIKILEAKS" in evt or "DROPBOX" in evt else "  "
                        print(f"        {marker} {evt}: {cnt}")
                else:
                    print(f"   ⚠️  {user_id}: NOT FOUND in dataset!")
            
            if intervals:
                hijack_df = pd.DataFrame(intervals)
                hijack_df['start'] = pd.to_datetime(hijack_df['start'], utc=True)
                hijack_df['end'] = pd.to_datetime(hijack_df['end'], utc=True)
                print(f"\n   ✅ Created {len(hijack_df)} intervals")
                print(f"   Detectable users: {hijack_df['user_id'].tolist()}")
    
    if hijack_df is None or hijack_df.empty:
        print("\n❌ ERROR: No ground truth available")
        sys.exit(1)
    
    # -------------------------------------------------------------------------
    # STEP 4: Windows
    # -------------------------------------------------------------------------
    print("\n" + "=" * 70)
    print("CONSTRUCTING WINDOWS")
    print("=" * 70)
    
    windows = construct_windows(df, window_size=50, step_size=25)
    print(f"\n✅ Created {len(windows):,} windows")
    
    y = label_windows(windows, hijack_df)
    pos = int(y.sum())
    neg = len(y) - pos
    
    print(f"   Positive: {pos:,} ({pos/len(y)*100:.2f}%)")
    print(f"   Negative: {neg:,} ({neg/len(y)*100:.2f}%)")
    
    if pos < 2:
        print("\n❌ ERROR: Not enough positive samples")
        sys.exit(1)
    
    # -------------------------------------------------------------------------
    # STEP 5: Features
    # -------------------------------------------------------------------------
    print("\n" + "=" * 70)
    print("EXTRACTING FEATURES")
    print("=" * 70)
    
    print("\n  Building user history...")
    user_history = build_user_history(df)
    
    all_event_types = df["event_type"].unique()
    print(f"  Event types: {len(all_event_types)}")
    
    print("  Building transition matrices...")
    user_transitions = build_transition_matrices(df, all_event_types)
    
    print("\n  Extracting Hadith features (26)...")
    X_hadith = []
    for i, w in enumerate(windows):
        if i % 2000 == 0 and i > 0:
            print(f"    {i}/{len(windows)} ({i/len(windows)*100:.0f}%)")
        X_hadith.append(build_hadith_features(w, df, user_history, all_event_types))
    X_hadith = np.nan_to_num(np.array(X_hadith), nan=0, posinf=0, neginf=0)
    print(f"  ✅ Hadith: {X_hadith.shape}")
    
    print("\n  Extracting Temporal features (16)...")
    X_temporal = []
    for i, w in enumerate(windows):
        if i % 2000 == 0 and i > 0:
            print(f"    {i}/{len(windows)} ({i/len(windows)*100:.0f}%)")
        X_temporal.append(
            build_temporal_sequence_features(w, df, user_history, all_event_types, user_transitions)
        )
    X_temporal = np.nan_to_num(np.array(X_temporal), nan=0, posinf=0, neginf=0)
    print(f"  ✅ Temporal: {X_temporal.shape}")
    
    X_combined = np.nan_to_num(np.hstack([X_hadith, X_temporal]), nan=0, posinf=0, neginf=0)
    print(f"  ✅ Combined: {X_combined.shape}")
    
    # -------------------------------------------------------------------------
    # STEP 6-8: Train & Evaluate
    # -------------------------------------------------------------------------
    print("\n" + "=" * 70)
    print("TRAINING & EVALUATION")
    print("=" * 70)
    
    (X_h_train, X_h_test, X_t_train, X_t_test, X_c_train, X_c_test,
     y_train, y_test) = train_test_split(
        X_hadith, X_temporal, X_combined, y,
        test_size=0.3, stratify=y, random_state=RANDOM_STATE
    )
    
    print(f"\n✅ Split:")
    print(f"   Train: {len(y_train):,} (Pos: {int(y_train.sum()):,})")
    print(f"   Test:  {len(y_test):,} (Pos: {int(y_test.sum()):,})")
    
    # Scale
    scaler_h = StandardScaler()
    X_h_test_s = scaler_h.fit_transform(X_h_train).transform(X_h_test) if False else scaler_h.fit(X_h_train).transform(X_h_test)
    
    scaler_t = StandardScaler()
    X_t_test_s = scaler_t.fit(X_t_train).transform(X_t_test)
    
    scaler_c = StandardScaler()
    X_c_train_s = scaler_c.fit_transform(X_c_train)
    X_c_test_s = scaler_c.transform(X_c_test)
    
    X_h_train_s = scaler_h.transform(X_h_train)
    X_t_train_s = scaler_t.transform(X_t_train)
    
    print("\n  Training models...")
    results = []
    
    # Combined + RF
    rf_combined = RandomForestClassifier(n_estimators=100, class_weight="balanced", 
                                         random_state=RANDOM_STATE, n_jobs=-1)
    rf_combined.fit(X_c_train_s, y_train)
    scores_c = rf_combined.predict_proba(X_c_test_s)[:, 1]
    roc_c = roc_auc_score(y_test, scores_c)
    pr_c = average_precision_score(y_test, scores_c)
    print(f"    Combined + RF: ROC={roc_c:.4f}, PR={pr_c:.4f}")
    results.append(("Combined + RF", roc_c, pr_c))
    
    # Original + RF
    rf_hadith = RandomForestClassifier(n_estimators=100, class_weight="balanced",
                                        random_state=RANDOM_STATE, n_jobs=-1)
    rf_hadith.fit(X_h_train_s, y_train)
    scores_h = rf_hadith.predict_proba(X_h_test_s)[:, 1]
    roc_h = roc_auc_score(y_test, scores_h)
    pr_h = average_precision_score(y_test, scores_h)
    print(f"    Original + RF: ROC={roc_h:.4f}, PR={pr_h:.4f}")
    results.append(("Original + RF", roc_h, pr_h))
    
    # Temporal + RF
    rf_temporal = RandomForestClassifier(n_estimators=100, class_weight="balanced",
                                          random_state=RANDOM_STATE, n_jobs=-1)
    rf_temporal.fit(X_t_train_s, y_train)
    scores_t = rf_temporal.predict_proba(X_t_test_s)[:, 1]
    roc_t = roc_auc_score(y_test, scores_t)
    pr_t = average_precision_score(y_test, scores_t)
    print(f"    Temporal + RF: ROC={roc_t:.4f}, PR={pr_t:.4f}")
    results.append(("Temporal + RF", roc_t, pr_t))
    
    # -------------------------------------------------------------------------
    # RESULTS
    # -------------------------------------------------------------------------
    print("\n" + "=" * 70)
    print("RESULTS")
    print("=" * 70)
    
    results_df = pd.DataFrame(results, columns=["Approach", "ROC-AUC", "PR-AUC"])
    print("\n" + results_df.to_string(index=False))
    
    improvement = (roc_c - roc_h) / (roc_h + 1e-12) * 100
    
    print(f"\n  Combined: {roc_c:.4f}")
    print(f"  Original: {roc_h:.4f}")
    print(f"  Temporal: {roc_t:.4f}")
    print(f"  Improvement: {improvement:+.2f}%")
    
    # Feature importance
    feature_names = [
        "adalah_active_days", "adalah_total_events", "adalah_account_age",
        "adalah_consistency", "adalah_avg_events",
        "dabt_login_success", "dabt_delta_fail", "dabt_burstiness",
        "dabt_outside_hours", "dabt_timing_entropy", "dabt_vocab_div",
        "dabt_sensitive_ratio",
        "isnad_ip_consistency", "isnad_ip_match", "isnad_subnet_match",
        "isnad_geo_impossible", "isnad_session_discont", "isnad_new_ip_rate",
        "rep_duration", "rep_trust", "rep_penalty", "rep_trend",
        "anom_kl_div", "anom_hour", "anom_path", "anom_l2_dist",
        "temp_kl_transition", "temp_rare_transitions", "temp_seq_entropy",
        "temp_ngram_anomaly", "temp_run_anomaly",
        "temp_behavior_drift", "temp_autocorr", "temp_timing_shift",
        "temp_dow_divergence", "temp_rate_drift",
        "temp_subnet_drift", "temp_ip_switch_rate", "temp_device_trans_anom",
        "temp_failure_trend", "temp_cumul_suspicious", "temp_risk_accel",
    ]
    
    importances = rf_combined.feature_importances_
    sorted_idx = np.argsort(importances)[::-1]
    
    print("\n  Top 10 Features:")
    for i in range(10):
        idx = sorted_idx[i]
        marker = "🔄" if "temp_" in feature_names[idx] else "📊"
        print(f"    {i+1:2d}. {marker} {feature_names[idx]:30s} {importances[idx]:.4f}")
    
    # Save
    results_df.to_csv(os.path.join(OUTPUT_DIR, "results.csv"), index=False)
    print(f"\n✅ Saved to: {OUTPUT_DIR}/")
    
    print("\n" + "=" * 70)
    print("✅ ANALYSIS COMPLETE!")
    print("=" * 70)
    print(f"\n🎯 Key Findings:")
    print(f"  - Detected {len(hijack_df)} malicious users")
    print(f"  - ROC-AUC: {roc_c:.4f}")
    print(f"  - Improvement: {improvement:+.2f}%")


if __name__ == "__main__":
    main()

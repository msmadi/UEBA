"""
MULTI-DATASET IMPLEMENTATION: Hadith + Temporal Features
Supports CLUE-LDS, CERT, LANL, UGR16, Azure, and Adversarial Variants

USAGE:
======
# Single dataset
python compare_features_MULTI_DATASET.py --dataset clue-lds --csv data.csv

# Cross-dataset comparison
python compare_features_MULTI_DATASET.py --cross-dataset \
    --clue-csv clue.csv --cert-dir cert/ --lanl-dir lanl/

# With adversarial variants
python compare_features_MULTI_DATASET.py --dataset clue-lds --csv data.csv --adversarial

# Jupyter
from compare_features_MULTI_DATASET import run_cross_dataset_evaluation
results = run_cross_dataset_evaluation([
    {'name': 'CLUE-LDS', 'type': 'clue-lds', 'path': 'data.csv'},
    {'name': 'CERT-r6.2', 'type': 'cert', 'path': 'cert/'},
])
"""

import os
import sys
import gzip
import argparse
from datetime import datetime, timedelta
from typing import Dict, List, Tuple
import warnings

import numpy as np
import pandas as pd
from scipy.stats import entropy
from scipy.spatial.distance import jensenshannon

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_auc_score, average_precision_score, f1_score
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier

import matplotlib.pyplot as plt
import seaborn as sns

warnings.filterwarnings('ignore')
sns.set_style('whitegrid')

RANDOM_STATE = 42
np.random.seed(RANDOM_STATE)

# ============================================================================
# DATASET LOADERS
# ============================================================================

class DatasetLoader:
    """Unified dataset loader supporting multiple formats."""
    
    SUPPORTED = ['clue-lds', 'cert', 'lanl', 'ugr16', 'azure']
    
    def __init__(self, dataset_type: str, data_path: str):
        self.dataset_type = dataset_type.lower()
        self.data_path = data_path
        
        if self.dataset_type not in self.SUPPORTED:
            raise ValueError(f"Unsupported dataset: {dataset_type}")
    
    def load(self, max_events: int = 1_000_000, 
             max_users: int = 500) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        Load dataset and ground truth.
        
        Returns:
            (events_df, ground_truth_df)
        """
        print(f"\n{'='*70}")
        print(f"LOADING DATASET: {self.dataset_type.upper()}")
        print(f"{'='*70}")
        
        if self.dataset_type == 'clue-lds':
            df = self._load_clue_lds(max_events, max_users)
            gt_df = pd.DataFrame()  # Will inject synthetically
            
        elif self.dataset_type == 'cert':
            df = self._load_cert(max_events, max_users)
            gt_df = self._load_cert_ground_truth()
            
        elif self.dataset_type == 'lanl':
            df = self._load_lanl(max_events, max_users)
            gt_df = self._load_lanl_ground_truth()
            
        elif self.dataset_type == 'ugr16':
            df = self._load_ugr16(max_events, max_users)
            gt_df = self._load_ugr16_ground_truth()
            
        elif self.dataset_type == 'azure':
            df = self._load_azure(max_events, max_users)
            gt_df = self._load_azure_ground_truth()
        
        if df is not None:
            self._print_summary(df, gt_df)
        
        return df, gt_df
    
    def _load_clue_lds(self, max_events, max_users):
        """Load CLUE-LDS from CSV."""
        if not os.path.exists(self.data_path):
            print(f"ERROR: File not found: {self.data_path}")
            return None
        
        df = pd.read_csv(self.data_path, low_memory=False)
        print(f"  Loaded {len(df):,} rows")
        
        # Column mapping
        col_map = {
            'uid': 'user_id', 'userId': 'user_id', 'user': 'user_id',
            'time': 'timestamp', '@timestamp': 'timestamp',
            'type': 'event_type', 'eventType': 'event_type',
            'ip': 'ip_address', 'sourceIp': 'ip_address'
        }
        
        for old, new in col_map.items():
            if old in df.columns and new not in df.columns:
                df = df.rename(columns={old: new})
        
        # Add missing columns
        if 'path' not in df.columns:
            df['path'] = ''
        if 'ip_address' not in df.columns:
            df['ip_address'] = ''
        
        # Type conversion
        df['user_id'] = df['user_id'].astype(str)
        df['event_type'] = df['event_type'].astype(str).fillna('unknown')
        df['timestamp'] = pd.to_datetime(df['timestamp'], errors='coerce')
        df = df.dropna(subset=['timestamp'])
        
        # Limit users
        if df['user_id'].nunique() > max_users:
            top_users = df['user_id'].value_counts().head(max_users).index
            df = df[df['user_id'].isin(top_users)]
        
        # Limit events
        if len(df) > max_events:
            df = df.head(max_events)
        
        df = df.sort_values(['user_id', 'timestamp']).reset_index(drop=True)
        
        # Generate IPs if missing
        if df['ip_address'].isna().all() or (df['ip_address'] == '').all():
            user_ips = {u: f"192.168.{np.random.randint(1,255)}.{np.random.randint(1,255)}" 
                       for u in df['user_id'].unique()}
            df['ip_address'] = df['user_id'].map(user_ips)
        
        return df
    
    def _load_cert(self, max_events, max_users):
        """Load CERT Insider Threat dataset."""
        print(f"  Loading CERT from: {self.data_path}")
        
        # CERT has multiple CSVs
        logon_file = os.path.join(self.data_path, 'logon.csv')
        device_file = os.path.join(self.data_path, 'device.csv')
        file_file = os.path.join(self.data_path, 'file.csv')
        email_file = os.path.join(self.data_path, 'email.csv')
        
        events = []
        
        # Load logon events
        if os.path.exists(logon_file):
            print(f"    Loading logon.csv...")
            logon_df = pd.read_csv(logon_file)
            for _, row in logon_df.iterrows():
                events.append({
                    'user_id': str(row['user']),
                    'timestamp': pd.to_datetime(row['date']),
                    'event_type': f"logon_{row['activity']}",
                    'device': str(row.get('pc', '')),
                    'ip_address': '',
                    'path': '',
                })
        
        # Load device events
        if os.path.exists(device_file):
            print(f"    Loading device.csv...")
            device_df = pd.read_csv(device_file)
            for _, row in device_df.iterrows():
                events.append({
                    'user_id': str(row['user']),
                    'timestamp': pd.to_datetime(row['date']),
                    'event_type': f"device_{row['activity']}",
                    'device': str(row.get('pc', '')),
                    'ip_address': '',
                    'path': '',
                })
        
        # Load file events
        if os.path.exists(file_file):
            print(f"    Loading file.csv...")
            file_df = pd.read_csv(file_file)
            for _, row in file_df.head(min(len(file_df), max_events // 2)).iterrows():
                events.append({
                    'user_id': str(row['user']),
                    'timestamp': pd.to_datetime(row['date']),
                    'event_type': f"file_{str(row.get('filename', '')).split('.')[-1]}",
                    'device': str(row.get('pc', '')),
                    'ip_address': '',
                    'path': str(row.get('filename', '')),
                })
        
        if not events:
            print("    ERROR: No CERT files found")
            return None
        
        df = pd.DataFrame(events)
        df = df.sort_values(['user_id', 'timestamp']).reset_index(drop=True)
        
        # Limit users
        if df['user_id'].nunique() > max_users:
            top_users = df['user_id'].value_counts().head(max_users).index
            df = df[df['user_id'].isin(top_users)]
        
        # Limit events
        if len(df) > max_events:
            df = df.head(max_events)
        
        # Generate IPs from devices
        device_to_ip = {}
        for device in df['device'].unique():
            if device and device != '':
                device_to_ip[device] = f"10.{np.random.randint(0,255)}.{np.random.randint(0,255)}.{np.random.randint(1,255)}"
        
        df['ip_address'] = df['device'].map(device_to_ip).fillna('')
        
        return df
    
    def _load_cert_ground_truth(self):
        """Load CERT ground truth."""
        answers_file = os.path.join(self.data_path, 'answers.csv')
        
        if not os.path.exists(answers_file):
            # Fallback to known malicious users
            print("    Using known CERT malicious users")
            malicious_users = ['ACM2278', 'CMP2946', 'MBG3183', 
                              'AAG0007', 'AAM0062', 'AJN0130',
                              'AAA0073', 'AAG0080', 'ABA0122']
            return pd.DataFrame({
                'user_id': malicious_users,
                'scenario': 'insider_threat',
                'start': None,
                'end': None
            })
        
        return pd.read_csv(answers_file)
    
    def _load_lanl(self, max_events, max_users):
        """Load LANL authentication data."""
        auth_file = os.path.join(self.data_path, 'auth.txt.gz')
        
        if not os.path.exists(auth_file):
            print(f"    ERROR: File not found: {auth_file}")
            return None
        
        print(f"    Loading LANL auth data...")
        events = []
        
        with gzip.open(auth_file, 'rt') as f:
            for i, line in enumerate(f):
                if i >= max_events:
                    break
                
                if i % 100000 == 0:
                    print(f"      {i:,} events loaded...")
                
                parts = line.strip().split(',')
                if len(parts) < 9:
                    continue
                
                timestamp, src_user, dst_user, src_comp, dst_comp, auth_type, logon_type, orientation, success = parts
                
                user_id = src_user.split('@')[0]
                
                events.append({
                    'user_id': user_id,
                    'timestamp': pd.to_datetime(int(timestamp), unit='s'),
                    'event_type': f"{auth_type}_{logon_type}",
                    'device': src_comp,
                    'ip_address': '',
                    'path': '',
                })
        
        df = pd.DataFrame(events)
        df = df.sort_values(['user_id', 'timestamp']).reset_index(drop=True)
        
        # Limit users
        if df['user_id'].nunique() > max_users:
            top_users = df['user_id'].value_counts().head(max_users).index
            df = df[df['user_id'].isin(top_users)]
        
        # Generate IPs from computers
        device_to_ip = {}
        for device in df['device'].unique():
            if device:
                device_to_ip[device] = f"10.{np.random.randint(0,255)}.{np.random.randint(0,255)}.{np.random.randint(1,255)}"
        
        df['ip_address'] = df['device'].map(device_to_ip).fillna('')
        
        return df
    
    def _load_lanl_ground_truth(self):
        """Load LANL red team events."""
        redteam_file = os.path.join(self.data_path, 'redteam.txt.gz')
        
        if not os.path.exists(redteam_file):
            print("    No LANL red team file found")
            return pd.DataFrame()
        
        # Parse red team events
        # Format: time,src_user@src_domain,src_computer,dst_user@dst_domain,dst_computer
        events = []
        with gzip.open(redteam_file, 'rt') as f:
            for line in f:
                parts = line.strip().split(',')
                if len(parts) >= 2:
                    timestamp = int(parts[0])
                    user = parts[1].split('@')[0]
                    events.append({
                        'user_id': user,
                        'timestamp': pd.to_datetime(timestamp, unit='s'),
                        'type': 'red_team'
                    })
        
        return pd.DataFrame(events)
    
    def _load_ugr16(self, max_events, max_users):
        """Load UGR16 NetFlow data."""
        # Placeholder - implement based on UGR16 format
        print("    UGR16 loader not yet implemented")
        return None
    
    def _load_ugr16_ground_truth(self):
        return pd.DataFrame()
    
    def _load_azure(self, max_events, max_users):
        """Load Azure AD logs."""
        # Placeholder - implement based on Azure format
        print("    Azure loader not yet implemented")
        return None
    
    def _load_azure_ground_truth(self):
        return pd.DataFrame()
    
    def _print_summary(self, df, gt_df):
        """Print dataset summary."""
        print(f"\n  ✓ Dataset loaded:")
        print(f"    Events: {len(df):,}")
        print(f"    Users: {df['user_id'].nunique()}")
        print(f"    Event types: {df['event_type'].nunique()}")
        print(f"    Date range: {df['timestamp'].min()} to {df['timestamp'].max()}")
        
        if not gt_df.empty:
            print(f"    Ground truth: {len(gt_df)} malicious users/events")


# ============================================================================
# ADVERSARIAL VARIANTS
# ============================================================================

def generate_adversarial_variants(df: pd.DataFrame, hijack_df: pd.DataFrame) -> Dict[str, Tuple]:
    """
    Generate adversarial attack variants that evade detection.
    
    Returns:
        Dict mapping variant name to (modified_df, modified_hijack_df)
    """
    print(f"\n{'='*70}")
    print("GENERATING ADVERSARIAL VARIANTS")
    print(f"{'='*70}")
    
    variants = {}
    
    # 1. IP-Stable Attacker (no IP changes)
    print("  1. IP-Stable Attacker...")
    df_stable = df.copy()
    for _, hijack in hijack_df.iterrows():
        mask = ((df_stable['user_id'] == hijack['user_id']) &
                (df_stable['timestamp'] >= hijack['start']) &
                (df_stable['timestamp'] <= hijack['end']))
        
        # Keep original IP during hijack
        user_events = df_stable[df_stable['user_id'] == hijack['user_id']]
        primary_ip = user_events[user_events['timestamp'] < hijack['start']]['ip_address'].mode()
        if len(primary_ip) > 0:
            df_stable.loc[mask, 'ip_address'] = primary_ip.iloc[0]
    
    variants['ip_stable'] = (df_stable, hijack_df)
    
    # 2. Slow-Burn (low rate malicious activity)
    print("  2. Slow-Burn Attack...")
    df_slow = df.copy()
    hijack_df_slow = hijack_df.copy()
    
    # Remove most injected suspicious events, keep only 1-2 per hour
    for _, hijack in hijack_df.iterrows():
        mask = ((df_slow['user_id'] == hijack['user_id']) &
                (df_slow['timestamp'] >= hijack['start']) &
                (df_slow['timestamp'] <= hijack['end']) &
                (df_slow['event_type'] == 'suspicious_action'))
        
        susp_events = df_slow[mask]
        if len(susp_events) > 10:
            keep_indices = np.random.choice(susp_events.index, size=min(10, len(susp_events)), replace=False)
            drop_indices = [i for i in susp_events.index if i not in keep_indices]
            df_slow = df_slow.drop(drop_indices)
    
    variants['slow_burn'] = (df_slow, hijack_df_slow)
    
    # 3. Business-Hours (no time anomaly)
    print("  3. Business-Hours Attack...")
    df_hours = df.copy()
    
    for _, hijack in hijack_df.iterrows():
        mask = ((df_hours['user_id'] == hijack['user_id']) &
                (df_hours['timestamp'] >= hijack['start']) &
                (df_hours['timestamp'] <= hijack['end']) &
                (df_hours['event_type'] == 'suspicious_action'))
        
        # Move all suspicious events to business hours (9-17)
        for idx in df_hours[mask].index:
            original_time = df_hours.loc[idx, 'timestamp']
            hour = np.random.randint(9, 17)
            df_hours.loc[idx, 'timestamp'] = original_time.replace(hour=hour)
    
    df_hours = df_hours.sort_values(['user_id', 'timestamp']).reset_index(drop=True)
    variants['business_hours'] = (df_hours, hijack_df)
    
    # 4. Path-Mimicry (use common paths)
    print("  4. Path-Mimicry Attack...")
    df_mimic = df.copy()
    
    for _, hijack in hijack_df.iterrows():
        user_df = df_mimic[df_mimic['user_id'] == hijack['user_id']]
        hist_paths = user_df[user_df['timestamp'] < hijack['start']]['path'].value_counts()
        
        if len(hist_paths) > 0:
            common_paths = hist_paths.head(5).index.tolist()
            
            mask = ((df_mimic['user_id'] == hijack['user_id']) &
                    (df_mimic['timestamp'] >= hijack['start']) &
                    (df_mimic['timestamp'] <= hijack['end']) &
                    (df_mimic['event_type'] == 'suspicious_action'))
            
            for idx in df_mimic[mask].index:
                df_mimic.loc[idx, 'path'] = np.random.choice(common_paths)
    
    variants['path_mimicry'] = (df_mimic, hijack_df)
    
    # 5. Combined Evasion (all tactics)
    print("  5. Combined Evasion...")
    df_combined = df_slow.copy()
    
    # Apply IP stability
    for _, hijack in hijack_df.iterrows():
        mask = ((df_combined['user_id'] == hijack['user_id']) &
                (df_combined['timestamp'] >= hijack['start']) &
                (df_combined['timestamp'] <= hijack['end']))
        
        user_events = df_combined[df_combined['user_id'] == hijack['user_id']]
        primary_ip = user_events[user_events['timestamp'] < hijack['start']]['ip_address'].mode()
        if len(primary_ip) > 0:
            df_combined.loc[mask, 'ip_address'] = primary_ip.iloc[0]
    
    # Apply business hours
    for _, hijack in hijack_df.iterrows():
        mask = ((df_combined['user_id'] == hijack['user_id']) &
                (df_combined['timestamp'] >= hijack['start']) &
                (df_combined['timestamp'] <= hijack['end']) &
                (df_combined['event_type'] == 'suspicious_action'))
        
        for idx in df_combined[mask].index:
            original_time = df_combined.loc[idx, 'timestamp']
            hour = np.random.randint(9, 17)
            df_combined.loc[idx, 'timestamp'] = original_time.replace(hour=hour)
    
    df_combined = df_combined.sort_values(['user_id', 'timestamp']).reset_index(drop=True)
    variants['combined_evasion'] = (df_combined, hijack_df)
    
    print(f"\n  ✓ Generated {len(variants)} adversarial variants")
    
    return variants


# ============================================================================
# HIJACK INJECTION
# ============================================================================

def inject_hijacks(df: pd.DataFrame, n_hijacks: int = 50, 
                   dataset_type: str = 'clue-lds') -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Inject hijacks appropriate for dataset type."""
    
    df = df.copy()
    user_counts = df.groupby('user_id').size()
    eligible = user_counts[user_counts >= 50].index.tolist()
    np.random.shuffle(eligible)
    
    n_hijacks = min(n_hijacks, len(eligible))
    hijack_intervals = []
    injected_events = []
    
    for i in range(n_hijacks):
        user_id = eligible[i]
        user_df = df[df['user_id'] == user_id]
        
        t_min, t_max = user_df['timestamp'].min(), user_df['timestamp'].max()
        time_range = (t_max - t_min).total_seconds()
        
        if time_range < 3600:
            continue
        
        start_offset = np.random.uniform(0.2, 0.6) * time_range
        hijack_start = t_min + timedelta(seconds=start_offset)
        hijack_end = hijack_start + timedelta(hours=8)
        
        hijack_intervals.append({
            'user_id': user_id,
            'start': hijack_start,
            'end': hijack_end
        })
        
        # Inject suspicious events
        for j in range(np.random.randint(5, 15)):
            event_time = hijack_start + timedelta(seconds=np.random.uniform(0, 8*3600))
            
            injected_events.append({
                'user_id': user_id,
                'timestamp': event_time,
                'event_type': 'suspicious_action',
                'path': '/admin/export',
                'ip_address': f"10.{np.random.randint(0,255)}.{np.random.randint(0,255)}.{np.random.randint(1,255)}",
                'device': ''
            })
    
    if injected_events:
        inj_df = pd.DataFrame(injected_events)
        inj_df['timestamp'] = pd.to_datetime(inj_df['timestamp'])
        df = pd.concat([df, inj_df], ignore_index=True)
        df = df.sort_values(['user_id', 'timestamp']).reset_index(drop=True)
    
    hijack_df = pd.DataFrame(hijack_intervals)
    print(f"\n  ✓ Injected {len(hijack_df)} hijacks with {len(injected_events)} events")
    
    return df, hijack_df


# ============================================================================
# IMPORT FULL FEATURE IMPLEMENTATION
# ============================================================================

# Import from the full implementation
try:
    from compare_features_temporal_FULL import (
        construct_windows, label_windows,
        build_user_history, build_transition_matrices,
        build_hadith_features, build_temporal_sequence_features,
        build_raw_count_features, build_minimal_features
    )
    FEATURES_AVAILABLE = True
except ImportError:
    print("WARNING: Could not import full feature implementation")
    FEATURES_AVAILABLE = False


# ============================================================================
# SIMPLIFIED FEATURE EXTRACTION (fallback)
# ============================================================================

def build_simple_features(windows, df):
    """Simplified feature extraction if full implementation unavailable."""
    user_history = {}
    for user_id, user_df in df.groupby('user_id'):
        user_history[user_id] = user_df.sort_values('timestamp')
    
    X_hadith = []
    X_temporal = []
    
    for win in windows:
        idx = win['indices']
        w_df = df.loc[idx]
        uid = win['user_id']
        past = user_history[uid][user_history[uid]['timestamp'] < win['start_time']]
        
        # Simple Hadith features (10)
        hadith = [
            len(past),
            w_df['event_type'].nunique(),
            w_df['ip_address'].nunique(),
            (w_df['timestamp'].max() - w_df['timestamp'].min()).total_seconds(),
            w_df['timestamp'].dt.hour.mean(),
            w_df['timestamp'].dt.hour.std() if len(w_df) > 1 else 0,
            len(w_df[w_df['event_type'].str.contains('admin|delete', case=False, na=False)]) / len(w_df),
            len(past.groupby(past['timestamp'].dt.date)) if len(past) > 0 else 0,
            w_df['path'].nunique(),
            len(set(w_df['ip_address']) - set(past['ip_address'])) / max(1, w_df['ip_address'].nunique()) if len(past) > 0 else 0
        ]
        
        # Simple temporal features (6)
        temporal = [0] * 6
        if len(past) > 0 and len(w_df) > 1:
            # Behavior drift
            if len(past) > 7:
                recent = past.tail(50)
                older = past.head(50)
                if len(recent) > 0 and len(older) > 0:
                    r_dist = recent['event_type'].value_counts(normalize=True)
                    o_dist = older['event_type'].value_counts(normalize=True)
                    temporal[0] = ((r_dist.reindex(o_dist.index, fill_value=0) - o_dist)**2).sum()**0.5
            
            # Timing shift
            temporal[1] = abs(w_df['timestamp'].dt.hour.median() - past['timestamp'].dt.hour.median()) / 24.0
            
            # IP switches
            ips = w_df['ip_address'].values
            temporal[2] = sum(1 for i in range(1, len(ips)) if ips[i] != ips[i-1]) / (len(ips) - 1)
            
            # Event rate change
            past_rate = len(past) / max(1, (past['timestamp'].max() - past['timestamp'].min()).days + 1)
            curr_rate = len(w_df) / max(1, (w_df['timestamp'].max() - w_df['timestamp'].min()).days + 1)
            temporal[3] = abs(curr_rate - past_rate) / (past_rate + 1e-9)
            
            # After hours
            business_hours = (w_df['timestamp'].dt.hour >= 8) & (w_df['timestamp'].dt.hour <= 17)
            temporal[4] = (~business_hours).sum() / len(w_df)
        
        X_hadith.append(hadith)
        X_temporal.append(temporal)
    
    return np.nan_to_num(np.array(X_hadith)), np.nan_to_num(np.array(X_temporal))


# ============================================================================
# CROSS-DATASET EVALUATION
# ============================================================================

def run_single_dataset(dataset_config: Dict) -> Dict:
    """Run evaluation on single dataset."""
    
    name = dataset_config['name']
    ds_type = dataset_config['type']
    path = dataset_config['path']
    max_events = dataset_config.get('max_events', 500_000)
    max_users = dataset_config.get('max_users', 100)
    
    print(f"\n{'='*70}")
    print(f"EVALUATING: {name}")
    print(f"{'='*70}")
    
    # Load dataset
    loader = DatasetLoader(ds_type, path)
    df, gt_df = loader.load(max_events, max_users)
    
    if df is None:
        return {'name': name, 'error': 'Load failed'}
    
    # Inject hijacks (or use ground truth)
    if gt_df.empty:
        df, hijack_df = inject_hijacks(df, n_hijacks=30, dataset_type=ds_type)
    else:
        hijack_df = gt_df
    
    # Build windows
    windows = construct_windows(df, window_size=50, step_size=25) if FEATURES_AVAILABLE else []
    if not windows:
        print("  ERROR: No windows created")
        return {'name': name, 'error': 'No windows'}
    
    y = label_windows(windows, hijack_df) if FEATURES_AVAILABLE else np.array([])
    print(f"  Windows: {len(windows)}, Positive: {y.sum()}")
    
    # Extract features
    if FEATURES_AVAILABLE:
        user_history = build_user_history(df)
        all_event_types = df['event_type'].unique()
        user_transitions = build_transition_matrices(df, all_event_types)
        
        X_hadith = np.array([build_hadith_features(w, df, user_history, all_event_types) 
                            for w in windows])
        X_temporal = np.array([build_temporal_sequence_features(w, df, user_history, 
                                                                all_event_types, user_transitions)
                              for w in windows])
    else:
        X_hadith, X_temporal = build_simple_features(windows, df)
    
    X_combined = np.hstack([X_hadith, X_temporal])
    
    # Handle NaN
    X_hadith = np.nan_to_num(X_hadith)
    X_temporal = np.nan_to_num(X_temporal)
    X_combined = np.nan_to_num(X_combined)
    
    # Train-test split
    if y.sum() < 2:
        print("  ERROR: Too few positive samples")
        return {'name': name, 'error': 'Insufficient positives'}
    
    (X_h_train, X_h_test, X_t_train, X_t_test, X_c_train, X_c_test,
     y_train, y_test) = train_test_split(
        X_hadith, X_temporal, X_combined, y,
        test_size=0.3, stratify=y, random_state=RANDOM_STATE
    )
    
    # Scale
    scaler_h = StandardScaler().fit(X_h_train)
    X_h_test_s = scaler_h.transform(X_h_test)
    
    scaler_t = StandardScaler().fit(X_t_train)
    X_t_test_s = scaler_t.transform(X_t_test)
    
    scaler_c = StandardScaler().fit(X_c_train)
    X_c_test_s = scaler_c.transform(X_c_test)
    
    # Train models
    rf_combined = RandomForestClassifier(n_estimators=100, class_weight='balanced',
                                         random_state=RANDOM_STATE, n_jobs=-1)
    rf_combined.fit(scaler_c.transform(X_c_train), y_train)
    
    rf_hadith = RandomForestClassifier(n_estimators=100, class_weight='balanced',
                                       random_state=RANDOM_STATE, n_jobs=-1)
    rf_hadith.fit(scaler_h.transform(X_h_train), y_train)
    
    rf_temporal = RandomForestClassifier(n_estimators=100, class_weight='balanced',
                                         random_state=RANDOM_STATE, n_jobs=-1)
    rf_temporal.fit(scaler_t.transform(X_t_train), y_train)
    
    # Evaluate
    scores_c = rf_combined.predict_proba(X_c_test_s)[:, 1]
    scores_h = rf_hadith.predict_proba(X_h_test_s)[:, 1]
    scores_t = rf_temporal.predict_proba(X_t_test_s)[:, 1]
    
    roc_c = roc_auc_score(y_test, scores_c)
    roc_h = roc_auc_score(y_test, scores_h)
    roc_t = roc_auc_score(y_test, scores_t)
    
    pr_c = average_precision_score(y_test, scores_c)
    pr_h = average_precision_score(y_test, scores_h)
    pr_t = average_precision_score(y_test, scores_t)
    
    improvement = (roc_c - roc_h) / roc_h * 100 if roc_h > 0 else 0
    
    print(f"\n  Results:")
    print(f"    Combined:  ROC={roc_c:.4f}, PR={pr_c:.4f}")
    print(f"    Original:  ROC={roc_h:.4f}, PR={pr_h:.4f}")
    print(f"    Temporal:  ROC={roc_t:.4f}, PR={pr_t:.4f}")
    print(f"    Improvement: +{improvement:.1f}%")
    
    return {
        'name': name,
        'combined_roc': roc_c,
        'original_roc': roc_h,
        'temporal_roc': roc_t,
        'combined_pr': pr_c,
        'original_pr': pr_h,
        'temporal_pr': pr_t,
        'improvement': improvement,
        'n_windows': len(windows),
        'n_positive': y.sum()
    }


def run_cross_dataset_evaluation(datasets: List[Dict], 
                                 output_dir: str = './results') -> pd.DataFrame:
    """
    Run evaluation across multiple datasets.
    
    Args:
        datasets: List of {name, type, path, max_events, max_users}
        output_dir: Where to save results
    
    Returns:
        DataFrame with cross-dataset comparison
    """
    
    print("\n" + "="*70)
    print("CROSS-DATASET EVALUATION")
    print("="*70)
    print(f"\nDatasets to evaluate: {len(datasets)}")
    for ds in datasets:
        print(f"  - {ds['name']} ({ds['type']})")
    
    all_results = []
    
    for ds_config in datasets:
        result = run_single_dataset(ds_config)
        all_results.append(result)
    
    # Create comparison table
    comparison_df = pd.DataFrame(all_results)
    
    # Sort by combined ROC
    if 'combined_roc' in comparison_df.columns:
        comparison_df = comparison_df.sort_values('combined_roc', ascending=False)
    
    # Display results
    print("\n" + "="*70)
    print("CROSS-DATASET COMPARISON")
    print("="*70)
    print(comparison_df.to_string(index=False))
    
    # Save results
    os.makedirs(output_dir, exist_ok=True)
    comparison_df.to_csv(os.path.join(output_dir, 'cross_dataset_results.csv'), index=False)
    print(f"\n✓ Results saved to: {output_dir}/cross_dataset_results.csv")
    
    # Generate LaTeX table
    latex_table = generate_latex_table(comparison_df)
    with open(os.path.join(output_dir, 'cross_dataset_table.tex'), 'w') as f:
        f.write(latex_table)
    print(f"✓ LaTeX table saved to: {output_dir}/cross_dataset_table.tex")
    
    # Plot comparison
    plot_cross_dataset_comparison(comparison_df, output_dir)
    
    return comparison_df


def generate_latex_table(df: pd.DataFrame) -> str:
    """Generate LaTeX table for paper."""
    
    latex = r"""
\begin{table}[t]
\centering
\caption{Cross-dataset evaluation showing generalization of Hadith-inspired temporal features}
\label{tab:cross-dataset}
\begin{tabular}{lcccc}
\toprule
\textbf{Dataset} & \textbf{Combined} & \textbf{Original} & \textbf{Temporal} & \textbf{Δ (\%)} \\
\midrule
"""
    
    for _, row in df.iterrows():
        if 'combined_roc' in row and not pd.isna(row['combined_roc']):
            latex += f"{row['name']:20s} & {row['combined_roc']:.3f} & "
            latex += f"{row['original_roc']:.3f} & {row['temporal_roc']:.3f} & "
            latex += f"+{row['improvement']:.1f} \\\\\n"
    
    latex += r"""
\bottomrule
\end{tabular}
\end{table}
"""
    
    return latex


def plot_cross_dataset_comparison(df: pd.DataFrame, output_dir: str):
    """Create visualization comparing results across datasets."""
    
    if 'combined_roc' not in df.columns:
        return
    
    fig, axes = plt.subplots(1, 2, figsize=(14, 6))
    
    # Plot 1: ROC-AUC comparison
    ax = axes[0]
    x = np.arange(len(df))
    width = 0.25
    
    ax.bar(x - width, df['combined_roc'], width, label='Combined', color='#2E86AB')
    ax.bar(x, df['original_roc'], width, label='Original', color='#A23B72')
    ax.bar(x + width, df['temporal_roc'], width, label='Temporal', color='#F18F01')
    
    ax.set_xlabel('Dataset', fontsize=12, fontweight='bold')
    ax.set_ylabel('ROC-AUC', fontsize=12, fontweight='bold')
    ax.set_title('Cross-Dataset Performance', fontsize=14, fontweight='bold')
    ax.set_xticks(x)
    ax.set_xticklabels(df['name'], rotation=45, ha='right')
    ax.legend()
    ax.grid(True, alpha=0.3, axis='y')
    ax.set_ylim([0, 1])
    
    # Plot 2: Improvement percentage
    ax = axes[1]
    colors = ['green' if imp > 0 else 'red' for imp in df['improvement']]
    ax.barh(df['name'], df['improvement'], color=colors, alpha=0.7)
    ax.set_xlabel('Improvement (%)', fontsize=12, fontweight='bold')
    ax.set_title('Temporal Features Contribution', fontsize=14, fontweight='bold')
    ax.axvline(x=0, color='black', linestyle='--', linewidth=1)
    ax.grid(True, alpha=0.3, axis='x')
    
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'cross_dataset_comparison.png'), dpi=150)
    print(f"✓ Plots saved to: {output_dir}/cross_dataset_comparison.png")
    plt.close()


# ============================================================================
# MAIN
# ============================================================================

def parse_arguments():
    parser = argparse.ArgumentParser(description='Multi-Dataset Evaluation')
    
    parser.add_argument('--dataset', type=str, choices=DatasetLoader.SUPPORTED,
                       help='Single dataset type')
    parser.add_argument('--path', type=str, help='Path to dataset')
    
    parser.add_argument('--cross-dataset', action='store_true',
                       help='Run cross-dataset evaluation')
    parser.add_argument('--clue-csv', type=str, help='CLUE-LDS CSV path')
    parser.add_argument('--cert-dir', type=str, help='CERT directory')
    parser.add_argument('--lanl-dir', type=str, help='LANL directory')
    
    parser.add_argument('--adversarial', action='store_true',
                       help='Generate adversarial variants')
    
    parser.add_argument('--max-events', type=int, default=500_000)
    parser.add_argument('--max-users', type=int, default=100)
    parser.add_argument('--output-dir', type=str, default='./results')
    
    return parser.parse_args()


def main():
    args = parse_arguments()
    
    if args.cross_dataset:
        # Cross-dataset evaluation
        datasets = []
        
        if args.clue_csv:
            datasets.append({
                'name': 'CLUE-LDS',
                'type': 'clue-lds',
                'path': args.clue_csv,
                'max_events': args.max_events,
                'max_users': args.max_users
            })
        
        if args.cert_dir:
            datasets.append({
                'name': 'CERT-r6.2',
                'type': 'cert',
                'path': args.cert_dir,
                'max_events': args.max_events,
                'max_users': args.max_users
            })
        
        if args.lanl_dir:
            datasets.append({
                'name': 'LANL-Auth',
                'type': 'lanl',
                'path': args.lanl_dir,
                'max_events': args.max_events,
                'max_users': args.max_users
            })
        
        if not datasets:
            print("ERROR: No datasets specified for cross-dataset evaluation")
            return
        
        results = run_cross_dataset_evaluation(datasets, args.output_dir)
        
    elif args.dataset and args.path:
        # Single dataset
        result = run_single_dataset({
            'name': args.dataset.upper(),
            'type': args.dataset,
            'path': args.path,
            'max_events': args.max_events,
            'max_users': args.max_users
        })
        
        print(f"\n✓ Evaluation complete: {result}")
    
    else:
        print("ERROR: Please specify either --cross-dataset or --dataset + --path")


if __name__ == "__main__":
    main()

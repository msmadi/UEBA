#!/usr/bin/env python3
"""
CERT r6.2 Fast Training - Uses Pre-Extracted Features
Train models in seconds instead of hours!

Usage:
    # Train on 500-user features
    python train_cert_fast_saved.py --config cert_500users
    
    # Train on 4000-user features  
    python train_cert_fast_saved.py --config cert_4000users
    
    # From Jupyter
    from train_cert_fast_saved import train_fast
    results = train_fast('cert_500users')
"""

import os
import sys
import argparse
from datetime import datetime

import numpy as np
import pandas as pd

from sklearn.model_selection import train_test_split, StratifiedKFold
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (
    roc_auc_score, average_precision_score, f1_score,
    precision_score, recall_score, accuracy_score,
    roc_curve, precision_recall_curve
)
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier

import matplotlib.pyplot as plt
import seaborn as sns

sys.path.insert(0, r'F:\Projects\Security')

from load_cert_features_saved import load_features

RANDOM_STATE = 42
np.random.seed(RANDOM_STATE)


def evaluate(y_true, scores, name):
    """Compute metrics."""
    if len(np.unique(y_true)) < 2:
        return {'Approach': name, 'ROC-AUC': 0.5, 'PR-AUC': y_true.mean(), 
                'F1': 0.0, 'Precision': 0.0, 'Recall': 0.0, 'Accuracy': 0.0}
    
    scores_norm = (scores - scores.min()) / (scores.max() - scores.min() + 1e-9)
    
    try:
        roc = roc_auc_score(y_true, scores_norm)
    except:
        roc = 0.5
    
    try:
        pr = average_precision_score(y_true, scores_norm)
    except:
        pr = y_true.mean()
    
    best_f1, best_thr = 0, 0.5
    for thr in np.linspace(0, 1, 101):
        y_pred = (scores_norm >= thr).astype(int)
        f1 = f1_score(y_true, y_pred, zero_division=0)
        if f1 > best_f1:
            best_f1, best_thr = f1, thr
    
    y_pred = (scores_norm >= best_thr).astype(int)
    
    return {
        'Approach': name,
        'ROC-AUC': roc,
        'PR-AUC': pr,
        'F1': best_f1,
        'Precision': precision_score(y_true, y_pred, zero_division=0),
        'Recall': recall_score(y_true, y_pred, zero_division=0),
        'Accuracy': accuracy_score(y_true, y_pred),
        'Threshold': best_thr,
    }


def train_fast(config_name='cert_500users',
               output_dir=r'F:\Projects\Security\results_cert_fast_saved',
               save_plots=True):
    """
    Fast training on pre-extracted CERT features.
    
    Args:
        config_name: Feature configuration to load
        output_dir: Where to save results
        save_plots: Whether to save visualizations
    
    Returns:
        dict: Results and metrics
    """
    
    print("="*80)
    print("CERT r6.2 FAST TRAINING - Using Pre-Extracted Features")
    print("="*80)
    print(f"\nConfiguration: {config_name}")
    
    # ========================================================================
    # STEP 1: Load Features
    # ========================================================================
    print("\n" + "="*80)
    print("STEP 1: LOADING FEATURES")
    print("="*80)
    
    X_hadith, X_temporal, X_combined, y, metadata = load_features(config_name)
    
    if X_hadith is None:
        print("\n❌ Failed to load features")
        return None
    
    # ========================================================================
    # STEP 2: Train-Test Split
    # ========================================================================
    print("\n" + "="*80)
    print("STEP 2: TRAIN-TEST SPLIT")
    print("="*80)
    
    (X_h_train, X_h_test, X_t_train, X_t_test, X_c_train, X_c_test,
     y_train, y_test) = train_test_split(
        X_hadith, X_temporal, X_combined, y,
        test_size=0.3, stratify=y, random_state=RANDOM_STATE
    )
    
    print(f"\n✅ Split complete:")
    print(f"   Train: {len(y_train):,} (Pos: {int(y_train.sum()):,}, {y_train.mean()*100:.2f}%)")
    print(f"   Test:  {len(y_test):,} (Pos: {int(y_test.sum()):,}, {y_test.mean()*100:.2f}%)")
    
    # ========================================================================
    # STEP 3: Scale Features
    # ========================================================================
    print("\n" + "="*80)
    print("STEP 3: SCALING FEATURES")
    print("="*80)
    
    scaler_h = StandardScaler()
    X_h_tr = scaler_h.fit_transform(X_h_train)
    X_h_te = scaler_h.transform(X_h_test)
    
    scaler_t = StandardScaler()
    X_t_tr = scaler_t.fit_transform(X_t_train)
    X_t_te = scaler_t.transform(X_t_test)
    
    scaler_c = StandardScaler()
    X_c_tr = scaler_c.fit_transform(X_c_train)
    X_c_te = scaler_c.transform(X_c_test)
    
    print("\n✅ Features scaled (mean=0, std=1)")
    
    # ========================================================================
    # STEP 4: Train Models (9 models like CLUE)
    # ========================================================================
    print("\n" + "="*80)
    print("STEP 4: TRAINING MODELS")
    print("="*80)
    
    results = []
    
    print("\n  1/9: Combined + RandomForest...")
    rf_c = RandomForestClassifier(n_estimators=100, class_weight='balanced',
                                   random_state=RANDOM_STATE, n_jobs=-1)
    rf_c.fit(X_c_tr, y_train)
    scores_c_rf = rf_c.predict_proba(X_c_te)[:, 1]
    res = evaluate(y_test, scores_c_rf, "Combined + RF")
    results.append(res)
    print(f"      ROC-AUC={res['ROC-AUC']:.4f}, PR-AUC={res['PR-AUC']:.4f}")
    
    print("\n  2/9: Combined + GradientBoosting...")
    gb_c = GradientBoostingClassifier(n_estimators=100, max_depth=5, random_state=RANDOM_STATE)
    gb_c.fit(X_c_tr, y_train)
    scores_c_gb = gb_c.predict_proba(X_c_te)[:, 1]
    res = evaluate(y_test, scores_c_gb, "Combined + GB")
    results.append(res)
    print(f"      ROC-AUC={res['ROC-AUC']:.4f}, PR-AUC={res['PR-AUC']:.4f}")
    
    print("\n  3/9: Original Hadith + RF...")
    rf_h = RandomForestClassifier(n_estimators=100, class_weight='balanced',
                                   random_state=RANDOM_STATE, n_jobs=-1)
    rf_h.fit(X_h_tr, y_train)
    scores_h_rf = rf_h.predict_proba(X_h_te)[:, 1]
    res = evaluate(y_test, scores_h_rf, "Original Hadith + RF")
    results.append(res)
    print(f"      ROC-AUC={res['ROC-AUC']:.4f}, PR-AUC={res['PR-AUC']:.4f}")
    
    print("\n  4/9: Original Hadith + GB...")
    gb_h = GradientBoostingClassifier(n_estimators=100, max_depth=5, random_state=RANDOM_STATE)
    gb_h.fit(X_h_tr, y_train)
    scores_h_gb = gb_h.predict_proba(X_h_te)[:, 1]
    res = evaluate(y_test, scores_h_gb, "Original Hadith + GB")
    results.append(res)
    print(f"      ROC-AUC={res['ROC-AUC']:.4f}, PR-AUC={res['PR-AUC']:.4f}")
    
    print("\n  5/9: Temporal Only + RF...")
    rf_t = RandomForestClassifier(n_estimators=100, class_weight='balanced',
                                   random_state=RANDOM_STATE, n_jobs=-1)
    rf_t.fit(X_t_tr, y_train)
    scores_t_rf = rf_t.predict_proba(X_t_te)[:, 1]
    res = evaluate(y_test, scores_t_rf, "Temporal Only + RF")
    results.append(res)
    print(f"      ROC-AUC={res['ROC-AUC']:.4f}, PR-AUC={res['PR-AUC']:.4f}")
    
    print("\n  6/9: Temporal Only + GB...")
    gb_t = GradientBoostingClassifier(n_estimators=100, max_depth=5, random_state=RANDOM_STATE)
    gb_t.fit(X_t_tr, y_train)
    scores_t_gb = gb_t.predict_proba(X_t_te)[:, 1]
    res = evaluate(y_test, scores_t_gb, "Temporal Only + GB")
    results.append(res)
    print(f"      ROC-AUC={res['ROC-AUC']:.4f}, PR-AUC={res['PR-AUC']:.4f}")
    
    # Train LSTM
    print("\n  7/9: Combined + LSTM...")
    try:
        import torch
        import torch.nn as nn
        import torch.optim as optim
        from torch.utils.data import TensorDataset, DataLoader
        
        # Simple LSTM classifier
        class LSTMClassifier(nn.Module):
            def __init__(self, input_dim, hidden_dim=64):
                super(LSTMClassifier, self).__init__()
                self.lstm = nn.LSTM(input_dim, hidden_dim, batch_first=True)
                self.fc = nn.Linear(hidden_dim, 1)
                self.sigmoid = nn.Sigmoid()
            
            def forward(self, x):
                lstm_out, (h_n, c_n) = self.lstm(x)
                out = h_n[-1]
                out = self.fc(out)
                return self.sigmoid(out).squeeze()
        
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        
        # Prepare data
        X_c_tr_t = torch.FloatTensor(X_c_tr).unsqueeze(1).to(device)
        y_train_t = torch.FloatTensor(y_train.values if hasattr(y_train, 'values') else y_train).to(device)
        X_c_te_t = torch.FloatTensor(X_c_te).unsqueeze(1).to(device)
        
        # Train LSTM
        model_lstm = LSTMClassifier(X_combined.shape[1]).to(device)
        criterion = nn.BCELoss()
        optimizer = optim.Adam(model_lstm.parameters(), lr=0.001)
        
        # Simple training loop
        model_lstm.train()
        for epoch in range(20):  # Quick training
            optimizer.zero_grad()
            outputs = model_lstm(X_c_tr_t)
            loss = criterion(outputs, y_train_t)
            loss.backward()
            optimizer.step()
            
            if epoch % 10 == 0:
                print(f"      Epoch {epoch}/20, Loss: {loss.item():.4f}")
        
        # Predict
        model_lstm.eval()
        with torch.no_grad():
            scores_lstm = model_lstm(X_c_te_t).cpu().numpy()
        
        res = evaluate(y_test, scores_lstm, "Combined + LSTM")
        results.append(res)
        print(f"      ROC-AUC={res['ROC-AUC']:.4f}, PR-AUC={res['PR-AUC']:.4f}")
        
    except ImportError:
        print("      ⚠️  PyTorch not available - skipping LSTM")
    except Exception as e:
        print(f"      ⚠️  LSTM training failed: {e}")
    
    # Load raw and minimal features if available
    X_raw_test = X_minimal_test = None
    try:
        raw_file = os.path.join(config_dir, 'features_raw.npy')
        minimal_file = os.path.join(config_dir, 'features_minimal.npy')
        
        if os.path.exists(raw_file):
            X_raw = np.load(raw_file)
            X_r_train, X_r_test = train_test_split(
                X_raw, test_size=0.3, random_state=RANDOM_STATE, 
                stratify=y
            )[1::2]  # Get test set only
            
            scaler_r = StandardScaler()
            X_r_tr = scaler_r.fit_transform(X_r_train)
            X_r_te = scaler_r.transform(X_r_test)
            
            print("\n  8/9: Raw Counts + RF...")
            rf_r = RandomForestClassifier(n_estimators=100, class_weight='balanced',
                                         random_state=RANDOM_STATE, n_jobs=-1)
            rf_r.fit(X_r_tr, y_train)
            scores_r = rf_r.predict_proba(X_r_te)[:, 1]
            res = evaluate(y_test, scores_r, "Raw Counts + RF")
            results.append(res)
            print(f"      ROC-AUC={res['ROC-AUC']:.4f}, PR-AUC={res['PR-AUC']:.4f}")
        
        if os.path.exists(minimal_file):
            X_minimal = np.load(minimal_file)
            X_m_train, X_m_test = train_test_split(
                X_minimal, test_size=0.3, random_state=RANDOM_STATE,
                stratify=y
            )[1::2]  # Get test set only
            
            scaler_m = StandardScaler()
            X_m_tr = scaler_m.fit_transform(X_m_train)
            X_m_te = scaler_m.transform(X_m_test)
            
            print("\n  9/10: Minimal + RF...")  # Changed to 9/10 since we have LSTM now
            rf_m = RandomForestClassifier(n_estimators=100, class_weight='balanced',
                                         random_state=RANDOM_STATE, n_jobs=-1)
            rf_m.fit(X_m_tr, y_train)
            scores_m = rf_m.predict_proba(X_m_te)[:, 1]
            res = evaluate(y_test, scores_m, "Minimal + RF")
            results.append(res)
            print(f"      ROC-AUC={res['ROC-AUC']:.4f}, PR-AUC={res['PR-AUC']:.4f}")
    except:
        print("\n  ⚠️  Raw/Minimal features not available (skipping)")
    
    print("\n  10/10: Random Baseline...")  # Changed to 10/10
    scores_rand = np.random.random(len(y_test))
    res = evaluate(y_test, scores_rand, "Random")
    results.append(res)
    print(f"      ROC-AUC={res['ROC-AUC']:.4f}, PR-AUC={res['PR-AUC']:.4f}")
    
    print("\n✅ All models trained!")
    
    # ========================================================================
    # STEP 5: Results
    # ========================================================================
    print("\n" + "="*80)
    print("RESULTS")
    print("="*80)
    
    results_df = pd.DataFrame(results).sort_values('ROC-AUC', ascending=False)
    print("\n" + results_df.to_string(index=False))
    
    # ========================================================================
    # STEP 6: Ablation Analysis
    # ========================================================================
    print("\n" + "="*80)
    print("ABLATION ANALYSIS")
    print("="*80)
    
    combined_roc = results_df[results_df['Approach'] == 'Combined + RF']['ROC-AUC'].values[0]
    orig_roc = results_df[results_df['Approach'] == 'Original Hadith + RF']['ROC-AUC'].values[0]
    temporal_roc = results_df[results_df['Approach'] == 'Temporal Only + RF']['ROC-AUC'].values[0]
    
    combined_pr = results_df[results_df['Approach'] == 'Combined + RF']['PR-AUC'].values[0]
    orig_pr = results_df[results_df['Approach'] == 'Original Hadith + RF']['PR-AUC'].values[0]
    
    combined_f1 = results_df[results_df['Approach'] == 'Combined + RF']['F1'].values[0]
    orig_f1 = results_df[results_df['Approach'] == 'Original Hadith + RF']['F1'].values[0]
    
    print(f"\n📊 Overall Performance Comparison:")
    print(f"{'':30s} {'ROC-AUC':>10s} {'PR-AUC':>10s} {'F1':>10s}")
    print(f"{'-'*60}")
    print(f"{'Full Combined (42 features)':30s} {combined_roc:10.4f} {combined_pr:10.4f} {combined_f1:10.4f}")
    print(f"{'Original Hadith (26)':30s} {orig_roc:10.4f} {orig_pr:10.4f} {orig_f1:10.4f}")
    print(f"{'Temporal Only (16)':30s} {temporal_roc:10.4f}")
    
    if orig_roc > 0:
        improvement = (combined_roc - orig_roc) / orig_roc * 100
        pr_improvement = (combined_pr - orig_pr) / orig_pr * 100 if orig_pr > 0 else 0
        f1_improvement = (combined_f1 - orig_f1) / orig_f1 * 100 if orig_f1 > 0 else 0
        
        print(f"\n🎯 Improvement from Temporal Features:")
        print(f"  ROC-AUC: {orig_roc:.4f} → {combined_roc:.4f} ({improvement:+.2f}%)")
        print(f"  PR-AUC:  {orig_pr:.4f} → {combined_pr:.4f} ({pr_improvement:+.2f}%)")
        print(f"  F1:      {orig_f1:.4f} → {combined_f1:.4f} ({f1_improvement:+.2f}%)")
        
        if improvement > 0:
            print(f"\n✅ Temporal features improve ROC-AUC by {improvement:.2f}%")
        elif abs(improvement) < 0.1:
            print(f"\n≈ Performance equivalent (difference < 0.1%)")
        else:
            print(f"\n⚠️  Combined performance lower than baseline")
    
    # ========================================================================
    # DETAILED ABLATION: Remove/Test Individual Axes
    # ========================================================================
    print("\n" + "="*80)
    print("DETAILED ABLATION STUDY")
    print("="*80)
    
    print("\n🔬 Testing impact of individual feature axes...")
    
    # Feature indices for each axis
    axis_indices = {
        'Adalah': list(range(0, 5)),           # adalah_* (5 features)
        'Dabt': list(range(5, 12)),            # dabt_* (7 features)
        'Isnad': list(range(12, 18)),          # isnad_* (6 features)
        'Reputation': list(range(18, 22)),     # rep_* (4 features)
        'Anomaly': list(range(22, 26)),        # anom_* (4 features)
        'Temporal_Dabt': list(range(26, 31)),      # temp dabt (5 features)
        'Temporal_Adalah': list(range(31, 36)),    # temp adalah (5 features)
        'Temporal_Isnad': list(range(36, 39)),     # temp isnad (3 features)
        'Temporal_Rep': list(range(39, 42)),       # temp rep (3 features)
    }
    
    ablation_results = []
    
    # 1. REMOVING INDIVIDUAL AXES
    print("\n📉 1. Removing Individual Axes from Full Set (42 → 42-N):")
    print(f"{'Axis Removed':25s} {'Features':>10s} {'ROC-AUC':>10s} {'PR-AUC':>10s} {'F1':>10s}")
    print("-" * 65)
    
    for axis_name, indices in axis_indices.items():
        # Create mask for all features EXCEPT this axis
        mask = np.ones(42, dtype=bool)
        mask[indices] = False
        
        X_ablated_train = X_c_train[:, mask]
        X_ablated_test = X_c_test[:, mask]
        
        # Scale
        scaler_abl = StandardScaler()
        X_abl_tr = scaler_abl.fit_transform(X_ablated_train)
        X_abl_te = scaler_abl.transform(X_ablated_test)
        
        # Train
        rf_abl = RandomForestClassifier(n_estimators=100, class_weight='balanced',
                                        random_state=RANDOM_STATE, n_jobs=-1)
        rf_abl.fit(X_abl_tr, y_train)
        scores_abl = rf_abl.predict_proba(X_abl_te)[:, 1]
        
        # Evaluate
        roc_abl = roc_auc_score(y_test, scores_abl)
        pr_abl = average_precision_score(y_test, scores_abl)
        
        best_f1 = 0
        for thr in np.linspace(0, 1, 51):
            f1 = f1_score(y_test, (scores_abl >= thr).astype(int), zero_division=0)
            best_f1 = max(best_f1, f1)
        
        n_features = 42 - len(indices)
        ablation_results.append({
            'Type': 'Remove',
            'Axis': axis_name,
            'Features': n_features,
            'ROC-AUC': roc_abl,
            'PR-AUC': pr_abl,
            'F1': best_f1,
            'Delta_ROC': roc_abl - combined_roc
        })
        
        print(f"Without {axis_name:20s} {n_features:10d} {roc_abl:10.4f} {pr_abl:10.4f} {best_f1:10.4f}")
    
    # 2. SINGLE AXIS ONLY MODELS
    print(f"\n📊 2. Single-Axis Only Models (Using Only One Axis):")
    print(f"{'Axis Used':25s} {'Features':>10s} {'ROC-AUC':>10s} {'PR-AUC':>10s} {'F1':>10s}")
    print("-" * 65)
    
    for axis_name, indices in axis_indices.items():
        # Use ONLY this axis
        X_single_train = X_c_train[:, indices]
        X_single_test = X_c_test[:, indices]
        
        # Scale
        scaler_sgl = StandardScaler()
        X_sgl_tr = scaler_sgl.fit_transform(X_single_train)
        X_sgl_te = scaler_sgl.transform(X_single_test)
        
        # Train
        rf_sgl = RandomForestClassifier(n_estimators=100, class_weight='balanced',
                                        random_state=RANDOM_STATE, n_jobs=-1)
        rf_sgl.fit(X_sgl_tr, y_train)
        scores_sgl = rf_sgl.predict_proba(X_sgl_te)[:, 1]
        
        # Evaluate
        roc_sgl = roc_auc_score(y_test, scores_sgl)
        pr_sgl = average_precision_score(y_test, scores_sgl)
        
        best_f1 = 0
        for thr in np.linspace(0, 1, 51):
            f1 = f1_score(y_test, (scores_sgl >= thr).astype(int), zero_division=0)
            best_f1 = max(best_f1, f1)
        
        ablation_results.append({
            'Type': 'Only',
            'Axis': axis_name,
            'Features': len(indices),
            'ROC-AUC': roc_sgl,
            'PR-AUC': pr_sgl,
            'F1': best_f1,
            'Delta_ROC': roc_sgl - combined_roc
        })
        
        print(f"{axis_name:25s} {len(indices):10d} {roc_sgl:10.4f} {pr_sgl:10.4f} {best_f1:10.4f}")
    
    # 3. GROUPED COMPARISONS
    print(f"\n📈 3. Original vs Temporal Feature Groups:")
    print(f"{'Group':25s} {'Features':>10s} {'ROC-AUC':>10s} {'PR-AUC':>10s} {'F1':>10s}")
    print("-" * 65)
    print(f"{'Original Hadith (26)':25s} {26:10d} {orig_roc:10.4f} {orig_pr:10.4f} {orig_f1:10.4f}")
    print(f"{'Temporal Only (16)':25s} {16:10d} {temporal_roc:10.4f}")
    print(f"{'Combined (42)':25s} {42:10d} {combined_roc:10.4f} {combined_pr:10.4f} {combined_f1:10.4f}")
    
    # Save ablation results
    ablation_df = pd.DataFrame(ablation_results)
    
    # ========================================================================
    # ABLATION INSIGHTS
    # ========================================================================
    print("\n" + "="*80)
    print("ABLATION INSIGHTS")
    print("="*80)
    
    # Find most impactful axis (largest drop when removed)
    remove_results = ablation_df[ablation_df['Type'] == 'Remove'].sort_values('Delta_ROC')
    if len(remove_results) > 0:
        most_impactful = remove_results.iloc[0]
        
        print(f"\n🎯 Most Critical Axis (largest drop when removed):")
        print(f"  {most_impactful['Axis']}: ROC-AUC drops by {abs(most_impactful['Delta_ROC']):.4f}")
        print(f"  ({most_impactful['Features']} features remaining)")
    
    # Find best single axis
    only_results = ablation_df[ablation_df['Type'] == 'Only'].sort_values('ROC-AUC', ascending=False)
    if len(only_results) > 0:
        best_single = only_results.iloc[0]
        
        print(f"\n🏆 Best Single Axis:")
        print(f"  {best_single['Axis']}: ROC-AUC = {best_single['ROC-AUC']:.4f}")
        print(f"  ({best_single['Features']} features)")
    
    # Temporal vs Original comparison
    orig_axes = ablation_df[(ablation_df['Type'] == 'Only') & 
                            (~ablation_df['Axis'].str.startswith('Temporal'))]
    temp_axes = ablation_df[(ablation_df['Type'] == 'Only') & 
                            (ablation_df['Axis'].str.startswith('Temporal'))]
    
    if len(orig_axes) > 0 and len(temp_axes) > 0:
        orig_avg = orig_axes['ROC-AUC'].mean()
        temp_avg = temp_axes['ROC-AUC'].mean()
        
        print(f"\n📊 Average Performance by Type:")
        print(f"  Original axes (5): {orig_avg:.4f}")
        print(f"  Temporal axes (4): {temp_avg:.4f}")
        print(f"  Difference: {temp_avg - orig_avg:+.4f}")
    
    # ========================================================================
    # STEP 7: Feature Importance
    # ========================================================================
    print("\n" + "="*80)
    print("FEATURE IMPORTANCE")
    print("="*80)
    
    feature_names = metadata.get('feature_names', {})
    hadith_names = feature_names.get('hadith', [f"hadith_{i}" for i in range(26)])
    temporal_names = feature_names.get('temporal', [f"temporal_{i}" for i in range(16)])
    all_names = hadith_names + temporal_names
    
    importances = rf_c.feature_importances_
    sorted_idx = np.argsort(importances)[::-1]
    
    print("\nTop 15 Features:")
    for i in range(15):
        idx = sorted_idx[i]
        marker = "🔄" if "temp_" in all_names[idx] else "📊"
        print(f"   {i+1:2d}. {marker} {all_names[idx]:30s} {importances[idx]:.4f}")
    
    orig_total = importances[:26].sum()
    temp_total = importances[26:42].sum()
    
    print(f"\nImportance by Type:")
    print(f"  Original Hadith: {orig_total:.4f} ({orig_total/importances.sum()*100:.1f}%)")
    print(f"  Temporal:        {temp_total:.4f} ({temp_total/importances.sum()*100:.1f}%)")
    
    # ========================================================================
    # STEP 8: Save Results
    # ========================================================================
    print("\n" + "="*80)
    print("SAVING RESULTS")
    print("="*80)
    
    os.makedirs(output_dir, exist_ok=True)
    
    # Get config directory for loading raw/minimal
    config_dir = os.path.join(r'F:\Projects\Security\cert_features_saved', config_name)
    
    # Save main results
    results_df.to_csv(os.path.join(output_dir, f'{config_name}_results.csv'), index=False)
    print(f"\n✅ Saved: {output_dir}/{config_name}_results.csv")
    
    # Save ablation results
    ablation_df.to_csv(os.path.join(output_dir, f'{config_name}_ablation.csv'), index=False)
    print(f"✅ Saved: {output_dir}/{config_name}_ablation.csv")
    
    # Save feature importance
    importance_df = pd.DataFrame({
        'Feature': all_names,
        'Importance': importances,
        'Type': ['Original']*26 + ['Temporal']*16,
        'Axis': (
            ['Adalah']*5 + ['Dabt']*7 + ['Isnad']*6 + ['Reputation']*4 + ['Anomaly']*4 +
            ['Temporal_Dabt']*5 + ['Temporal_Adalah']*5 + ['Temporal_Isnad']*3 + ['Temporal_Rep']*3
        )
    }).sort_values('Importance', ascending=False)
    importance_df.to_csv(os.path.join(output_dir, f'{config_name}_importance.csv'), index=False)
    print(f"✅ Saved: {output_dir}/{config_name}_importance.csv")
    
    # Save comprehensive summary
    with open(os.path.join(output_dir, f'{config_name}_summary.txt'), 'w') as f:
        f.write(f"CERT r6.2 COMPREHENSIVE ANALYSIS - {config_name}\n")
        f.write("=" * 80 + "\n\n")
        f.write(f"Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"Configuration: {config_name}\n")
        f.write(f"Windows: {len(y):,}\n")
        f.write(f"Positive: {int(y.sum()):,} ({y.mean()*100:.2f}%)\n")
        f.write(f"Users: {metadata.get('total_users', '?')}\n")
        f.write(f"Malicious users: {metadata.get('malicious_users', '?')}\n\n")
        
        f.write("MAIN RESULTS\n")
        f.write("-" * 80 + "\n")
        f.write(results_df.to_string(index=False))
        
        f.write("\n\nOVERALL ABLATION\n")
        f.write("-" * 80 + "\n")
        f.write(f"Combined ROC-AUC: {combined_roc:.4f}\n")
        f.write(f"Original ROC-AUC: {orig_roc:.4f}\n")
        f.write(f"Temporal ROC-AUC: {temporal_roc:.4f}\n")
        f.write(f"Improvement: {improvement:+.2f}%\n\n")
        
        f.write("DETAILED ABLATION\n")
        f.write("-" * 80 + "\n")
        f.write(ablation_df.to_string(index=False))
        
        f.write("\n\nFEATURE IMPORTANCE (Top 20)\n")
        f.write("-" * 80 + "\n")
        f.write(importance_df.head(20).to_string(index=False))
        
        f.write(f"\n\nTEMPORAL CONTRIBUTION\n")
        f.write("-" * 80 + "\n")
        f.write(f"Original features: {orig_total:.4f} ({orig_total/importances.sum()*100:.1f}%)\n")
        f.write(f"Temporal features: {temp_total:.4f} ({temp_total/importances.sum()*100:.1f}%)\n")
    
    print(f"✅ Saved: {output_dir}/{config_name}_summary.txt")
    
    # ========================================================================
    # DONE
    # ========================================================================
    print("\n" + "="*80)
    print("✅ ANALYSIS COMPLETE!")
    print("="*80)
    
    print(f"\nAll results saved to: {output_dir}")
    
    print(f"\nKey Findings:")
    print(f"  - Combined ROC-AUC: {combined_roc:.4f}")
    print(f"  - Temporal contribution: {improvement:+.2f}%")
    print(f"  - Top feature: {all_names[sorted_idx[0]]}")
    print(f"  - Malicious users detected: {metadata.get('malicious_users', '?')}")
    
    return {
        'results_df': results_df,
        'ablation_df': ablation_df,
        'improvement': improvement,
        'temporal_contribution': temp_total / importances.sum(),
        'combined_roc': combined_roc,
        'original_roc': orig_roc,
        'most_critical_axis': most_impactful['Axis'] if len(remove_results) > 0 else None,
        'best_single_axis': best_single['Axis'] if len(only_results) > 0 else None,
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', type=str, default='cert_500users', help='Configuration name')
    args = parser.parse_args()
    
    results = train_fast(args.config)
    
    if results:
        print(f"\n✅ Training complete for: {args.config}")
        print(f"   Improvement: {results['improvement']:+.2f}%")

#!/usr/bin/env python3
"""
CODE VALIDATION SCRIPT
Check all files for common bugs before running extraction/training

Run this BEFORE running the full pipeline!
"""

import os
import sys
import importlib.util

print("="*80)
print("CERT ANALYSIS - CODE VALIDATION")
print("="*80)

# ============================================================================
# CHECK 1: File Existence
# ============================================================================

print("\n" + "="*80)
print("CHECK 1: File Existence")
print("="*80)

required_files = {
    'extract_cert_features_saved.py': 'Feature extraction script',
    'load_cert_features_saved.py': 'Feature loading script',
    'train_cert_fast_saved.py': 'Training script',
    'load_cert_scalable.py': 'Scalable data loader',
    'compare_features_temporal_FULL.py': 'Feature builders',
}

base_path = r'F:\Projects\Security'
all_files_exist = True

for filename, description in required_files.items():
    filepath = os.path.join(base_path, filename)
    if os.path.exists(filepath):
        size_kb = os.path.getsize(filepath) / 1024
        print(f"✅ {filename:40s} ({size_kb:.1f} KB) - {description}")
    else:
        print(f"❌ {filename:40s} MISSING! - {description}")
        all_files_exist = False

if all_files_exist:
    print("\n✅ All required files present!")
else:
    print("\n❌ Some files are missing - download them first!")

# ============================================================================
# CHECK 2: Import Test
# ============================================================================

print("\n" + "="*80)
print("CHECK 2: Import Test")
print("="*80)

sys.path.insert(0, base_path)

imports_ok = True

# Test imports
try:
    print("\nTesting imports...")
    
    print("  - numpy...", end='')
    import numpy as np
    print(" ✅")
    
    print("  - pandas...", end='')
    import pandas as pd
    print(" ✅")
    
    print("  - sklearn...", end='')
    from sklearn.ensemble import RandomForestClassifier
    print(" ✅")
    
    print("  - matplotlib...", end='')
    import matplotlib.pyplot as plt
    print(" ✅")
    
    print("\n✅ All core libraries available!")
    
except ImportError as e:
    print(f" ❌\n\n❌ Import error: {e}")
    imports_ok = False

# ============================================================================
# CHECK 3: Syntax Validation
# ============================================================================

print("\n" + "="*80)
print("CHECK 3: Syntax Validation")
print("="*80)

syntax_ok = True

for filename in required_files.keys():
    filepath = os.path.join(base_path, filename)
    if not os.path.exists(filepath):
        continue
    
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            code = f.read()
        
        compile(code, filepath, 'exec')
        print(f"✅ {filename:40s} - Syntax OK")
        
    except SyntaxError as e:
        print(f"❌ {filename:40s} - SYNTAX ERROR at line {e.lineno}")
        print(f"   {e.msg}")
        syntax_ok = False
    except Exception as e:
        print(f"⚠️  {filename:40s} - Warning: {e}")

if syntax_ok:
    print("\n✅ All files have valid Python syntax!")
else:
    print("\n❌ Syntax errors found - fix before running!")

# ============================================================================
# CHECK 4: Function Availability
# ============================================================================

print("\n" + "="*80)
print("CHECK 4: Function Availability")
print("="*80)

functions_ok = True

try:
    # Test extract function
    from extract_cert_features_saved import extract_and_save_cert_features
    print("✅ extract_and_save_cert_features() available")
    
    # Test load function
    from load_cert_features_saved import load_features, list_available_configs
    print("✅ load_features() available")
    print("✅ list_available_configs() available")
    
    # Test train function
    from train_cert_fast_saved import train_fast
    print("✅ train_fast() available")
    
    # Test feature builders
    from compare_features_temporal_FULL import (
        construct_windows,
        build_hadith_features,
        build_temporal_sequence_features
    )
    print("✅ construct_windows() available")
    print("✅ build_hadith_features() available")
    print("✅ build_temporal_sequence_features() available")
    
    print("\n✅ All required functions available!")
    
except ImportError as e:
    print(f"❌ Import error: {e}")
    functions_ok = False
except AttributeError as e:
    print(f"❌ Function not found: {e}")
    functions_ok = False

# ============================================================================
# CHECK 5: Directory Structure
# ============================================================================

print("\n" + "="*80)
print("CHECK 5: Directory Structure")
print("="*80)

required_dirs = [
    (r'F:\Projects\Security\cert\r6.2', 'CERT dataset'),
    (r'F:\Projects\Security\cert_features_saved', 'Saved features (will be created)'),
    (r'F:\Projects\Security\results_cert_fast_saved', 'Results (will be created)'),
]

for dirpath, description in required_dirs:
    if os.path.exists(dirpath):
        print(f"✅ {dirpath}")
        print(f"   {description} - EXISTS")
    else:
        if 'will be created' in description:
            print(f"📁 {dirpath}")
            print(f"   {description} - Will be created automatically")
        else:
            print(f"❌ {dirpath}")
            print(f"   {description} - MISSING!")

# Check CERT files
cert_path = r'F:\Projects\Security\cert\r6.2'
if os.path.exists(cert_path):
    print(f"\n📊 CERT r6.2 files:")
    cert_files = ['logon.csv', 'device.csv', 'file.csv', 'email.csv', 'http.csv']
    for cf in cert_files:
        cf_path = os.path.join(cert_path, cf)
        if os.path.exists(cf_path):
            size_mb = os.path.getsize(cf_path) / (1024**2)
            print(f"   ✅ {cf:20s} ({size_mb:.1f} MB)")
        else:
            print(f"   ⚠️  {cf:20s} NOT FOUND")

# ============================================================================
# CHECK 6: Memory Check
# ============================================================================

print("\n" + "="*80)
print("CHECK 6: System Resources")
print("="*80)

try:
    import psutil
    
    # RAM
    mem = psutil.virtual_memory()
    print(f"\n💾 RAM:")
    print(f"   Total: {mem.total / (1024**3):.1f} GB")
    print(f"   Available: {mem.available / (1024**3):.1f} GB")
    
    if mem.available / (1024**3) < 2:
        print(f"   ⚠️  WARNING: Low memory (< 2 GB available)")
        print(f"      Feature extraction may fail!")
    else:
        print(f"   ✅ Sufficient memory")
    
    # Disk
    disk = psutil.disk_usage('F:\\')
    print(f"\n💿 Disk (F:):")
    print(f"   Total: {disk.total / (1024**3):.1f} GB")
    print(f"   Free: {disk.free / (1024**3):.1f} GB")
    
    if disk.free / (1024**3) < 5:
        print(f"   ⚠️  WARNING: Low disk space (< 5 GB)")
        print(f"      May not have room for features!")
    else:
        print(f"   ✅ Sufficient disk space")
    
except ImportError:
    print("⚠️  psutil not available - skipping resource check")

# ============================================================================
# CHECK 7: Quick Smoke Test
# ============================================================================

print("\n" + "="*80)
print("CHECK 7: Quick Smoke Test")
print("="*80)

print("\nTesting feature builders with dummy data...")

try:
    from compare_features_temporal_FULL import (
        construct_windows,
        build_user_history,
        build_hadith_features
    )
    
    # Create dummy data
    dummy_df = pd.DataFrame({
        'user_id': ['U001'] * 100,
        'timestamp': pd.date_range('2020-01-01', periods=100, freq='1H', tz='UTC'),
        'event_type': ['login'] * 100,
        'device': ['PC001'] * 100,
        'ip_address': ['10.0.0.1'] * 100,
        'path': [''] * 100,
        'source': ['test'] * 100
    })
    
    # Test window construction
    print("  Testing construct_windows()...", end='')
    windows = construct_windows(dummy_df, window_size=10, step_size=5)
    assert len(windows) > 0, "No windows created!"
    print(f" ✅ ({len(windows)} windows)")
    
    # Test user history
    print("  Testing build_user_history()...", end='')
    history = build_user_history(dummy_df)
    assert len(history) > 0, "No history built!"
    print(" ✅")
    
    # Test feature extraction
    print("  Testing build_hadith_features()...", end='')
    features = build_hadith_features(windows[0], dummy_df, history, ['login'])
    assert len(features) == 26, f"Wrong number of features: {len(features)}"
    print(f" ✅ (26 features)")
    
    print("\n✅ Smoke test passed!")
    
except Exception as e:
    print(f" ❌\n\n❌ Smoke test failed: {e}")
    import traceback
    traceback.print_exc()

# ============================================================================
# FINAL SUMMARY
# ============================================================================

print("\n" + "="*80)
print("VALIDATION SUMMARY")
print("="*80)

checks = [
    ("Files exist", all_files_exist),
    ("Imports work", imports_ok),
    ("Syntax valid", syntax_ok),
    ("Functions available", functions_ok),
]

all_passed = all(passed for _, passed in checks)

print()
for check_name, passed in checks:
    status = "✅ PASS" if passed else "❌ FAIL"
    print(f"{status:10s} - {check_name}")

print("\n" + "="*80)

if all_passed:
    print("✅ ALL CHECKS PASSED!")
    print("="*80)
    print("\n🚀 You're ready to run the CERT analysis!")
    print("\nNext steps:")
    print("  1. Open Jupyter notebook")
    print("  2. Run CERT_Analysis_Complete.py")
    print("  3. Extract features (Cell 3)")
    print("  4. Train models (Cell 6)")
    print("  5. Generate paper tables (Cells 9-11)")
else:
    print("❌ SOME CHECKS FAILED!")
    print("="*80)
    print("\n⚠️  Fix the errors above before proceeding!")
    print("\nCommon fixes:")
    print("  - Download missing files from Claude")
    print("  - Install missing packages: pip install numpy pandas scikit-learn matplotlib")
    print("  - Check that CERT dataset is in F:\\Projects\\Security\\cert\\r6.2")

print()

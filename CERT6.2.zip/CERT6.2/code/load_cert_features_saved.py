#!/usr/bin/env python3
"""
Load Pre-Extracted CERT Features
Load features instantly without re-extraction

Usage:
    from load_cert_features_saved import load_features
    
    # Load 500-user features
    X_h, X_t, X_c, y, meta = load_features('cert_500users')
    
    # Load 4000-user features
    X_h, X_t, X_c, y, meta = load_features('cert_4000users')
"""

import os
import json
import pickle
import numpy as np


def load_features(config_name='cert_500users', 
                  base_dir=r'F:\Projects\Security\cert_features_saved'):
    """
    Load pre-extracted CERT features.
    
    Args:
        config_name: Configuration name (e.g., 'cert_500users', 'cert_4000users')
        base_dir: Base directory where features are saved
    
    Returns:
        X_hadith: Original Hadith features (N, 26)
        X_temporal: Temporal sequence features (N, 16)
        X_combined: Combined features (N, 42)
        y: Labels (N,)
        metadata: Dictionary with extraction metadata
    """
    
    print("="*70)
    print("LOADING PRE-EXTRACTED CERT FEATURES")
    print("="*70)
    
    config_dir = os.path.join(base_dir, config_name)
    
    if not os.path.exists(config_dir):
        print(f"\n❌ ERROR: Configuration not found: {config_name}")
        print(f"   Path: {config_dir}")
        print(f"\n   Available configurations:")
        if os.path.exists(base_dir):
            for item in os.listdir(base_dir):
                if os.path.isdir(os.path.join(base_dir, item)):
                    print(f"     - {item}")
        return None, None, None, None, None
    
    print(f"\nFeatures directory: {config_dir}")
    
    # Load metadata
    metadata_file = os.path.join(config_dir, 'metadata.json')
    if os.path.exists(metadata_file):
        print(f"\n📋 Loading metadata...")
        with open(metadata_file, 'r') as f:
            metadata = json.load(f)
        
        print(f"   Extraction date: {metadata['extraction_date']}")
        print(f"   Total windows: {metadata['windows']:,}")
        print(f"   Positive rate: {metadata['positive_rate']*100:.2f}%")
        print(f"   Users: {metadata['total_users']}")
        print(f"   Malicious users: {metadata['malicious_users']}")
    else:
        print(f"\n⚠️  Warning: metadata.json not found")
        metadata = {}
    
    # Load features
    print(f"\n📊 Loading features...")
    
    hadith_file = os.path.join(config_dir, 'features_hadith.npy')
    X_hadith = np.load(hadith_file)
    print(f"   ✅ Hadith features: {X_hadith.shape} ({os.path.getsize(hadith_file)/(1024**2):.2f} MB)")
    
    temporal_file = os.path.join(config_dir, 'features_temporal.npy')
    X_temporal = np.load(temporal_file)
    print(f"   ✅ Temporal features: {X_temporal.shape} ({os.path.getsize(temporal_file)/(1024**2):.2f} MB)")
    
    combined_file = os.path.join(config_dir, 'features_combined.npy')
    X_combined = np.load(combined_file)
    print(f"   ✅ Combined features: {X_combined.shape} ({os.path.getsize(combined_file)/(1024**2):.2f} MB)")
    
    # Load labels
    print(f"\n🏷️  Labels: ", end='')
    labels_file = os.path.join(config_dir, 'labels.npy')
    y = np.load(labels_file)
    pos = int(y.sum())
    neg = len(y) - pos
    print(f"{y.shape}")
    print(f"   Positive: {pos:,} ({pos/len(y)*100:.2f}%)")
    print(f"   Negative: {neg:,} ({neg/len(y)*100:.2f}%)")
    
    # Load windows (optional)
    windows_file = os.path.join(config_dir, 'windows.pkl')
    if os.path.exists(windows_file):
        with open(windows_file, 'rb') as f:
            windows = pickle.load(f)
        metadata['windows_objects'] = windows
    
    print("\n" + "="*70)
    print("✅ FEATURES LOADED SUCCESSFULLY!")
    print("="*70)
    
    print(f"\n📦 Returned objects:")
    print(f"   X_hadith:   {X_hadith.shape} - Original Hadith features")
    print(f"   X_temporal: {X_temporal.shape} - Temporal sequence features")
    print(f"   X_combined: {X_combined.shape} - Combined features")
    print(f"   y:          {y.shape} - Labels (0=normal, 1=malicious)")
    print(f"   metadata:   dict - Extraction metadata")
    
    return X_hadith, X_temporal, X_combined, y, metadata


def list_available_configs(base_dir=r'F:\Projects\Security\cert_features_saved'):
    """List all available feature configurations."""
    
    print("="*70)
    print("AVAILABLE CERT FEATURE CONFIGURATIONS")
    print("="*70)
    
    if not os.path.exists(base_dir):
        print(f"\n❌ Directory not found: {base_dir}")
        return []
    
    configs = []
    for item in os.listdir(base_dir):
        item_path = os.path.join(base_dir, item)
        if os.path.isdir(item_path):
            metadata_file = os.path.join(item_path, 'metadata.json')
            if os.path.exists(metadata_file):
                with open(metadata_file, 'r') as f:
                    meta = json.load(f)
                
                configs.append({
                    'name': item,
                    'users': meta.get('total_users', '?'),
                    'windows': meta.get('windows', '?'),
                    'positive_rate': meta.get('positive_rate', 0) * 100,
                    'extraction_date': meta.get('extraction_date', 'Unknown')
                })
    
    if configs:
        print(f"\nFound {len(configs)} configuration(s):\n")
        for cfg in configs:
            print(f"  📁 {cfg['name']}")
            print(f"     Users: {cfg['users']}, Windows: {cfg['windows']:,}, Pos: {cfg['positive_rate']:.1f}%")
            print(f"     Extracted: {cfg['extraction_date'][:10]}")
            print()
    else:
        print(f"\n❌ No configurations found in: {base_dir}")
    
    return configs


if __name__ == "__main__":
    # Show available configurations
    list_available_configs()
    
    # Example: Load 500-user features
    print("\n" + "="*70)
    print("EXAMPLE: Loading cert_500users")
    print("="*70)
    
    X_h, X_t, X_c, y, meta = load_features('cert_500users')
    
    if X_h is not None:
        print(f"\n✅ Loaded successfully!")
        print(f"   Ready for training!")

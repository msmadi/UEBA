#!/usr/bin/env python3
"""
CERT Feature Loader
Quickly load pre-extracted features from disk

USAGE:
======
from load_cert_features import load_features

# Load features
X_hadith, X_temporal, X_combined, y, metadata = load_features()

# Or specify custom path
X_hadith, X_temporal, X_combined, y, metadata = load_features('path/to/features')
"""

import os
import sys
import numpy as np
import pickle
import json


def load_features(features_dir=None):
    """
    Load pre-extracted CERT features from disk.
    
    Args:
        features_dir: Directory containing feature files (default: F:\Projects\Security\cert_features)
    
    Returns:
        tuple: (X_hadith, X_temporal, X_combined, y, metadata)
    """
    
    if features_dir is None:
        features_dir = r"F:\Projects\Security\cert_features"
    
    print("="*70)
    print("LOADING PRE-EXTRACTED CERT FEATURES")
    print("="*70)
    print(f"\nFeatures directory: {features_dir}")
    
    if not os.path.exists(features_dir):
        print(f"\n❌ ERROR: Features directory not found!")
        print(f"   Expected: {features_dir}")
        print(f"\nPlease run extract_cert_features.py first to extract features.")
        return None, None, None, None, None
    
    # Check for required files
    required_files = {
        'hadith': 'features_hadith.npy',
        'temporal': 'features_temporal.npy',
        'combined': 'features_combined.npy',
        'labels': 'labels.npy',
        'metadata': 'metadata.json'
    }
    
    missing = []
    for name, filename in required_files.items():
        filepath = os.path.join(features_dir, filename)
        if not os.path.exists(filepath):
            missing.append(filename)
    
    if missing:
        print(f"\n❌ ERROR: Missing files:")
        for f in missing:
            print(f"   - {f}")
        print(f"\nPlease run extract_cert_features.py first.")
        return None, None, None, None, None
    
    # Load metadata first
    print("\n📋 Loading metadata...")
    metadata_file = os.path.join(features_dir, 'metadata.json')
    with open(metadata_file, 'r') as f:
        metadata = json.load(f)
    
    print(f"   Extraction date: {metadata['extraction_date']}")
    print(f"   Total windows: {metadata['total_windows']:,}")
    print(f"   Positive rate: {metadata['positive_rate']*100:.2f}%")
    
    # Load features
    print("\n📊 Loading features...")
    
    hadith_file = os.path.join(features_dir, 'features_hadith.npy')
    X_hadith = np.load(hadith_file)
    size_mb = os.path.getsize(hadith_file) / (1024**2)
    print(f"   ✅ Hadith features: {X_hadith.shape} ({size_mb:.2f} MB)")
    
    temporal_file = os.path.join(features_dir, 'features_temporal.npy')
    X_temporal = np.load(temporal_file)
    size_mb = os.path.getsize(temporal_file) / (1024**2)
    print(f"   ✅ Temporal features: {X_temporal.shape} ({size_mb:.2f} MB)")
    
    combined_file = os.path.join(features_dir, 'features_combined.npy')
    X_combined = np.load(combined_file)
    size_mb = os.path.getsize(combined_file) / (1024**2)
    print(f"   ✅ Combined features: {X_combined.shape} ({size_mb:.2f} MB)")
    
    # Load labels
    labels_file = os.path.join(features_dir, 'labels.npy')
    y = np.load(labels_file)
    pos = int(y.sum())
    neg = len(y) - pos
    print(f"\n🏷️  Labels: {y.shape}")
    print(f"   Positive: {pos:,} ({pos/len(y)*100:.2f}%)")
    print(f"   Negative: {neg:,} ({neg/len(y)*100:.2f}%)")
    
    print("\n" + "="*70)
    print("✅ FEATURES LOADED SUCCESSFULLY!")
    print("="*70)
    
    print("\n📦 Returned objects:")
    print(f"   X_hadith:   {X_hadith.shape} - Original Hadith features")
    print(f"   X_temporal: {X_temporal.shape} - Temporal sequence features")
    print(f"   X_combined: {X_combined.shape} - Combined features")
    print(f"   y:          {y.shape} - Labels (0=normal, 1=hijacked)")
    print(f"   metadata:   dict - Extraction metadata")
    
    return X_hadith, X_temporal, X_combined, y, metadata


def get_feature_names(metadata=None):
    """
    Get feature names from metadata.
    
    Args:
        metadata: Metadata dict (if None, loads from default path)
    
    Returns:
        dict: {'hadith': [...], 'temporal': [...], 'combined': [...]}
    """
    
    if metadata is None:
        features_dir = r"F:\Projects\Security\cert_features"
        metadata_file = os.path.join(features_dir, 'metadata.json')
        with open(metadata_file, 'r') as f:
            metadata = json.load(f)
    
    feature_names = metadata['feature_names']
    feature_names['combined'] = feature_names['hadith'] + feature_names['temporal']
    
    return feature_names


def print_feature_info(metadata=None):
    """Print detailed feature information."""
    
    if metadata is None:
        features_dir = r"F:\Projects\Security\cert_features"
        metadata_file = os.path.join(features_dir, 'metadata.json')
        with open(metadata_file, 'r') as f:
            metadata = json.load(f)
    
    print("="*70)
    print("CERT FEATURE INFORMATION")
    print("="*70)
    
    print(f"\n📊 Dataset:")
    print(f"   Total events: {metadata['total_events']:,}")
    print(f"   Total users: {metadata['total_users']}")
    print(f"   Event types: {metadata['event_types']}")
    print(f"   Date range: {metadata['date_range']['min']} to {metadata['date_range']['max']}")
    
    print(f"\n🪟 Windows:")
    print(f"   Total: {metadata['total_windows']:,}")
    print(f"   Positive: {metadata['positive_windows']:,} ({metadata['positive_rate']*100:.2f}%)")
    print(f"   Negative: {metadata['negative_windows']:,}")
    
    print(f"\n🎯 Malicious Users: {len(metadata['malicious_users'])}")
    for user in metadata['malicious_users']:
        print(f"   - {user}")
    
    print(f"\n📐 Features:")
    print(f"   Hadith: {metadata['hadith_features']}")
    print(f"   Temporal: {metadata['temporal_features']}")
    print(f"   Combined: {metadata['combined_features']}")
    
    print(f"\n📝 Hadith Feature Names ({len(metadata['feature_names']['hadith'])}):")
    for i, name in enumerate(metadata['feature_names']['hadith'], 1):
        print(f"   {i:2d}. {name}")
    
    print(f"\n📝 Temporal Feature Names ({len(metadata['feature_names']['temporal'])}):")
    for i, name in enumerate(metadata['feature_names']['temporal'], 1):
        print(f"   {i:2d}. {name}")


# Convenience function for quick loading
def quick_load():
    """Quick load with minimal output."""
    import os
    features_dir = r"F:\Projects\Security\cert_features"
    
    X_hadith = np.load(os.path.join(features_dir, 'features_hadith.npy'))
    X_temporal = np.load(os.path.join(features_dir, 'features_temporal.npy'))
    X_combined = np.load(os.path.join(features_dir, 'features_combined.npy'))
    y = np.load(os.path.join(features_dir, 'labels.npy'))
    
    with open(os.path.join(features_dir, 'metadata.json'), 'r') as f:
        metadata = json.load(f)
    
    return X_hadith, X_temporal, X_combined, y, metadata


if __name__ == "__main__":
    """Demo: Load and display feature info."""
    
    X_hadith, X_temporal, X_combined, y, metadata = load_features()
    
    if X_hadith is not None:
        print("\n" + "="*70)
        print("FEATURE DETAILS")
        print("="*70)
        print_feature_info(metadata)
        
        print("\n" + "="*70)
        print("USAGE EXAMPLE")
        print("="*70)
        print("""
from load_cert_features import load_features
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier

# Load features (instant!)
X_hadith, X_temporal, X_combined, y, metadata = load_features()

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(
    X_combined, y, test_size=0.3, stratify=y, random_state=42
)

# Train model
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Evaluate
score = model.score(X_test, y_test)
print(f"Accuracy: {score:.4f}")
""")

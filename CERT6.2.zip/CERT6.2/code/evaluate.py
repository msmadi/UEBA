"""
COMPLETE IMPLEMENTATION: Hadith-Inspired Features with Temporal Sequence Analysis
Full production-ready code with all features (26 Original + 16 Temporal = 42 Total)

Research: Multi-Axis Trust Modeling for Interpretable Account Hijacking Detection

DATA:
=====
data\cert\r6.2 :   Place all the cert dataset r6.2 files in one folder including the answers files 

USAGE:
======
Command Line:
    python evaluate.py --csv clue_lds_logs.csv --max-events 500000 --n-hijacks 30 --save-plots

Jupyter:
    
    results = train_fast('cert_4000users')
"""
# Re-extract using the CORRECT loader
from load_cert_expanded import load_cert_expanded
from compare_features_temporal_FULL import (
    construct_windows, build_user_history, build_transition_matrices,
    build_hadith_features, build_temporal_sequence_features,
    build_raw_count_features, build_minimal_features
)
import numpy as np
import pickle
import json
import os
from datetime import datetime

# Load with CORRECT loader
print("Loading CERT data...")
df, gt_df = load_cert_expanded(
    cert_path=r"data\cert\r6.2", #Change to your CERT r6.2 data folder
    target_events=10_000_000,
    max_users=4000
)

print(f"Loaded: {len(df):,} events, {df['user_id'].nunique()} users")

# Construct windows
print("\nConstructing windows...")
windows = construct_windows(df, window_size=50, step_size=25)
print(f"Created {len(windows):,} windows")

# Label
malicious_users = set(gt_df['user'].astype(str).unique())
y = np.array([1 if w['user_id'] in malicious_users else 0 for w in windows])
print(f"Positive: {int(y.sum()):,} ({y.sum()/len(y)*100:.2f}%)")

# Extract ALL features
print("\nExtracting features...")
user_history = build_user_history(df)
all_event_types = df['event_type'].unique()
user_transitions = build_transition_matrices(df, all_event_types)

X_hadith = []
X_temporal = []
X_raw = []
X_minimal = []

for i, w in enumerate(windows):
    if i % 500 == 0:
        print(f"  {i}/{len(windows)}")
    
    X_hadith.append(build_hadith_features(w, df, user_history, all_event_types))
    X_temporal.append(build_temporal_sequence_features(w, df, user_history, all_event_types, user_transitions))
    X_raw.append(build_raw_count_features(w, df, all_event_types))
    X_minimal.append(build_minimal_features(w, df))

X_hadith = np.nan_to_num(np.array(X_hadith), 0)
X_temporal = np.nan_to_num(np.array(X_temporal), 0)
X_combined = np.hstack([X_hadith, X_temporal])
X_raw = np.nan_to_num(np.array(X_raw), 0)
X_minimal = np.nan_to_num(np.array(X_minimal), 0)

# Save to cert_500users
output_dir = r"\cert_features_saved\cert_4000users" #Change to your output features folder
os.makedirs(output_dir, exist_ok=True)

print("\nSaving features...")
np.save(os.path.join(output_dir, 'features_hadith.npy'), X_hadith)
np.save(os.path.join(output_dir, 'features_temporal.npy'), X_temporal)
np.save(os.path.join(output_dir, 'features_combined.npy'), X_combined)
np.save(os.path.join(output_dir, 'features_raw.npy'), X_raw)
np.save(os.path.join(output_dir, 'features_minimal.npy'), X_minimal)
np.save(os.path.join(output_dir, 'labels.npy'), y)

with open(os.path.join(output_dir, 'windows.pkl'), 'wb') as f:
    pickle.dump(windows, f)

# Complete metadata
metadata = {
    'config_name': 'cert_4000users',
    'extraction_date': datetime.now().isoformat(),
    'cert_path': r'data\cert\r6.2', #Change to your CERT r6.2 data folder
    'max_events': 10_000_000,
    'max_users': 4000,
    'load_full': False,
    'total_events': len(df),
    'total_users': int(df['user_id'].nunique()),
    'malicious_users': len(gt_df),
    'event_types': int(df['event_type'].nunique()),
    'windows': len(windows),
    'positive_windows': int(y.sum()),
    'negative_windows': int(len(y) - y.sum()),
    'positive_rate': float(y.sum() / len(y)),
    'feature_shapes': {
        'hadith': list(X_hadith.shape),
        'temporal': list(X_temporal.shape),
        'combined': list(X_combined.shape),
        'raw': list(X_raw.shape),
        'minimal': list(X_minimal.shape),
    },
    'feature_names': {
        'hadith': [
            "adalah_active_days", "adalah_total_events", "adalah_account_age",
            "adalah_consistency", "adalah_avg_events",
            "dabt_login_success", "dabt_delta_fail", "dabt_burstiness",
            "dabt_outside_hours", "dabt_timing_entropy", "dabt_vocab_div",
            "dabt_sensitive_ratio",
            "isnad_ip_consistency", "isnad_ip_match", "isnad_subnet_match",
            "isnad_geo_impossible", "isnad_session_discont", "isnad_new_ip_rate",
            "rep_duration", "rep_trust", "rep_penalty", "rep_trend",
            "anom_kl_div", "anom_hour", "anom_path", "anom_l2_dist",
        ],
        'temporal': [
            "temp_kl_transition", "temp_rare_transitions", "temp_seq_entropy",
            "temp_ngram_anomaly", "temp_run_anomaly",
            "temp_behavior_drift", "temp_autocorr", "temp_timing_shift",
            "temp_dow_divergence", "temp_rate_drift",
            "temp_subnet_drift", "temp_ip_switch_rate", "temp_device_trans_anom",
            "temp_failure_trend", "temp_cumul_suspicious", "temp_risk_accel",
        ]
    }
}

with open(os.path.join(output_dir, 'metadata.json'), 'w') as f:
    json.dump(metadata, f, indent=2)

print(f"\n✅ Features saved to: {output_dir}")
print(f"   Windows: {len(windows):,}")
print(f"   Positive: {int(y.sum()):,} ({y.sum()/len(y)*100:.2f}%)")

# NOW train with the CORRECT features
from train_cert_fast_saved import train_fast
results = train_fast('cert_4000users')

print(f"\n🎉 DONE!")
print(f"Combined ROC-AUC: {results['combined_roc']:.4f}")
print(f"Improvement: {results['improvement']:+.2f}%")
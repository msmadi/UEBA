"""
CERT r6.2 COMPLETE ANALYSIS - JUPYTER NOTEBOOK
==============================================

This notebook runs the complete CERT analysis pipeline:
1. Extract features at different scales (500, 1000, 4000 users)
2. Train models instantly using saved features
3. Generate publication-ready results

Run cells in order!
"""

# ============================================================================
# CELL 1: Setup and Imports
# ============================================================================

import sys
import os

# Add project directory to path
sys.path.insert(0, r'F:\Projects\Security')

import numpy as np
import pandas as pd
from datetime import datetime

# Set display options
pd.set_option('display.max_columns', None)
pd.set_option('display.width', 120)
pd.set_option('display.float_format', '{:.4f}'.format)

print("✅ Setup complete!")
print(f"Working directory: {os.getcwd()}")
print(f"Python path includes: F:\\Projects\\Security")


# ============================================================================
# CELL 2: Check Available Configurations
# ============================================================================

from load_cert_features_saved import list_available_configs

print("Checking for pre-extracted features...\n")
configs = list_available_configs()

if len(configs) == 0:
    print("\n⚠️  No pre-extracted features found!")
    print("   You need to extract features first (see Cell 3)")
else:
    print(f"\n✅ Found {len(configs)} configuration(s)")
    print("   Ready to train!")


# ============================================================================
# CELL 3: Extract Features - 500 Users (Quick Test)
# ============================================================================

"""
Extract features for 500 users
Time: ~30-45 minutes
Use: Quick validation, baseline results
"""

from extract_cert_features_saved import extract_and_save_cert_features

print("="*80)
print("EXTRACTING FEATURES: 500 USERS")
print("="*80)
print("\nThis will take approximately 30-45 minutes")
print("The features will be saved and can be reused forever!\n")

# Uncomment to run:
# metadata_500 = extract_and_save_cert_features(
#     cert_path=r"F:\Projects\Security\cert\r6.2",
#     output_dir=r"F:\Projects\Security\cert_features_saved",
#     max_events=1_500_000,
#     max_users=500,
#     load_full=False,
#     config_name="cert_500users"
# )
# 
# if metadata_500:
#     print("\n✅ SUCCESS! Features extracted for 500 users")
#     print(f"   Windows: {metadata_500['windows']:,}")
#     print(f"   Positive rate: {metadata_500['positive_rate']*100:.2f}%")
# else:
#     print("\n❌ FAILED to extract features")

print("\n💡 TIP: Uncomment the code above to run extraction")


# ============================================================================
# CELL 4: Extract Features - 1000 Users (Medium Scale)
# ============================================================================

"""
Extract features for 1000 users
Time: ~1-1.5 hours
Use: Good balance, strong paper results
"""

print("="*80)
print("EXTRACTING FEATURES: 1000 USERS")
print("="*80)
print("\nThis will take approximately 1-1.5 hours")
print("Run this overnight or during lunch!\n")

# Uncomment to run:
# metadata_1000 = extract_and_save_cert_features(
#     cert_path=r"F:\Projects\Security\cert\r6.2",
#     output_dir=r"F:\Projects\Security\cert_features_saved",
#     max_events=3_000_000,
#     max_users=1000,
#     load_full=False,
#     config_name="cert_1000users"
# )
# 
# if metadata_1000:
#     print("\n✅ SUCCESS! Features extracted for 1000 users")
# else:
#     print("\n❌ FAILED to extract features")

print("\n💡 TIP: Uncomment the code above to run extraction")


# ============================================================================
# CELL 5: Extract Features - 4000 Users (Full Dataset)
# ============================================================================

"""
Extract features for 4000 users (full CERT dataset)
Time: ~3-4 hours
Use: Maximum comparison with literature
"""

print("="*80)
print("EXTRACTING FEATURES: 4000 USERS (FULL)")
print("="*80)
print("\nThis will take approximately 3-4 hours")
print("Run this overnight!\n")

# Uncomment to run:
# metadata_4000 = extract_and_save_cert_features(
#     cert_path=r"F:\Projects\Security\cert\r6.2",
#     output_dir=r"F:\Projects\Security\cert_features_saved",
#     max_events=10_000_000,
#     max_users=4000,
#     load_full=True,  # Load everything!
#     config_name="cert_4000users"
# )
# 
# if metadata_4000:
#     print("\n✅ SUCCESS! Features extracted for 4000 users")
# else:
#     print("\n❌ FAILED to extract features")

print("\n💡 TIP: Uncomment the code above to run extraction")


# ============================================================================
# CELL 6: Train Models - 500 Users (FAST!)
# ============================================================================

"""
Train all models on 500-user features
Time: ~30 seconds ⚡
"""

from train_cert_fast_saved import train_fast

print("="*80)
print("TRAINING MODELS: 500 USERS")
print("="*80)
print("\nThis should take less than 1 minute!\n")

try:
    results_500 = train_fast(
        config_name='cert_500users',
        output_dir=r'F:\Projects\Security\results_cert_fast_saved',
        save_plots=True
    )
    
    if results_500:
        print("\n" + "="*80)
        print("✅ TRAINING COMPLETE!")
        print("="*80)
        
        print("\n📊 KEY RESULTS:")
        print(f"   Combined ROC-AUC: {results_500['combined_roc']:.4f}")
        print(f"   Original ROC-AUC: {results_500['original_roc']:.4f}")
        print(f"   Improvement: {results_500['improvement']:+.2f}%")
        print(f"   Temporal contribution: {results_500['temporal_contribution']*100:.1f}%")
        
        print("\n🎯 ABLATION INSIGHTS:")
        print(f"   Most critical axis: {results_500['most_critical_axis']}")
        print(f"   Best single axis: {results_500['best_single_axis']}")
        
        print("\n📈 TOP 10 MODELS:")
        print(results_500['results_df'].head(10).to_string(index=False))
        
    else:
        print("\n❌ Training failed - check error messages above")
        
except Exception as e:
    print(f"\n❌ ERROR: {e}")
    print("\nMake sure you've extracted features first (Cell 3)")


# ============================================================================
# CELL 7: Train Models - 1000 Users
# ============================================================================

"""
Train all models on 1000-user features
Time: ~1 minute
"""

print("="*80)
print("TRAINING MODELS: 1000 USERS")
print("="*80)

try:
    results_1000 = train_fast(
        config_name='cert_1000users',
        output_dir=r'F:\Projects\Security\results_cert_fast_saved'
    )
    
    if results_1000:
        print("\n✅ SUCCESS!")
        print(f"   Combined ROC-AUC: {results_1000['combined_roc']:.4f}")
        print(f"   Improvement: {results_1000['improvement']:+.2f}%")
    else:
        print("\n❌ Training failed")
        
except Exception as e:
    print(f"\n❌ ERROR: {e}")
    print("Make sure you've extracted 1000-user features first (Cell 4)")


# ============================================================================
# CELL 8: Train Models - 4000 Users
# ============================================================================

"""
Train all models on 4000-user features
Time: ~2-3 minutes
"""

print("="*80)
print("TRAINING MODELS: 4000 USERS")
print("="*80)

try:
    results_4000 = train_fast(
        config_name='cert_4000users',
        output_dir=r'F:\Projects\Security\results_cert_fast_saved'
    )
    
    if results_4000:
        print("\n✅ SUCCESS!")
        print(f"   Combined ROC-AUC: {results_4000['combined_roc']:.4f}")
        print(f"   Improvement: {results_4000['improvement']:+.2f}%")
    else:
        print("\n❌ Training failed")
        
except Exception as e:
    print(f"\n❌ ERROR: {e}")
    print("Make sure you've extracted 4000-user features first (Cell 5)")


# ============================================================================
# CELL 9: Compare All Scales
# ============================================================================

"""
Compare results across all scales
"""

print("="*80)
print("SCALABILITY COMPARISON")
print("="*80)

comparison_data = []

# Collect results from all scales
configs_to_check = [
    ('cert_500users', 500),
    ('cert_1000users', 1000),
    ('cert_4000users', 4000)
]

for config_name, n_users in configs_to_check:
    try:
        # Try to load results
        results_file = f"F:\\Projects\\Security\\results_cert_fast_saved\\{config_name}_results.csv"
        if os.path.exists(results_file):
            df = pd.read_csv(results_file)
            
            combined_row = df[df['Approach'] == 'Combined + RF'].iloc[0]
            original_row = df[df['Approach'] == 'Original Hadith + RF'].iloc[0]
            
            improvement = ((combined_row['ROC-AUC'] - original_row['ROC-AUC']) / 
                          original_row['ROC-AUC'] * 100)
            
            comparison_data.append({
                'Users': n_users,
                'Combined ROC-AUC': combined_row['ROC-AUC'],
                'Original ROC-AUC': original_row['ROC-AUC'],
                'Improvement (%)': improvement,
                'Combined PR-AUC': combined_row['PR-AUC'],
                'F1': combined_row['F1']
            })
    except Exception as e:
        print(f"⚠️  Could not load results for {config_name}: {e}")

if comparison_data:
    comparison_df = pd.DataFrame(comparison_data)
    
    print("\n📊 SCALABILITY ANALYSIS:")
    print(comparison_df.to_string(index=False))
    
    print("\n📝 LATEX TABLE FOR PAPER:")
    print("\\begin{table}[t]")
    print("\\centering")
    print("\\caption{Scalability Analysis on CERT r6.2}")
    print("\\begin{tabular}{rrrr}")
    print("\\toprule")
    print("\\textbf{Users} & \\textbf{Combined} & \\textbf{Original} & \\textbf{Improvement} \\\\")
    print("\\midrule")
    
    for _, row in comparison_df.iterrows():
        print(f"{row['Users']:,} & {row['Combined ROC-AUC']:.3f} & "
              f"{row['Original ROC-AUC']:.3f} & {row['Improvement (%)']:+.1f}\\% \\\\")
    
    print("\\bottomrule")
    print("\\end{tabular}")
    print("\\end{table}")
    
    # Save comparison
    comparison_df.to_csv(
        r"F:\Projects\Security\results_cert_fast_saved\scalability_comparison.csv",
        index=False
    )
    print("\n✅ Saved: results_cert_fast_saved/scalability_comparison.csv")
    
else:
    print("\n⚠️  No results available yet!")
    print("   Train models first (Cells 6-8)")


# ============================================================================
# CELL 10: Generate Paper-Ready Ablation Tables
# ============================================================================

"""
Create formatted ablation tables for publication
"""

print("="*80)
print("PAPER-READY ABLATION TABLES")
print("="*80)

# Use 500-user results as example (or change to any config)
config_to_use = 'cert_500users'

try:
    ablation_file = f"F:\\Projects\\Security\\results_cert_fast_saved\\{config_to_use}_ablation.csv"
    
    if os.path.exists(ablation_file):
        ablation_df = pd.read_csv(ablation_file)
        
        # Separate remove vs only experiments
        remove_df = ablation_df[ablation_df['Type'] == 'Remove'].copy()
        only_df = ablation_df[ablation_df['Type'] == 'Only'].copy()
        
        print("\n📉 TABLE 1: Removing Individual Axes")
        print("-" * 70)
        print(remove_df[['Axis', 'Features', 'ROC-AUC', 'PR-AUC', 'F1']].to_string(index=False))
        
        print("\n\n📊 TABLE 2: Single-Axis Only Models")
        print("-" * 70)
        print(only_df[['Axis', 'Features', 'ROC-AUC', 'PR-AUC', 'F1']].to_string(index=False))
        
        # Generate LaTeX
        print("\n\n📝 LATEX TABLE (Remove Axes):")
        print("\\begin{tabular}{lcccc}")
        print("\\toprule")
        print("\\textbf{Axis Removed} & \\textbf{Features} & \\textbf{ROC-AUC} & "
              "\\textbf{PR-AUC} & \\textbf{F$_1$} \\\\")
        print("\\midrule")
        
        for _, row in remove_df.iterrows():
            axis_name = row['Axis'].replace('_', '\\_')
            print(f"Without {axis_name} & {row['Features']} & "
                  f"{row['ROC-AUC']:.3f} & {row['PR-AUC']:.3f} & {row['F1']:.3f} \\\\")
        
        print("\\bottomrule")
        print("\\end{tabular}")
        
        print("\n✅ Ablation tables generated!")
        
    else:
        print(f"\n⚠️  Ablation file not found: {ablation_file}")
        print("   Train models first (Cell 6)")
        
except Exception as e:
    print(f"\n❌ ERROR: {e}")


# ============================================================================
# CELL 11: Visualize Feature Importance
# ============================================================================

"""
Create feature importance visualization
"""

import matplotlib.pyplot as plt
import seaborn as sns

print("="*80)
print("FEATURE IMPORTANCE VISUALIZATION")
print("="*80)

config_to_plot = 'cert_500users'

try:
    importance_file = f"F:\\Projects\\Security\\results_cert_fast_saved\\{config_to_plot}_importance.csv"
    
    if os.path.exists(importance_file):
        imp_df = pd.read_csv(importance_file)
        
        # Plot top 20
        top_20 = imp_df.head(20)
        
        plt.figure(figsize=(12, 8))
        
        colors = ['#F18F01' if 'temp_' in f else '#2E86AB' 
                  for f in top_20['Feature']]
        
        plt.barh(range(len(top_20)), top_20['Importance'], color=colors)
        plt.yticks(range(len(top_20)), top_20['Feature'])
        plt.xlabel('Feature Importance', fontsize=12, fontweight='bold')
        plt.title('CERT r6.2 - Top 20 Features', fontsize=14, fontweight='bold')
        plt.gca().invert_yaxis()
        plt.grid(True, alpha=0.3, axis='x')
        
        from matplotlib.patches import Patch
        legend_elements = [
            Patch(facecolor='#2E86AB', label='Original Hadith'),
            Patch(facecolor='#F18F01', label='Temporal Sequence')
        ]
        plt.legend(handles=legend_elements, loc='lower right')
        
        plt.tight_layout()
        plt.savefig(f"F:\\Projects\\Security\\results_cert_fast_saved\\{config_to_plot}_importance.png", 
                    dpi=150)
        print(f"\n✅ Saved: results_cert_fast_saved/{config_to_plot}_importance.png")
        
        plt.show()
        
        # Print summary
        orig_imp = imp_df[~imp_df['Feature'].str.startswith('temp_')]['Importance'].sum()
        temp_imp = imp_df[imp_df['Feature'].str.startswith('temp_')]['Importance'].sum()
        total = orig_imp + temp_imp
        
        print(f"\n📊 IMPORTANCE SUMMARY:")
        print(f"   Original: {orig_imp:.4f} ({orig_imp/total*100:.1f}%)")
        print(f"   Temporal: {temp_imp:.4f} ({temp_imp/total*100:.1f}%)")
        
    else:
        print(f"\n⚠️  Importance file not found: {importance_file}")
        
except Exception as e:
    print(f"\n❌ ERROR: {e}")


# ============================================================================
# CELL 12: Summary Report
# ============================================================================

"""
Generate comprehensive summary report
"""

print("="*80)
print("COMPREHENSIVE SUMMARY REPORT")
print("="*80)

print("\n📁 FILES CREATED:\n")

base_dir = r"F:\Projects\Security"

# Features
features_dir = os.path.join(base_dir, "cert_features_saved")
if os.path.exists(features_dir):
    print("✅ EXTRACTED FEATURES:")
    for item in os.listdir(features_dir):
        item_path = os.path.join(features_dir, item)
        if os.path.isdir(item_path):
            size_mb = sum(os.path.getsize(os.path.join(item_path, f)) 
                         for f in os.listdir(item_path)) / (1024**2)
            print(f"   {item}: {size_mb:.1f} MB")

# Results
results_dir = os.path.join(base_dir, "results_cert_fast_saved")
if os.path.exists(results_dir):
    print("\n✅ TRAINING RESULTS:")
    for item in os.listdir(results_dir):
        if item.endswith('.csv') or item.endswith('.txt'):
            print(f"   {item}")

print("\n" + "="*80)
print("ALL DONE! 🎉")
print("="*80)

print("\n📊 NEXT STEPS FOR YOUR PAPER:")
print("   1. Use scalability_comparison.csv for Table 1")
print("   2. Use *_ablation.csv for detailed ablation tables")
print("   3. Use *_importance.csv for feature analysis")
print("   4. Use the LaTeX code generated above")

print("\n✅ Your CERT analysis is publication-ready!")
